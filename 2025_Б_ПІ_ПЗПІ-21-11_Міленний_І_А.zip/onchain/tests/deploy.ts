import {before} from "mocha";
import {
    createLaunchpoolTestingEnvironment,
    getLaunchpoolsConfigPDA,
    getLaunchpoolsConfigsManagerPDA, LaunchpoolTestingEnvironment
} from "./launchpool/helpers";
import {
    createLaunchpoolBackendIntegrationTestingEnvironment
} from "./launchpool/launchpool-backend_integration/helpers";
import {ProgramDerivedAddress} from "@solana/kit";
import {
    createLiquidityPoolTestingEnvironment, getAmmsConfigPDA,
    getAmmsConfigsManagerPDA,
    LiquidityPoolTestingEnvironment
} from "./liquidity-pool/helpers";
import {
    createLiquidityPoolBackendIntegrationTestingEnvironment,
    LiquidityPoolBackendIntegrationTestingEnvironment
} from "./liquidity-pool/liquidity-pool-integration/helpers";
import {
    launchpoolsConfigsManagerBackendIntegrationTests
} from "./launchpool/launchpool-backend_integration/launchpools-configs-manager.test";
import {
    launchpoolsConfigBackendIntegrationTests
} from "./launchpool/launchpool-backend_integration/launchpools-config.test";
import {launchpoolBackendIntegrationTests} from "./launchpool/launchpool-backend_integration/launchpool.test";
import {deployLiquidityPool} from "./deploy/liquidity-pool";
import {deployLaunchpool} from "./deploy/launchpool";
import {createDeployEnvironment, DeployEnvironment} from "./deploy/helpers";
let launchpoolTestingEnvironment: LaunchpoolTestingEnvironment;
let launchpoolsConfigsManagerAddress: ProgramDerivedAddress;
let launchpoolsConfigAddress: ProgramDerivedAddress;
let liquidityPoolTestingEnvironment: LiquidityPoolTestingEnvironment;
let ammsConfigsManagerAddress: ProgramDerivedAddress;
let ammsConfigAddress: ProgramDerivedAddress;
let deployEnv: DeployEnvironment
before(async () =>{
    // Initialize testing environment
    launchpoolTestingEnvironment = await createLaunchpoolTestingEnvironment();
    console.log("Launchpool Program Address:", launchpoolTestingEnvironment.program.LAUNCHPOOL_PROGRAM_ADDRESS);
    deployEnv = await createDeployEnvironment();
    // Fetch the Launchpools Configs Manager PDA
    launchpoolsConfigsManagerAddress = await getLaunchpoolsConfigsManagerPDA();
    console.log("Launchpools Configs Manager PDA:", launchpoolsConfigsManagerAddress);

    // Fetch a specific Launchpools Config PDA (assuming config ID 0)
    launchpoolsConfigAddress = await getLaunchpoolsConfigPDA(BigInt(0));
    console.log("Launchpools Config PDA:", launchpoolsConfigAddress);


    // Initialize testing environment
    liquidityPoolTestingEnvironment = await createLiquidityPoolTestingEnvironment();
    console.log("Liquidity pool Program Address:", liquidityPoolTestingEnvironment.program.LIQUIDITY_POOL_PROGRAM_ADDRESS);

    // Fetch the AMMs Configs Manager PDA
    ammsConfigsManagerAddress = await getAmmsConfigsManagerPDA();
    console.log("AMMs Configs Manager PDA:", ammsConfigsManagerAddress);

    // Fetch a specific AMMs Config PDA (assuming config ID 0)
    ammsConfigAddress = await getAmmsConfigPDA(BigInt(0));
    console.log("AMMs Config PDA:", ammsConfigAddress);
});

it("Launchpool program backend integration tests", async () => {
    deployLiquidityPool(liquidityPoolTestingEnvironment, deployEnv, ammsConfigsManagerAddress, ammsConfigAddress)

    deployLaunchpool(launchpoolTestingEnvironment, deployEnv, launchpoolsConfigsManagerAddress, launchpoolsConfigAddress)

});