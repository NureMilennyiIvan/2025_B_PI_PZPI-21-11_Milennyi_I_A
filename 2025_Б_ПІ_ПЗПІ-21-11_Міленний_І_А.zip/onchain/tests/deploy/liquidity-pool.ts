import {Account, pipe, ProgramDerivedAddress,} from "@solana/kit";
import {SYSTEM_PROGRAM_ADDRESS} from "@solana-program/system";
import {before, describe} from "mocha";
import {assert} from "chai";
import {
    airdropTo,
    createTestUser,
    createTransaction, decodeSignAndSend, delay, getTransactionLogs,
    signAndSendTransaction
} from "../helpers";
import {
    AmmsConfig, AmmsConfigsManager,
    fetchAmmsConfig,
    fetchAmmsConfigsManager, getInitializeAmmsConfigInstruction,
    getInitializeAmmsConfigsManagerInstruction,
    getUpdateAmmsConfigsManagerAuthorityInstruction,
    getUpdateAmmsConfigsManagerHeadAuthorityInstruction,
    InitializeAmmsConfigInput,
    InitializeAmmsConfigsManagerInput,
    UpdateAmmsConfigsManagerAuthorityInput,
    UpdateAmmsConfigsManagerHeadAuthorityInput
} from "@liquidity-pool/js";
import {LiquidityPoolTestingEnvironment} from "../liquidity-pool/helpers";
import {DeployEnvironment} from "./helpers";
import {
    createAtaWithTokens, createAtaWithTokens22, createDropAtaWithTokens,
    createToken22Mint,
    createToken22MintWithPermanentDelegate,
    createToken22MintWithTransferFee,
    createTokenMint, createTokenMintWithKeypair, getToken22PDA, getTokenPDA
} from "../tokens-helpers";
import {initializeAmmsConfig} from "../liquidity-pool/liquidity-pool-integration/helpers";

/**
 * AmmsConfigsManager tests function.
 */
export const deployLiquidityPool = (liquidityPoolTestingEnvironment: LiquidityPoolTestingEnvironment, deployEnv: DeployEnvironment, ammsConfigsManagerAddress: ProgramDerivedAddress,  ammsConfigsAddress: ProgramDerivedAddress) =>{
    describe("\nAmmsConfigsManager tests", () =>{
        const {program, programDataAddress, rpcClient, rent, headAuthority, owner, ammsConfigsManagerAuthority, user} = liquidityPoolTestingEnvironment;
        before(async () => {
            await createTokenMintWithKeypair(rpcClient, owner, deployEnv.VON_KEYPAIR, 6)
            for (const recip of deployEnv.VON_RECIPIENTS) {
                    await airdropTo(rpcClient, 100_000, recip);
                }
            const von_recipients = deployEnv.VON_RECIPIENTS.map(async (recip) => {
                return [recip, await createDropAtaWithTokens(rpcClient, deployEnv.VON_KEYPAIR.address, owner, recip, BigInt(1_000_000_000_000))]
            })
        })
        it("Initialize AmmsConfigsManager", async () => {
            const input: InitializeAmmsConfigsManagerInput = {
                signer: owner,
                ammsConfigsManager: ammsConfigsManagerAddress[0],
                authority: ammsConfigsManagerAuthority.address,
                headAuthority: owner.address,
                programData: programDataAddress,
                liquidityPoolProgram: program.LIQUIDITY_POOL_PROGRAM_ADDRESS,
                rent,
                systemProgram: SYSTEM_PROGRAM_ADDRESS
            };

            const ix = getInitializeAmmsConfigsManagerInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            ).catch((error) => console.log(error));

            const ammsConfigsManagerAccount = await program.fetchAmmsConfigsManager(rpcClient.rpc, ammsConfigsManagerAddress[0]);

            assert.ok(ammsConfigsManagerAccount, "AmmsConfigsManager account was not created");
            assert.strictEqual(ammsConfigsManagerAccount.data.authority, ammsConfigsManagerAuthority.address, "Authority does not match the expected address");
            assert.strictEqual(ammsConfigsManagerAccount.data.headAuthority, owner.address, "Head authority does not match the expected owner address");
            assert.strictEqual(ammsConfigsManagerAccount.data.configsCount, BigInt(0), "Configs count should be initialized to 0");
            assert.strictEqual(ammsConfigsManagerAccount.data.bump, ammsConfigsManagerAddress[1].valueOf(), "Bump value is incorrect");
        })
        it("Initialize AmmsConfig by head authority", async () => {
            const ammsConfigsManagerAccountBefore = await program.fetchAmmsConfigsManager(rpcClient.rpc, ammsConfigsManagerAddress[0]);
            assert.ok(ammsConfigsManagerAccountBefore, "AmmsConfigsManager doesn't exist");

            const protocolFeeRateBasisPoints = 25;
            const providersFeeRateBasisPoints = 50;

            const input: InitializeAmmsConfigInput = {
                authority: owner,
                ammsConfigsManager: ammsConfigsManagerAddress[0],
                ammsConfig: ammsConfigsAddress[0],
                feeAuthority: deployEnv.AMMS_HEAD_AUTHORITY,
                rent: rent,
                systemProgram: SYSTEM_PROGRAM_ADDRESS,
                protocolFeeRateBasisPoints,
                providersFeeRateBasisPoints
            };

            const ix = getInitializeAmmsConfigInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            );
        })
        it("Update AmmsConfigsManager authority by head authority", async () => {
            const ammsConfigsManagerAccountBefore = await program.fetchAmmsConfigsManager(rpcClient.rpc, ammsConfigsManagerAddress[0]);

            assert.ok(ammsConfigsManagerAccountBefore, "AmmsConfigsManager doesn't exist");

            const input: UpdateAmmsConfigsManagerAuthorityInput = {
                authority: owner,
                ammsConfigsManager: ammsConfigsManagerAddress[0],
                newAuthority: deployEnv.AMMS_AUTHORITY
            };

            const ix = getUpdateAmmsConfigsManagerAuthorityInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            )
        })
        it("Update AmmsConfigsManager head authority", async () => {
            const ammsConfigsManagerAccountBefore = await program.fetchAmmsConfigsManager(rpcClient.rpc, ammsConfigsManagerAddress[0]);

            assert.ok(ammsConfigsManagerAccountBefore, "AmmsConfigsManager doesn't exist");

            const input: UpdateAmmsConfigsManagerHeadAuthorityInput = {
                headAuthority: owner,
                ammsConfigsManager: ammsConfigsManagerAddress[0],
                newHeadAuthority: deployEnv.AMMS_HEAD_AUTHORITY
            };

            const ix = getUpdateAmmsConfigsManagerHeadAuthorityInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            )


        })


    })
}