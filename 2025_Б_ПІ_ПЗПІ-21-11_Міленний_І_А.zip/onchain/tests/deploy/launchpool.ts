import {Account, pipe, ProgramDerivedAddress,} from "@solana/kit";
import {SYSTEM_PROGRAM_ADDRESS} from "@solana-program/system";
import {before, describe} from "mocha";
import {assert} from "chai";
import {
    airdropTo,
    createTestUser,
    createTransaction, decodeSignAndSend, delay, getTransactionLogs,
    signAndSendTransaction
} from "../helpers";
import {LiquidityPoolTestingEnvironment} from "../liquidity-pool/helpers";
import {DeployEnvironment} from "./helpers";
import {
    createAtaWithTokens, createAtaWithTokens22, createDropAtaWithTokens,
    createToken22Mint,
    createToken22MintWithPermanentDelegate,
    createToken22MintWithTransferFee,
    createTokenMint, createTokenMintWithKeypair, getToken22PDA, getTokenPDA, mintTokens
} from "../tokens-helpers";
import {initializeAmmsConfig} from "../liquidity-pool/liquidity-pool-integration/helpers";
import {getLaunchpoolPDA, getLaunchpoolVaultPDA, LaunchpoolTestingEnvironment} from "../launchpool/helpers";
import {
    fetchLaunchpool,
    getInitializeLaunchpoolInstruction,
    getInitializeLaunchpoolsConfigInstruction,
    getInitializeLaunchpoolsConfigsManagerInstruction,
    getUpdateLaunchpoolsConfigsManagerAuthorityInstruction,
    getUpdateLaunchpoolsConfigsManagerHeadAuthorityInstruction, InitializeLaunchpoolInput,
    InitializeLaunchpoolsConfigInput,
    InitializeLaunchpoolsConfigsManagerInput,
    LaunchpoolsConfig,
    LaunchpoolsConfigsManager, LaunchpoolStatus,
    UpdateLaunchpoolsConfigsManagerAuthorityInput,
    UpdateLaunchpoolsConfigsManagerHeadAuthorityInput
} from "@launchpool/js";
import {TOKEN_PROGRAM_ADDRESS} from "@solana-program/token";
import {fetchToken as fetchTokenAccount} from "@solana-program/token/dist/types/generated/accounts/token";
import {Mint as TokenMint} from "@solana-program/token/dist/types/generated/accounts/mint";
import {Mint as Token22Mint} from "@solana-program/token-2022/dist/types/generated/accounts/mint";

/**
 * AmmsConfigsManager tests function.
 */
export const deployLaunchpool = (liquidityPoolTestingEnvironment: LaunchpoolTestingEnvironment, deployEnv: DeployEnvironment, launchpoolsConfigsManagerAddress: ProgramDerivedAddress, launchpoolsConfigAddress: ProgramDerivedAddress) => {
    const TEST_LAUNCHPOOLS: {
        rewardMint1: Account<TokenMint>,
        launchpool1: ProgramDerivedAddress,
        rewardVault1: ProgramDerivedAddress,
    } = {
        rewardMint1: undefined,
        launchpool1: undefined,
        rewardVault1: undefined,
    };
    describe("\nAmmsConfigsManager tests", () => {
        const {
            program,
            programDataAddress,
            rpcClient,
            rent,
            headAuthority,
            owner,
            launchpoolsConfigsManagerAuthority,
            user
        } = liquidityPoolTestingEnvironment;

        before(async () => {
            TEST_LAUNCHPOOLS.rewardMint1 = await createTokenMint(rpcClient, owner, 4);
            TEST_LAUNCHPOOLS.launchpool1 = await getLaunchpoolPDA(TEST_LAUNCHPOOLS.rewardMint1.address)
            TEST_LAUNCHPOOLS.rewardVault1 = await getLaunchpoolVaultPDA(TEST_LAUNCHPOOLS.launchpool1[0])
        })
        it("Initialize LaunchpoolsConfigsManager", async () => {
            const input: InitializeLaunchpoolsConfigsManagerInput = {
                signer: owner,
                launchpoolsConfigsManager: launchpoolsConfigsManagerAddress[0],
                authority: launchpoolsConfigsManagerAuthority.address,
                headAuthority: owner.address,
                programData: programDataAddress,
                launchpoolProgram: program.LAUNCHPOOL_PROGRAM_ADDRESS,
                rent,
                systemProgram: SYSTEM_PROGRAM_ADDRESS
            };
            const ix = getInitializeLaunchpoolsConfigsManagerInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            ).catch((error) => console.log(error));
        })
        it("Initialize LaunchpoolsConfig by head authority", async () => {
            const launchpoolsConfigsManagerAccountBefore = await program.fetchLaunchpoolsConfigsManager(rpcClient.rpc, launchpoolsConfigsManagerAddress[0]);
            assert.ok(launchpoolsConfigsManagerAccountBefore, "LaunchpoolsConfigManager doesn't exist");

            const protocolRewardShareBasisPoints = 500;
            const duration = BigInt(600);
            const maxPositionSize = BigInt(100000_000000);
            const minPositionSize = BigInt(10000_000000);
            const stakableMint = deployEnv.VON_KEYPAIR.address;

            const input: InitializeLaunchpoolsConfigInput = {
                authority: owner,
                launchpoolsConfigsManager: launchpoolsConfigsManagerAddress[0],
                launchpoolsConfig: launchpoolsConfigAddress[0],
                rewardAuthority: deployEnv.LAUNCHPOOLS_HEAD_AUTHORITY,
                stakableMint,
                rent: rent,
                systemProgram: SYSTEM_PROGRAM_ADDRESS,
                duration,
                maxPositionSize,
                minPositionSize,
                protocolRewardShareBasisPoints
            };

            const ix = getInitializeLaunchpoolsConfigInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            );
        })
        it("Authorized initialization of Launchpool by head authority", async () => {
            let initialRewardAmount = 100_000_000_000n;

            const input: InitializeLaunchpoolInput = {
                authority: owner,
                launchpoolsConfigsManager: launchpoolsConfigsManagerAddress[0],
                launchpoolsConfig: launchpoolsConfigAddress[0],
                rewardMint: TEST_LAUNCHPOOLS.rewardMint1.address,
                launchpool: TEST_LAUNCHPOOLS.launchpool1[0],
                rewardVault: TEST_LAUNCHPOOLS.rewardVault1[0],
                rent,
                systemProgram: SYSTEM_PROGRAM_ADDRESS,
                rewardTokenProgram: TOKEN_PROGRAM_ADDRESS,
                initialRewardAmount
            }
            let ix = getInitializeLaunchpoolInstruction(input);
            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            );
            await mintTokens(rpcClient, owner, TEST_LAUNCHPOOLS.rewardVault1[0], TEST_LAUNCHPOOLS.rewardMint1.address, 100_000_000_000n)
        });
        it("Update LaunchpoolsConfigsManager authority by head authority", async () => {
            const launchpoolsConfigsManagerAccountBefore = await program.fetchLaunchpoolsConfigsManager(rpcClient.rpc, launchpoolsConfigsManagerAddress[0]);

            assert.ok(launchpoolsConfigsManagerAccountBefore, "LaunchpoolsConfigsManager doesn't exist");

            const input: UpdateLaunchpoolsConfigsManagerAuthorityInput = {
                authority: owner,
                launchpoolsConfigsManager: launchpoolsConfigsManagerAddress[0],
                newAuthority: deployEnv.LAUNCHPOOLS_AUTHORITY
            };

            const ix = getUpdateLaunchpoolsConfigsManagerAuthorityInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            )
        })
        it("Update LaunchpoolsConfigsManager head authority", async () => {
            const launchpoolsConfigsManagerAccountBefore = await program.fetchLaunchpoolsConfigsManager(rpcClient.rpc, launchpoolsConfigsManagerAddress[0]);

            assert.ok(launchpoolsConfigsManagerAccountBefore, "LaunchpoolsConfigsManager doesn't exist");

            const input: UpdateLaunchpoolsConfigsManagerHeadAuthorityInput = {
                headAuthority: owner,
                launchpoolsConfigsManager: launchpoolsConfigsManagerAddress[0],
                newHeadAuthority: deployEnv.LAUNCHPOOLS_HEAD_AUTHORITY
            };
            const ix = getUpdateLaunchpoolsConfigsManagerHeadAuthorityInstruction(input);

            await pipe(
                await createTransaction(rpcClient, owner, [ix]),
                (tx) => signAndSendTransaction(rpcClient, tx)
            )
        })


    })
}