import {createTestUser, requireEnv, RpcClient} from "../helpers";
import {
    address,
    Address,
    createKeyPairSignerFromBytes,
    createSolanaRpc,
    createSolanaRpcSubscriptions,
    KeyPairSigner
} from "@solana/kit";
import {config as loadEnv} from "dotenv";
import path from "path";
import fs from "fs";
import {LiquidityPoolBackendIntegrationTestingEnvironment} from "../liquidity-pool/liquidity-pool-integration/helpers";
loadEnv({
    path: path.resolve(__dirname, ".env"),
});
export type DeployEnvironment = {
    AMMS_HEAD_AUTHORITY: Address,
    AMMS_AUTHORITY: Address,
    LAUNCHPOOLS_HEAD_AUTHORITY: Address,
    LAUNCHPOOLS_AUTHORITY: Address,
    VON_RECIPIENTS: Address[],
    VON_KEYPAIR: KeyPairSigner
};

export const createDeployEnvironment = async (): Promise<DeployEnvironment> => {
    const von_keypair = await createKeyPairSignerFromBytes(Buffer.from(JSON.parse(fs.readFileSync("../VoNYfzVngsf9NkQgYVwfBMrQKa23TTRk6TGmvKHse9g.json", 'utf8'))));
    const environment = {
        AMMS_HEAD_AUTHORITY: address(requireEnv("AMMS_HEAD_AUTHORITY")),
        AMMS_AUTHORITY: address(requireEnv("AMMS_AUTHORITY")),
        LAUNCHPOOLS_HEAD_AUTHORITY: address(requireEnv("LAUNCHPOOLS_HEAD_AUTHORITY")),
        LAUNCHPOOLS_AUTHORITY: address(requireEnv("LAUNCHPOOLS_AUTHORITY")),
        VON_RECIPIENTS: requireEnv("VON_RECIPIENTS").split(',').map((add) => address(add)),
        VON_KEYPAIR: von_keypair
    };

    return environment;
};
