use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow, Serialize)]
pub struct CpAmmRow {
    pub cp_amm: String,
    pub amms_config: String,
    pub base_mint: String,
    pub quote_mint: String,
    pub lp_mint: String
}

#[derive(DeserializeRow)]
pub struct CpAmmByBaseOrQuote {
    pub cp_amm: String,
    pub amms_config: String,
    pub base_or_quote_mint: String,
    pub remaining_mint: String,
    pub lp_mint: String,
}

impl From<CpAmmByBaseOrQuote> for CpAmmRow {
    fn from(value: CpAmmByBaseOrQuote) -> Self {
        Self {
            cp_amm: value.cp_amm,
            amms_config: value.amms_config,
            base_mint: value.base_or_quote_mint,
            quote_mint: value.remaining_mint,
            lp_mint: value.lp_mint,
        }
    }
}
