use crate::utils::clients::models::TokenMint;
use liquidity_pool::accounts::{AmmsConfig, CpAmm};
use serde::Serialize;
use utilities::math::{Q64_128, U192};

#[derive(Serialize)]
pub struct CpAmmVM {
    pub amms_config: String,
    pub base_mint: String,
    pub quote_mint: String,
    pub lp_mint: String,
    pub fee_authority: String,
    pub base_token_data: (TokenMint, Option<String>),
    pub quote_token_data: (TokenMint, Option<String>),
    pub lp_token_data: (TokenMint, Option<String>),
    pub constant_product: String,
    pub base_quote_ratio: String,
    pub base_liquidity: String,
    pub quote_liquidity: String,
    pub lp_tokens_supply: String,
    pub protocol_base_fees_to_redeem: String,
    pub protocol_quote_fees_to_redeem: String,
    pub providers_fee_rate_basis_points: u16,
    pub protocol_fee_rate_basis_points: u16,
}
impl CpAmmVM {
    pub fn new(
        cp_amm: CpAmm,
        amms_config: AmmsConfig,
        base_token_data: (TokenMint, Option<String>),
        quote_token_data: (TokenMint, Option<String>),
        lp_token_data: (TokenMint, Option<String>),
    ) -> Self {
        let constant_product_sqrt = Q64_128::new(U192([
            cp_amm.constant_product_sqrt.value[0],
            cp_amm.constant_product_sqrt.value[1],
            cp_amm.constant_product_sqrt.value[2],
        ]));
        let base_quote_ratio_sqrt = Q64_128::new(U192([
            cp_amm.base_quote_ratio_sqrt.value[0],
            cp_amm.base_quote_ratio_sqrt.value[1],
            cp_amm.base_quote_ratio_sqrt.value[2],
        ]));
        Self {
            amms_config: cp_amm.amms_config.to_string(),
            base_mint: cp_amm.base_mint.to_string(),
            quote_mint: cp_amm.quote_mint.to_string(),
            lp_mint: cp_amm.lp_mint.to_string(),
            fee_authority: amms_config.fee_authority.to_string(),
            base_token_data,
            quote_token_data,
            lp_token_data,
            constant_product: constant_product_sqrt.square_as_u128().to_string(),
            base_quote_ratio: f64::from(base_quote_ratio_sqrt.saturating_mul(base_quote_ratio_sqrt)).to_string(),
            base_liquidity: cp_amm.base_liquidity.to_string(),
            quote_liquidity: cp_amm.quote_liquidity.to_string(),
            lp_tokens_supply: cp_amm.lp_tokens_supply.to_string(),
            protocol_base_fees_to_redeem: cp_amm.protocol_base_fees_to_redeem.to_string(),
            protocol_quote_fees_to_redeem: cp_amm.protocol_quote_fees_to_redeem.to_string(),
            providers_fee_rate_basis_points: amms_config.providers_fee_rate_basis_points,
            protocol_fee_rate_basis_points: amms_config.protocol_fee_rate_basis_points,
        }
    }
}
