use scylla::DeserializeRow;
use scylla::value::CqlTimeuuid;
use serde::Serialize;

#[derive(Serialize, Debug)]
pub struct Trade {
    pub signature: String,
    pub timestamp: i64,
    pub swapper: String,
    pub cp_amm: String,
    pub swapped_amount: String,
    pub received_amount: String,
    pub is_in_out: bool,
}

#[derive(DeserializeRow)]
pub struct TradeScylla {
    pub signature: String,
    pub timestamp: i64,
    pub event_id: CqlTimeuuid,
    pub cp_amm: String,
    pub swapper: String,
    pub swapped_amount: Vec<u8>,
    pub received_amount: Vec<u8>,
    pub is_in_out: bool,
}

impl From<TradeScylla> for Trade {
    fn from(trade: TradeScylla) -> Self {
        Self{
            signature: trade.signature,
            timestamp: trade.timestamp,
            swapper: trade.swapper,
            cp_amm: trade.cp_amm,
            swapped_amount: u64::from_be_bytes(trade.swapped_amount.try_into().ok().unwrap()).to_string(),
            received_amount: u64::from_be_bytes(trade.received_amount.try_into().ok().unwrap()).to_string(),
            is_in_out: trade.is_in_out,
        }
    }
}