use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow, Serialize)]
pub struct AmmsConfigAddress {
    pub amms_config: String,
}