use serde::{Serialize};
use solana_sdk::pubkey::{Pubkey};
use liquidity_pool::accounts::AmmsConfigsManager;
use crate::liquidity_pool::core::address_derive::get_amms_configs_manager_pda;

#[derive(Serialize)]
pub struct AmmsConfigsManagerVM{
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub key: Pubkey,
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub authority: Pubkey,
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub head_authority: Pubkey,
}

impl From<AmmsConfigsManager> for AmmsConfigsManagerVM{

    fn from(value: AmmsConfigsManager) -> Self {
        Self{
            key: get_amms_configs_manager_pda().0,
            authority: value.authority,
            head_authority: value.head_authority
        }
    }
}