use serde::{Serialize};
use solana_sdk::pubkey::Pubkey;
use liquidity_pool::accounts::AmmsConfig;
use crate::liquidity_pool::core::address_derive::get_amms_config_pda;

#[derive(Serialize)]
pub struct AmmsConfigVM{
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub key: Pubkey,
    pub fee_authority: String,
    pub protocol_fee_rate_basis_points: u16,
    pub providers_fee_rate_basis_points: u16
}

impl From<AmmsConfig> for AmmsConfigVM{

    fn from(value: AmmsConfig) -> Self {
        Self{
            key: get_amms_config_pda(value.id).0,
            fee_authority: value.fee_authority.to_string(),
            protocol_fee_rate_basis_points: value.protocol_fee_rate_basis_points,
            providers_fee_rate_basis_points: value.providers_fee_rate_basis_points,
        }
    }
}