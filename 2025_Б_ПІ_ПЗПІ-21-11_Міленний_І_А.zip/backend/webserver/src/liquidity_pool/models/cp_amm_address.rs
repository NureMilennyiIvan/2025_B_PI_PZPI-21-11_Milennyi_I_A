use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow)]
pub struct CpAmmAddress {
    pub cp_amm: String,
}