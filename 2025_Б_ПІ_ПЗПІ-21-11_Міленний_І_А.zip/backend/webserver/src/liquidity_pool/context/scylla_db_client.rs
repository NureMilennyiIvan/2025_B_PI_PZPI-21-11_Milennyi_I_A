use scylla::client::session::Session;
use solana_sdk::pubkey::Pubkey;
use anyhow::{Context, Result as AnyResult, Error as AnyError};
use scylla::_macro_internal::DeserializationError;
use scylla::value::CqlTimeuuid;
use tokio::{join, try_join};
use tracing::debug;
use liquidity_pool::accounts::AmmsConfig;
use crate::launchpool::view_models::{LaunchpoolRow, LaunchpoolsConfigAddress};
use crate::utils::clients::ScyllaDbClient;
use crate::liquidity_pool::models::{CpAmmKeys, CpAmmKeysScylla};
use crate::liquidity_pool::view_models::{AmmsConfigAddress, CpAmmByBaseOrQuote, CpAmmRow, TradeScylla};

pub struct LiquidityPoolScyllaDbClient {
    liquidity_pool_session: Session
}
impl LiquidityPoolScyllaDbClient {
    pub fn new(liquidity_pool_session: Session) -> Self {
        Self{
            liquidity_pool_session
        }
    }

    pub async fn fetch_amms_configs_addresses(
        &self,
        limit: Option<u32>,
    ) -> AnyResult<Vec<AmmsConfigAddress>> {
        let rows = match limit {
            Some(limit) => self
                .liquidity_pool_session
                .query_unpaged(
                    "SELECT amms_config FROM init_amms_config_events LIMIT ?",
                    (limit as i64,),
                )
                .await,
            None => {
                self.liquidity_pool_session
                    .query_unpaged(
                        "SELECT amms_config FROM init_amms_config_events",
                        (),
                    )
                    .await
            }
        }
            .context("failed to fetch amms_config addresses")?
            .into_rows_result()?;

        debug!(
            ?limit,
            rows = rows.rows_num(),
            "Fetched amms_config addresses rows"
        );

        if rows.rows_num() == 0 {
            return Ok(vec![]);
        }
        let addresses: Result<Vec<AmmsConfigAddress>, DeserializationError> =
            rows.rows::<AmmsConfigAddress>()?.collect();
        Ok(addresses?)
    }

    pub async fn fetch_cp_amm_keys(&self, cp_amm: &Pubkey) -> AnyResult<Option<CpAmmKeys>> {
        let rows = self
            .session()
            .query_unpaged("SELECT amms_config, base_mint, quote_mint, lp_mint FROM cp_amms_keys WHERE cp_amm = ?", (cp_amm.to_string(),))
            .await
            .context("failed to fetch cp_amm_keys")?
            .into_rows_result()?;

        debug!(?cp_amm, rows = rows.rows_num(), "Fetched cp amm keys rows");

        if rows.rows_num() == 0{
            return Ok(None);
        }
        let cp_amm_keys: CpAmmKeys = rows.first_row::<CpAmmKeysScylla>()?.try_into()?;
        debug!(?cp_amm, "Parsed CpAmmKeys");
        Ok(Some(cp_amm_keys))
    }

    pub async fn fetch_cp_amm_rows_by_base_or_quote_mint(&self, limit: Option<u32>, base_mint: Option<Pubkey>, quote_mint: Option<Pubkey>) -> AnyResult<Vec<CpAmmRow>> {
        let limit_query = limit.map(|limit| format!(" LIMIT {}", limit)).unwrap_or(String::new());
        let cp_amms = match (base_mint, quote_mint) {
            (Some(base_mint), Some(quote_mint)) => {
                let session = self.session();
                let query1 = format!("SELECT cp_amm, amms_config, base_mint, quote_mint, lp_mint FROM launched_cp_amms_by_base_and_quote WHERE base_mint = ? AND quote_mint = ?{}", limit_query);
                let query2 = query1.clone();
                let (rows1, rows2) = try_join!(
                    async {
                        session
                            .query_unpaged(query1, (base_mint.to_string(), quote_mint.to_string(),))
                            .await?
                            .into_rows_result()?
                            .rows::<CpAmmRow>()?
                            .map(|row| row.map_err(AnyError::from)).collect::<Result<Vec<CpAmmRow>, AnyError>>()
                    },
                    async {
                        session
                            .query_unpaged(query2, (quote_mint.to_string(), base_mint.to_string(),))
                            .await?
                            .into_rows_result()?
                            .rows::<CpAmmRow>()?
                            .map(|row| row.map_err(AnyError::from)).collect::<Result<Vec<CpAmmRow>, AnyError>>()
                    }
                ).context("failed to fetch cp_amm_rows")?;
                rows1.into_iter().chain(rows2).take(limit.map(|l| l as usize).unwrap_or(usize::MAX)).collect()
            },
            (Some(base_mint), None) => {
                let query = format!("SELECT cp_amm, amms_config, base_or_quote_mint, remaining_mint, lp_mint FROM launched_cp_amms_by_base_or_quote WHERE base_or_quote_mint = ?{}", limit_query);
                self.session()
                    .query_unpaged(query, (base_mint.to_string(),)).await
                    .context("failed to fetch cp_amm_rows")?
                    .into_rows_result()?
                    .rows::<CpAmmByBaseOrQuote>()?.map(|row| row.map(|cp_amm| cp_amm.into())).collect::<Result<Vec<CpAmmRow>, DeserializationError>>()?
            },
            (None, Some(quote_mint)) => {
                let query = format!("SELECT cp_amm, amms_config, base_or_quote_mint, remaining_mint, lp_mint FROM launched_cp_amms_by_base_or_quote WHERE base_or_quote_mint = ?{}", limit_query);
                self.session()
                    .query_unpaged(query, (quote_mint.to_string(),)).await
                    .context("failed to fetch cp_amm_rows")?
                    .into_rows_result()?
                    .rows::<CpAmmByBaseOrQuote>()?.map(|row| row.map(|cp_amm| cp_amm.into())).collect::<Result<Vec<CpAmmRow>, DeserializationError>>()?
            },
            (None, None) => {
                let query = format!("SELECT cp_amm, amms_config, base_mint, quote_mint, lp_mint FROM launched_cp_amms{}", limit_query);
                self.session()
                    .query_unpaged(query, ()).await
                    .context("failed to fetch cp_amm_rows")?
                    .into_rows_result()?
                    .rows::<CpAmmRow>()?.collect::<Result<Vec<CpAmmRow>, DeserializationError>>()?
            }
        };
        debug!(?limit, ?base_mint, ?quote_mint, cp_amm_rows = cp_amms.len(), "Fetched cp_amm_rows");
        Ok(cp_amms)
    }

    pub async fn fetch_cp_amm_trades(&self, cp_amm: &Pubkey, last_uuid: Option<CqlTimeuuid>) -> AnyResult<Vec<TradeScylla>> {
        let query_with_uuid = "SELECT signature, timestamp, event_id, cp_amm, swapper, swapped_amount, received_amount, is_in_out \
                           FROM trades_by_cp_amm \
                           WHERE cp_amm = ? AND event_id > ?";

        let query_without_uuid = "SELECT signature, timestamp, event_id, cp_amm, swapper, swapped_amount, received_amount, is_in_out \
                              FROM trades_by_cp_amm \
                              WHERE cp_amm = ?";

        let rows = match last_uuid {
            Some(uuid) => {
                self.session()
                    .query_unpaged(query_with_uuid, (cp_amm.to_string(), uuid))
                    .await
                    .context("failed to fetch cp_amm_trades (with uuid)")?
            }
            _ => {
                self.session()
                    .query_unpaged(query_without_uuid, (cp_amm.to_string(),))
                    .await
                    .context("failed to fetch cp_amm_trades (without uuid)")?
            }
        }.into_rows_result()?;

        debug!(?cp_amm, rows = rows.rows_num(), "Fetched cp amm trades rows");

        let trades = rows.rows::<TradeScylla>()?.collect::<Result<Vec<TradeScylla>, DeserializationError>>()?;
        debug!(?cp_amm, "Parsed TradeScylla");
        Ok(trades)
    }
    pub async fn fetch_user_trades(&self, cp_amm: &Pubkey, last_uuid: Option<CqlTimeuuid>) -> AnyResult<Vec<TradeScylla>> {
        let query_with_uuid = "SELECT signature, timestamp, event_id, cp_amm, swapper, swapped_amount, received_amount, is_in_out \
                           FROM trades_by_user \
                           WHERE swapper = ? AND event_id > ?";

        let query_without_uuid = "SELECT signature, timestamp, event_id, cp_amm, swapper, swapped_amount, received_amount, is_in_out \
                              FROM trades_by_user \
                              WHERE swapper = ?";

        let rows = match last_uuid {
            Some(uuid) => {
                self.session()
                    .query_unpaged(query_with_uuid, (cp_amm.to_string(), uuid))
                    .await
                    .context("failed to fetch user_trades (with uuid)")?
            }
            _ => {
                self.session()
                    .query_unpaged(query_without_uuid, (cp_amm.to_string(),))
                    .await
                    .context("failed to fetch user_trades (without uuid)")?
            }
        }.into_rows_result()?;

        debug!(?cp_amm, rows = rows.rows_num(), "Fetched user trades rows");

        let trades = rows.rows::<TradeScylla>()?.collect::<Result<Vec<TradeScylla>, DeserializationError>>()?;
        debug!(?cp_amm, "Parsed TradeScylla");
        Ok(trades)
    }
}
impl ScyllaDbClient for LiquidityPoolScyllaDbClient {
    fn session(&self) -> &Session{
        &self.liquidity_pool_session
    }
}