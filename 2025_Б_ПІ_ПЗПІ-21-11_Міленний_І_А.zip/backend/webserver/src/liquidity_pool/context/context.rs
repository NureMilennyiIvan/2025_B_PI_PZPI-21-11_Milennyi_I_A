use std::ops::Deref;
use std::str::FromStr;
use super::{LiquidityPoolScyllaDbClient, LiquidityPoolSolanaRpcClient};
use crate::liquidity_pool::models::CpAmmKeys;
use crate::utils::clients::{CacheRegistry, ProgramContext};
use anyhow::{anyhow, Context, Result as AnyResult};
use async_trait::async_trait;
use solana_sdk::pubkey::Pubkey;
use std::sync::Arc;
use futures::future::try_join;
use scylla::value::CqlTimeuuid;
use tracing::debug;
use launchpool::accounts::Launchpool;
use liquidity_pool::accounts::CpAmm;
use crate::launchpool::core::address_derive::get_launchpools_configs_manager_pda;
use crate::launchpool::models::LaunchpoolKeys;
use crate::launchpool::view_models::{LaunchpoolsConfigAddress, LaunchpoolsConfigVM, LaunchpoolsConfigsManagerVM};
use crate::liquidity_pool::core::address_derive::get_amms_configs_manager_pda;
use crate::liquidity_pool::view_models::{AmmsConfigAddress, AmmsConfigVM, AmmsConfigsManagerVM, CpAmmRow, CpAmmVM, TradeScylla};

pub struct LiquidityPoolContext {
    solana_rpc_client: Arc<LiquidityPoolSolanaRpcClient>,
    scylla_db_client: Arc<LiquidityPoolScyllaDbClient>,
    cache_registry: Arc<CacheRegistry>,
}

impl LiquidityPoolContext {
    pub fn new(
        solana_rpc_client: Arc<LiquidityPoolSolanaRpcClient>,
        scylla_db_client: Arc<LiquidityPoolScyllaDbClient>,
        cache_registry: Arc<CacheRegistry>,
    ) -> Self {
        Self {
            solana_rpc_client,
            scylla_db_client,
            cache_registry
        }
    }
    pub async fn get_amms_configs_manager_vm(&self) -> AnyResult<AmmsConfigsManagerVM>{
        let key = get_amms_configs_manager_pda().0;
        let manager = self.solana_rpc_client.fetch_amms_configs_manager(&key).await?;
        Ok(manager.into())
    }
    pub async fn get_amms_config_vm(&self, launchpools_config_key: &Pubkey) -> AnyResult<AmmsConfigVM>{
        let config = self.solana_rpc_client.fetch_amms_config(&launchpools_config_key).await?;
        Ok(config.into())
    }
    pub async fn get_amms_configs_addresses(&self, limit: Option<u32>) -> AnyResult<Vec<AmmsConfigAddress>> {
        self.scylla_db_client().fetch_amms_configs_addresses(limit).await
    }
    pub async fn get_amms_config_vms(&self, limit: Option<u32>) -> AnyResult<Vec<AmmsConfigVM>> {
        let addresses = self.get_amms_configs_addresses(limit).await?.into_iter().map(|address| Pubkey::from_str(address.amms_config.as_str())).collect::<Result<Vec<_>, _>>()?;
        self.solana_rpc_client().fetch_amms_configs(&addresses).await.map(|vms| vms.into_iter().map(|config| config.into()).collect::<Vec<AmmsConfigVM>>())
    }
    pub async fn get_launched_cp_amm_rows(&self, limit: Option<u32>, base_mint: Option<Pubkey>, quote_mint: Option<Pubkey>) -> AnyResult<Vec<CpAmmRow>> {
        let scylla_db_client = self.scylla_db_client.clone();
        scylla_db_client.fetch_cp_amm_rows_by_base_or_quote_mint(limit, base_mint, quote_mint).await
    }
    pub async fn get_cp_amm_keys(&self, cp_amm_key: &Pubkey) -> AnyResult<Arc<CpAmmKeys>> {
        debug!(?cp_amm_key, "Fetching cp amm keys from cp_amm_keys_cache");
        let cp_amm_keys_cache = self
            .cache_registry()
            .get::<Pubkey, Arc<CpAmmKeys>>("cp_amm_keys_cache")
            .expect("cp_amm_keys_cache must be registered");
        if let Some(cp_amm_keys) = cp_amm_keys_cache.get(cp_amm_key).await {
            debug!(?cp_amm_key, "Fetched cp amm keys");
            return Ok(cp_amm_keys);
        }

        debug!(?cp_amm_key, "CpAmm keys not in cp_amm_keys_cache — fetching from Events Storage");
        if let Some(cp_amm_keys) = self
            .scylla_db_client()
            .fetch_cp_amm_keys(cp_amm_key)
            .await
            .ok()
            .flatten()
            .map(Arc::new)
        {
            cp_amm_keys_cache
                .insert(*cp_amm_key, cp_amm_keys.clone())
                .await;
            return Ok(cp_amm_keys);
        }
        debug!(?cp_amm_key, "CpAmm keys not in Events Storage — fetching from Solana");
        let cp_amm_account = self.solana_rpc_client().fetch_cp_amm(cp_amm_key).await?;

        let cp_amm_keys = Arc::new(CpAmmKeys::from(cp_amm_account));
        cp_amm_keys_cache
            .insert(*cp_amm_key, cp_amm_keys.clone())
            .await;

        Ok(cp_amm_keys)
    }
    pub async fn get_cp_amm_vm(&self, cp_amm_key: &Pubkey, user: &Option<Pubkey>) -> AnyResult<CpAmmVM>{
        let cp_amm_keys = self.get_cp_amm_keys(cp_amm_key).await?;
        let solana_rpc_client = self.solana_rpc_client().clone();
        let (cp_amm, amms_config, base_token_with_ata, quote_token_with_ata, lp_token_with_ata) = tokio::try_join!(
            solana_rpc_client.fetch_cp_amm(cp_amm_key),
            solana_rpc_client.fetch_amms_config(&cp_amm_keys.amms_config),
            self.get_token_with_ata_balance(&cp_amm_keys.base_mint, user),
            self.get_token_with_ata_balance(&cp_amm_keys.quote_mint, user),
            self.get_token_with_ata_balance(&cp_amm_keys.lp_mint, user)
        )?;
        Ok(CpAmmVM::new(cp_amm, amms_config, base_token_with_ata.ok_or(anyhow!("missing token mint"))?, quote_token_with_ata.ok_or(anyhow!("missing token mint"))?, lp_token_with_ata.ok_or(anyhow!("missing token mint"))?))
    }
    pub async fn get_new_cp_amm_trades(&self, cp_amm_key: &Pubkey, last_uuid: Option<CqlTimeuuid>) -> AnyResult<Vec<TradeScylla>>{
        self.scylla_db_client().fetch_cp_amm_trades(cp_amm_key, last_uuid).await
    }
    pub async fn get_new_user_trades(&self, user: &Pubkey, last_uuid: Option<CqlTimeuuid>) -> AnyResult<Vec<TradeScylla>>{
        self.scylla_db_client().fetch_user_trades(user, last_uuid).await
    }
}
#[async_trait]
impl ProgramContext<LiquidityPoolScyllaDbClient, LiquidityPoolSolanaRpcClient>
    for LiquidityPoolContext
{
    fn scylla_db_client(&self) -> Arc<LiquidityPoolScyllaDbClient> {
        self.scylla_db_client.clone()
    }

    fn solana_rpc_client(&self) -> Arc<LiquidityPoolSolanaRpcClient> {
        self.solana_rpc_client.clone()
    }

    fn cache_registry(&self) -> Arc<CacheRegistry> {
        self.cache_registry.clone()
    }
}
