use serde::Deserialize;
use solana_sdk::pubkey::Pubkey;
use crate::utils::serde::option_pubkey_from_str;
#[derive(Deserialize)]
pub struct FetchAmmsConfigsAddressesPayload {
    pub limit: Option<u32>
}

#[derive(Deserialize)]
pub struct FetchLaunchedCpAmmRowsPayload {
    pub limit: Option<u32>,
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub base_mint: Option<Pubkey>,
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub quote_mint: Option<Pubkey>,
}

#[derive(Deserialize)]
pub struct FetchTokenWithAtaPayload {
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub user: Option<Pubkey>
}

#[derive(Deserialize)]
pub struct FetchAmmsConfigsVMsPayload {
    pub limit: Option<u32>
}

#[derive(Deserialize)]
pub struct FetchCpAmmVMPayload {
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub user: Option<Pubkey>
}