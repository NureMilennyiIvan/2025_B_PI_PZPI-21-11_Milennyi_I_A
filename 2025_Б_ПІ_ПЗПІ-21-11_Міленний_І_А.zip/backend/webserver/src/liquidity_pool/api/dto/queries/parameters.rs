use serde::Deserialize;
use solana_sdk::pubkey::Pubkey;
use crate::utils::serde::pubkey_from_str;
#[derive(Deserialize)]
pub struct FetchAmmsConfigVMParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub amms_config: Pubkey
}

#[derive(Deserialize)]
pub struct FetchTokenWithAtaParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub mint: Pubkey
}

#[derive(Deserialize)]
pub struct FetchCpAmmVMParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub cp_amm: Pubkey
}