use serde::Deserialize;
use solana_sdk::pubkey::Pubkey;
use crate::utils::serde::*;
#[derive(Deserialize)]
pub struct CpAmmTradesParams {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub cp_amm: Pubkey,
}

#[derive(Deserialize)]
pub struct UserTradesParams {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub user: Pubkey,
}
