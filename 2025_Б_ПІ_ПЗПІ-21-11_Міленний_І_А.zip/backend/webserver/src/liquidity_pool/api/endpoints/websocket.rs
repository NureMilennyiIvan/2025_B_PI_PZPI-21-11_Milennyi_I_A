use std::sync::Arc;
use std::time::Duration;
use axum::Error;
use axum::extract::{Path, WebSocketUpgrade, State};
use axum::extract::ws::Message;
use axum::response::IntoResponse;
use moka::ops::compute::Op;
use scylla::value::CqlTimeuuid;
use solana_sdk::pubkey::Pubkey;
use tokio::time::sleep;
use tracing::warn;
use crate::liquidity_pool::api::dto::websockets::parameters::{CpAmmTradesParams, UserTradesParams};
use crate::liquidity_pool::context::LiquidityPoolContext;
use crate::liquidity_pool::view_models::Trade;

pub async fn cp_amm_trades_ws(
    ws: WebSocketUpgrade,
    State(context): State<Arc<LiquidityPoolContext>>,
    Path(params): Path<CpAmmTradesParams>,
) -> impl IntoResponse {
    let CpAmmTradesParams { cp_amm } = params;
    ws.on_upgrade(move |socket| handle_cp_amm_trades_ws(socket, context, cp_amm))
}

async fn handle_cp_amm_trades_ws(
    mut socket: axum::extract::ws::WebSocket,
    context: Arc<LiquidityPoolContext>,
    cp_amm: Pubkey,
) {
    let mut last_uuid: Option<CqlTimeuuid> = None;
    loop {
        let maybe_msg = tokio::time::timeout(Duration::from_secs(2), socket.recv()).await;

        match maybe_msg {
            Ok(Some(Ok(_msg))) => {
            }
            Ok(Some(Err(e))) => {
                warn!(?e, "WebSocket receive error");
                break;
            }
            Ok(None) => {
                break;
            }
            Err(_) => {
            }
        }
        let new_trades = match context.get_new_cp_amm_trades(&cp_amm, last_uuid).await {
            Ok(trades) => trades,
            Err(err) => {
                warn!(?err, "Failed to fetch new trades");
                break;
            }
        };

        if !new_trades.is_empty() {
            last_uuid = new_trades.iter().map(|t| t.event_id).max();
            let trades = new_trades.into_iter().map(|t| t.into()).collect::<Vec<Trade>>();

            if let Ok(text) = serde_json::to_string(&trades) {
                if let Err(e) = socket.send(Message::Text(text.into())).await {
                    warn!(?e, "Failed to send trade");
                    break;
                }
            }
        }
    }
}

pub async fn user_trades_ws(
    ws: WebSocketUpgrade,
    State(context): State<Arc<LiquidityPoolContext>>,
    Path(params): Path<UserTradesParams>,
) -> impl IntoResponse {
    let UserTradesParams { user } = params;
    ws.on_upgrade(move |socket| handle_user_trades_ws(socket, context, user))
}

async fn handle_user_trades_ws(
    mut socket: axum::extract::ws::WebSocket,
    context: Arc<LiquidityPoolContext>,
    user: Pubkey,
) {
    let mut last_uuid: Option<CqlTimeuuid> = None;
    loop {
        let maybe_msg = tokio::time::timeout(Duration::from_secs(2), socket.recv()).await;

        match maybe_msg {
            Ok(Some(Ok(_msg))) => {
            }
            Ok(Some(Err(e))) => {
                warn!(?e, "WebSocket receive error");
                break;
            }
            Ok(None) => {
                break;
            }
            Err(_) => {
            }
        }
        let new_trades = match context.get_new_user_trades(&user, last_uuid).await {
            Ok(trades) => trades,
            Err(err) => {
                warn!(?err, "Failed to fetch new trades");
                break;
            }
        };

        if !new_trades.is_empty() {
            last_uuid = new_trades.iter().map(|t| t.event_id).max();
            let trades = new_trades.into_iter().map(|t| t.into()).collect::<Vec<Trade>>();

            if let Ok(text) = serde_json::to_string(&trades) {
                if let Err(e) = socket.send(Message::Text(text.into())).await {
                    warn!(?e, "Failed to send trade");
                    break;
                }
            }
        }
    }
}
