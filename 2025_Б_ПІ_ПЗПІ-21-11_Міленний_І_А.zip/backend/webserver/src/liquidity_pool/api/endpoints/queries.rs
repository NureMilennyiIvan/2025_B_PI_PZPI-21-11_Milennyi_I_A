use std::sync::Arc;
use axum::extract::{Path, State};
use axum::Json;
use axum::response::IntoResponse;
use tracing::debug;
use crate::launchpool::api::dto::queries::parameters::FetchLaunchpoolsConfigVMParameters;
use crate::launchpool::api::dto::queries::payloads::{FetchActiveLaunchpoolRowsPayload, FetchLaunchpoolsConfigsAddressesPayload};
use crate::launchpool::api::dto::transactions::payloads::UpdateLaunchpoolsConfigsManagerAuthorityPayload;
use crate::launchpool::context::LaunchpoolContext;
use crate::launchpool::core::update_launchpools_configs_manager_authority_tx;
use crate::liquidity_pool::api::dto::queries::parameters::{FetchAmmsConfigVMParameters, FetchCpAmmVMParameters, FetchTokenWithAtaParameters};
use crate::liquidity_pool::api::dto::queries::payloads::{FetchAmmsConfigsAddressesPayload, FetchAmmsConfigsVMsPayload, FetchCpAmmVMPayload, FetchLaunchedCpAmmRowsPayload, FetchTokenWithAtaPayload};
use crate::liquidity_pool::context::LiquidityPoolContext;
use crate::utils::clients::ProgramContext;
use crate::utils::web::send_result;

pub async fn fetch_amms_configs_manager_vm(
    State(context): State<Arc<LiquidityPoolContext>>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_amms_configs_manager_vm"
    );
    let result = context.get_amms_configs_manager_vm().await;
    send_result(result)
}
pub async fn fetch_amms_configs_addresses(
    State(context): State<Arc<LiquidityPoolContext>>,
    Json(payload): Json<FetchAmmsConfigsAddressesPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_amms_configs_addresses"
    );
    let FetchAmmsConfigsAddressesPayload {limit} = payload;
    let result = context.get_amms_configs_addresses(limit).await;
    send_result(result)
}
pub async fn fetch_amms_config_vm(
    State(context): State<Arc<LiquidityPoolContext>>,
    Path(params): Path<FetchAmmsConfigVMParameters>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_amms_config_vm"
    );
    let FetchAmmsConfigVMParameters {amms_config} = params;
    let result = context.get_amms_config_vm(&amms_config).await;
    send_result(result)
}
pub async fn fetch_amms_config_vms(
    State(context): State<Arc<LiquidityPoolContext>>,
    Json(payload): Json<FetchAmmsConfigsVMsPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_amms_config_vms"
    );
    let FetchAmmsConfigsVMsPayload {limit} = payload;
    let result = context.get_amms_config_vms(limit).await;
    send_result(result)
}
pub async fn fetch_launched_cp_amm_rows(
    State(context): State<Arc<LiquidityPoolContext>>,
    Json(payload): Json<FetchLaunchedCpAmmRowsPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_launched_cp_amm_rows"
    );
    let FetchLaunchedCpAmmRowsPayload {limit, base_mint, quote_mint} = payload;
    let result = context.get_launched_cp_amm_rows(limit, base_mint, quote_mint).await;
    send_result(result)
}

pub async fn fetch_token_with_ata_balance(
    State(context): State<Arc<LiquidityPoolContext>>,
    Path(params): Path<FetchTokenWithAtaParameters>,
    Json(payload): Json<FetchTokenWithAtaPayload>,
) -> impl IntoResponse {
    debug!(
        "Calling fetch_token_with_ata_balance"
    );
    let FetchTokenWithAtaPayload {user} = payload;
    let FetchTokenWithAtaParameters {mint} = params;
    let result = context.get_token_with_ata_balance(&mint, &user).await;
    send_result(result)
}

pub async fn fetch_cp_amm_vm(
    State(context): State<Arc<LiquidityPoolContext>>,
    Path(params): Path<FetchCpAmmVMParameters>,
    Json(payload): Json<FetchCpAmmVMPayload>,
) -> impl IntoResponse {
    debug!(
        "Calling fetch_cp_amm_vm"
    );
    let FetchCpAmmVMPayload {user} = payload;
    let FetchCpAmmVMParameters {cp_amm} = params;
    let result = context.get_cp_amm_vm(&cp_amm, &user).await;
    send_result(result)
}