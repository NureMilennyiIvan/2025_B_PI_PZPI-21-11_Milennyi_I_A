use std::sync::Arc;
use axum::{Router, routing::post, Router as AxumRouter};
use axum::routing::{get, IntoMakeService};
use tower_http::cors::CorsLayer;
use crate::liquidity_pool::api::endpoints::queries::*;
use crate::liquidity_pool::api::endpoints::transactions::*;
use crate::liquidity_pool::api::endpoints::websocket::*;
use crate::liquidity_pool::context::LiquidityPoolContext;

#[derive(Clone)]
pub struct LiquidityPoolRoutes {
    pub scope_path: String,
    pub initialize_config_manager: String,
    pub update_manager_authority: String,
    pub update_manager_head_authority: String,
    pub initialize_config: String,
    pub update_fee_authority: String,
    pub update_protocol_fee_rate: String,
    pub update_providers_fee_rate: String,
    pub create_cp_amm: String,
    pub initialize_cp_amm: String,
    pub launch_cp_amm: String,
    pub provide: String,
    pub withdraw: String,
    pub swap: String,
    pub collect_fees: String,
    pub fetch_configs_manager_vm: String,
    pub fetch_configs_addresses: String,
    pub fetch_config_vm: String,
    pub fetch_config_vms: String,
    pub fetch_launched_cp_amms: String,
    pub fetch_token_mint_with_ata_balance: String,
    pub fetch_cp_amm_vm: String,
    pub cp_amm_trades_ws: String,
    pub user_trades_ws: String,
}

impl LiquidityPoolRoutes {
    pub fn new(
        scope_path: String,
        initialize_config_manager: String,
        update_manager_authority: String,
        update_manager_head_authority: String,
        initialize_config: String,
        update_fee_authority: String,
        update_protocol_fee_rate: String,
        update_providers_fee_rate: String,
        create_cp_amm: String,
        initialize_cp_amm: String,
        launch_cp_amm: String,
        provide: String,
        withdraw: String,
        swap: String,
        collect_fees: String,
        fetch_configs_manager_vm: String,
        fetch_configs_addresses: String,
        fetch_config_vm: String,
        fetch_config_vms: String,
        fetch_launched_cp_amms: String,
        fetch_token_mint_with_ata_balance: String,
        fetch_cp_amm_vm: String,
        cp_amm_trades_ws: String,
        user_trades_ws: String
    ) -> Self {
        Self {
            scope_path,
            initialize_config_manager,
            update_manager_authority,
            update_manager_head_authority,
            initialize_config,
            update_fee_authority,
            update_protocol_fee_rate,
            update_providers_fee_rate,
            create_cp_amm,
            initialize_cp_amm,
            launch_cp_amm,
            provide,
            withdraw,
            swap,
            collect_fees,
            fetch_configs_manager_vm,
            fetch_configs_addresses,
            fetch_config_vm,
            fetch_config_vms,
            fetch_launched_cp_amms,
            fetch_token_mint_with_ata_balance,
            fetch_cp_amm_vm,
            cp_amm_trades_ws,
            user_trades_ws
        }
    }
}

pub struct LiquidityPoolApp {
    pub context: Arc<LiquidityPoolContext>,
    pub routes: LiquidityPoolRoutes,
    pub cors_layer: CorsLayer,
}

impl LiquidityPoolApp {
    pub fn new(context: Arc<LiquidityPoolContext>, routes: LiquidityPoolRoutes, cors_layer: CorsLayer) -> Self {
        Self { context, routes, cors_layer }
    }

    pub fn into_make_service(self) -> IntoMakeService<AxumRouter> {
        let state = self.context.clone();
        let r = &self.routes;
        let cors = self.cors_layer;
        let scoped = Router::new()
            .route(&r.initialize_config_manager, post(get_initialize_amms_configs_manager_tx))
            .route(&r.update_manager_authority, post(get_update_amms_configs_manager_authority_tx))
            .route(&r.update_manager_head_authority, post(get_update_amms_configs_manager_head_authority_tx))
            .route(&r.initialize_config, post(get_initialize_amms_config_tx))
            .route(&r.update_fee_authority, post(get_update_amms_config_fee_authority_tx))
            .route(&r.update_protocol_fee_rate, post(get_update_amms_config_protocol_fee_rate_tx))
            .route(&r.update_providers_fee_rate, post(get_update_amms_config_providers_fee_rate_tx))
            .route(&r.create_cp_amm, post(get_create_cp_amm_tx))
/*            .route(&r.initialize_cp_amm, post(get_initialize_cp_amm_tx))
            .route(&r.launch_cp_amm, post(get_launch_cp_amm_tx))*/
            .route(&r.provide, post(get_provide_to_cp_amm_tx))
            .route(&r.withdraw, post(get_withdraw_from_cp_amm_tx))
            .route(&r.swap, post(get_swap_in_cp_amm_tx))
            .route(&r.collect_fees, post(get_collect_fees_from_cp_amm_tx))
            .route(&r.fetch_configs_manager_vm, post(fetch_amms_configs_manager_vm))
            .route(&r.fetch_configs_addresses, post(fetch_amms_configs_addresses))
            .route(&r.fetch_config_vm, post(fetch_amms_config_vm))
            .route(&r.fetch_config_vms, post(fetch_amms_config_vms))
            .route(&r.fetch_launched_cp_amms, post(fetch_launched_cp_amm_rows))
            .route(&r.fetch_token_mint_with_ata_balance, post(fetch_token_with_ata_balance))
            .route(&r.fetch_cp_amm_vm, post(fetch_cp_amm_vm))
            .route(&r.cp_amm_trades_ws, get(cp_amm_trades_ws))
            .route(&r.user_trades_ws, get(user_trades_ws))
            .layer(cors)
            .with_state(state);

        Router::new()
            .nest(&r.scope_path, scoped)
            .into_make_service()
    }
}
