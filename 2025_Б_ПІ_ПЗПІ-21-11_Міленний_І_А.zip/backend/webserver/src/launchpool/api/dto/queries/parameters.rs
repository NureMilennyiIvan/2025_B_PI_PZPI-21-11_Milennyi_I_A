use serde::Deserialize;
use solana_sdk::pubkey::Pubkey;
use crate::utils::serde::pubkey_from_str;
#[derive(Deserialize)]
pub struct FetchLaunchpoolsConfigVMParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub launchpools_config: Pubkey
}
#[derive(Deserialize)]
pub struct FetchTokenWithAtaParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub mint: Pubkey
}

#[derive(Deserialize)]
pub struct FetchLaunchpoolVMParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub launchpool: Pubkey
}
#[derive(Deserialize)]
pub struct FetchStakePositionVMParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub launchpool: Pubkey
}
#[derive(Deserialize)]
pub struct FetchStakePositionVMsByUserParameters {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub user: Pubkey
}
