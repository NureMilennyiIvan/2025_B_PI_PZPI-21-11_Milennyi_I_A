use serde::Deserialize;
use solana_sdk::pubkey::Pubkey;
use crate::utils::serde::*;
#[derive(Deserialize)]
pub struct FetchLaunchpoolsConfigsAddressesPayload {
    pub limit: Option<u32>
}
#[derive(Deserialize)]
pub struct FetchLaunchpoolsConfigsVMsPayload {
    pub limit: Option<u32>
}
#[derive(Deserialize)]
pub struct FetchActiveLaunchpoolRowsPayload {
    pub limit: Option<u32>,
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub stakable_mint: Option<Pubkey>,
}
#[derive(Deserialize)]
pub struct FetchInitializedLaunchpoolRowsPayload {
    pub limit: Option<u32>,
}
#[derive(Deserialize)]
pub struct FetchTokenWithAtaPayload {
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub user: Option<Pubkey>
}

#[derive(Deserialize)]
pub struct FetchLaunchpoolVMPayload {
    #[serde(deserialize_with = "option_pubkey_from_str")]
    pub user: Option<Pubkey>
}
#[derive(Deserialize)]
pub struct FetchStakePositionVMPayload {
    #[serde(deserialize_with = "pubkey_from_str")]
    pub user: Pubkey
}