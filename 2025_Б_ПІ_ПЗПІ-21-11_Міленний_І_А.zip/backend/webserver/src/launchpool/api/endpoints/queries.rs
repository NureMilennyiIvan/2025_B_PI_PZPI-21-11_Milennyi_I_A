use std::sync::Arc;
use axum::extract::{Path, State};
use axum::Json;
use axum::response::IntoResponse;
use tracing::debug;
use crate::launchpool::api::dto::queries::parameters::{FetchLaunchpoolVMParameters, FetchLaunchpoolsConfigVMParameters, FetchStakePositionVMParameters, FetchStakePositionVMsByUserParameters, FetchTokenWithAtaParameters};
use crate::launchpool::api::dto::queries::payloads::{FetchActiveLaunchpoolRowsPayload, FetchInitializedLaunchpoolRowsPayload, FetchLaunchpoolVMPayload, FetchLaunchpoolsConfigsAddressesPayload, FetchLaunchpoolsConfigsVMsPayload, FetchStakePositionVMPayload, FetchTokenWithAtaPayload};
use crate::launchpool::api::dto::transactions::payloads::UpdateLaunchpoolsConfigsManagerAuthorityPayload;
use crate::launchpool::context::LaunchpoolContext;
use crate::launchpool::core::update_launchpools_configs_manager_authority_tx;
use crate::liquidity_pool::api::dto::queries::payloads::FetchAmmsConfigsVMsPayload;
use crate::liquidity_pool::context::LiquidityPoolContext;
use crate::utils::clients::ProgramContext;
use crate::utils::web::send_result;

pub async fn fetch_launchpools_configs_manager_vm(
    State(context): State<Arc<LaunchpoolContext>>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_launchpools_configs_manager_vm"
    );
    let result = context.get_launchpools_configs_manager_vm().await;
    send_result(result)
}
pub async fn fetch_launchpools_configs_addresses(
    State(context): State<Arc<LaunchpoolContext>>,
    Json(payload): Json<FetchLaunchpoolsConfigsAddressesPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_launchpools_configs_addresses"
    );
    let FetchLaunchpoolsConfigsAddressesPayload {limit} = payload;
    let result = context.get_launchpools_configs_addresses(limit).await;
    send_result(result)
}
pub async fn fetch_launchpools_config_vm(
    State(context): State<Arc<LaunchpoolContext>>,
    Path(params): Path<FetchLaunchpoolsConfigVMParameters>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_launchpools_config_vm"
    );
    let FetchLaunchpoolsConfigVMParameters {launchpools_config} = params;
    let result = context.get_launchpools_config_vm(&launchpools_config).await;
    send_result(result)
}
pub async fn fetch_launchpools_configs_vms(
    State(context): State<Arc<LaunchpoolContext>>,
    Json(payload): Json<FetchLaunchpoolsConfigsVMsPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_launchpools_configs_vms"
    );
    let FetchLaunchpoolsConfigsVMsPayload {limit} = payload;
    let result = context.get_launchpools_configs_vms(limit).await;
    send_result(result)
}
pub async fn fetch_active_launchpool_rows(
    State(context): State<Arc<LaunchpoolContext>>,
    Json(payload): Json<FetchActiveLaunchpoolRowsPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_active_launchpool_rows"
    );
    let FetchActiveLaunchpoolRowsPayload {limit, stakable_mint} = payload;
    let result = context.get_active_launchpool_rows(limit, stakable_mint).await;
    send_result(result)
}
pub async fn fetch_initialized_launchpool_rows(
    State(context): State<Arc<LaunchpoolContext>>,
    Json(payload): Json<FetchInitializedLaunchpoolRowsPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_initialized_launchpool_rows"
    );
    let FetchInitializedLaunchpoolRowsPayload {limit} = payload;
    let result = context.get_initialized_launchpool_rows(limit).await;
    send_result(result)
}
pub async fn fetch_launchpool_vm(
    State(context): State<Arc<LaunchpoolContext>>,
    Path(params): Path<FetchLaunchpoolVMParameters>,
    Json(payload): Json<FetchLaunchpoolVMPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_launchpool_vm"
    );
    let FetchLaunchpoolVMPayload {user} = payload;
    let FetchLaunchpoolVMParameters {launchpool} = params;
    let result = context.get_launchpool_vm(&launchpool, &user).await;
    send_result(result)
}
pub async fn fetch_stake_position_vm(
    State(context): State<Arc<LaunchpoolContext>>,
    Path(params): Path<FetchStakePositionVMParameters>,
    Json(payload): Json<FetchStakePositionVMPayload>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_stake_position_vm"
    );
    let FetchStakePositionVMPayload {user} = payload;
    let FetchStakePositionVMParameters {launchpool} = params;
    let result = context.get_stake_position_vm(&launchpool, &user).await;
    send_result(result)
}
pub async fn fetch_stake_position_vms_by_user(
    State(context): State<Arc<LaunchpoolContext>>,
    Path(params): Path<FetchStakePositionVMsByUserParameters>
) -> impl IntoResponse {
    debug!(
        "Calling fetch_stake_position_vms_by_user"
    );
    let FetchStakePositionVMsByUserParameters {user} = params;
    let result = context.get_stake_position_vms_by_user(&user).await;
    send_result(result)
}
pub async fn fetch_token_with_ata_balance(
    State(context): State<Arc<LaunchpoolContext>>,
    Path(params): Path<FetchTokenWithAtaParameters>,
    Json(payload): Json<FetchTokenWithAtaPayload>,
) -> impl IntoResponse {
    debug!(
        "Calling fetch_token_with_ata_balance"
    );
    let FetchTokenWithAtaPayload {user} = payload;
    let FetchTokenWithAtaParameters {mint} = params;
    let result = context.get_token_with_ata_balance(&mint, &user).await;
    send_result(result)
}