use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow, Serialize)]
pub struct StakePositionAddress {
    pub stake_position: String,
}