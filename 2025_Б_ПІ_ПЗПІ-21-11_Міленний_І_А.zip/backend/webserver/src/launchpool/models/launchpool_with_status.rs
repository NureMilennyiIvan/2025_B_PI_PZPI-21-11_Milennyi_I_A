use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow)]
pub struct LaunchpoolWithStatus {
    pub launchpool: String,
    pub status: i8
}