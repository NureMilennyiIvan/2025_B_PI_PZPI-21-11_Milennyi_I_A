use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow, Serialize)]
pub struct LaunchpoolAddress {
    pub launchpool: String,
}