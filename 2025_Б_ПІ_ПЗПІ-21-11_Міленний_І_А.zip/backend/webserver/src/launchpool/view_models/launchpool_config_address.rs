use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow, Serialize)]
pub struct LaunchpoolsConfigAddress {
    pub launchpools_config: String,
}