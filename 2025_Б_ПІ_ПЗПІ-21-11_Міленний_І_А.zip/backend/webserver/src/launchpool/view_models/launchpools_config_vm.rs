use serde::{Serialize};
use solana_sdk::pubkey::{Pubkey};
use launchpool::accounts::LaunchpoolsConfig;
use crate::launchpool::core::address_derive::get_launchpools_config_pda;

#[derive(Serialize)]
pub struct LaunchpoolsConfigVM{
    pub key: Pubkey,
    pub reward_authority: String,
    pub stakable_mint: String,
    pub min_position_size: u64,
    pub max_position_size: u64,
    pub protocol_reward_share_basis_points: u16,
    pub duration: u64
}

impl From<LaunchpoolsConfig> for LaunchpoolsConfigVM{

    fn from(value: LaunchpoolsConfig) -> Self {
        Self{
            key: get_launchpools_config_pda(value.id).0,
            reward_authority: value.reward_authority.to_string(),
            stakable_mint: value.stakable_mint.to_string(),
            min_position_size: value.min_position_size,
            max_position_size: value.max_position_size,
            protocol_reward_share_basis_points: value.protocol_reward_share_basis_points,
            duration: value.duration,
        }
    }
}