use crate::utils::clients::models::TokenMint;
use serde::Serialize;
use launchpool::accounts::{Launchpool, LaunchpoolsConfig};
use launchpool::types::LaunchpoolStatus;
use utilities::math::{Q64_128, U192};
use crate::launchpool::view_models::StakePositionVM;

#[derive(Serialize)]
pub struct LaunchpoolVM {
    pub launchpools_config: String,
    pub stakable_mint: String,
    pub stakable_token_data: (TokenMint, Option<String>),
    pub reward_mint: String,
    pub reward_vault: String,
    pub reward_token_data: (TokenMint, Option<String>),
    pub initial_reward_amount: String,
    pub participants_reward_amount: String,
    pub protocol_reward_amount: String,
    pub protocol_reward_left_to_obtain: String,
    pub participants_reward_left_to_obtain: String,
    pub staked_amount: String,
    pub participants_reward_left_to_distribute: String,
    pub reward_rate: String,
    pub reward_per_token: String,
    pub min_position_size: String,
    pub max_position_size: String,
    pub status: String,
    pub duration: i64,
    pub start_timestamp: i64,
    pub end_timestamp: i64,
    pub last_update_timestamp: i64,
    pub stake_position_vm: Option<StakePositionVM>,
}
impl LaunchpoolVM {
    pub fn new(
        launchpool: Launchpool,
        launchpools_config: LaunchpoolsConfig,
        stakable_token_data: (TokenMint, Option<String>),
        reward_token_data: (TokenMint, Option<String>),
        stake_position_vm: Option<StakePositionVM>
    ) -> Self {
        let participants_reward_amount = Q64_128::new(U192([
            launchpool.participants_reward_amount.value[0],
            launchpool.participants_reward_amount.value[1],
            launchpool.participants_reward_amount.value[2],
        ]));
        let participants_reward_left_to_distribute = Q64_128::new(U192([
            launchpool.participants_reward_left_to_distribute.value[0],
            launchpool.participants_reward_left_to_distribute.value[1],
            launchpool.participants_reward_left_to_distribute.value[2],
        ]));
        let reward_rate = Q64_128::new(U192([
            launchpool.reward_rate.value[0],
            launchpool.reward_rate.value[1],
            launchpool.reward_rate.value[2],
        ]));
        let reward_per_token = Q64_128::new(U192([
            launchpool.reward_per_token.value[0],
            launchpool.reward_per_token.value[1],
            launchpool.reward_per_token.value[2],
        ]));
        Self {
            launchpools_config: launchpool.launchpools_config.to_string(),
            stakable_mint: launchpools_config.stakable_mint.to_string(),
            stakable_token_data,
            reward_mint: launchpool.reward_mint.to_string(),
            reward_vault: launchpool.reward_vault.to_string(),
            reward_token_data,
            initial_reward_amount: launchpool.initial_reward_amount.to_string(),
            participants_reward_amount: participants_reward_amount.as_u64().to_string(),
            protocol_reward_amount: launchpool.protocol_reward_amount.to_string(),
            protocol_reward_left_to_obtain: launchpool.protocol_reward_left_to_obtain.to_string(),
            participants_reward_left_to_obtain: launchpool.participants_reward_left_to_obtain.to_string(),
            staked_amount: launchpool.staked_amount.to_string(),
            participants_reward_left_to_distribute: participants_reward_left_to_distribute.as_u64().to_string(),
            reward_rate: f64::from(reward_rate).to_string(),
            reward_per_token: f64::from(reward_per_token).to_string(),
            min_position_size: launchpool.min_position_size.to_string(),
            max_position_size: launchpool.max_position_size.to_string(),
            duration: launchpools_config.duration as i64,
            start_timestamp: launchpool.start_timestamp as i64,
            end_timestamp: launchpool.end_timestamp as i64,
            last_update_timestamp: launchpool.last_update_timestamp as i64,
            stake_position_vm,
            status: match launchpool.status{
                LaunchpoolStatus::Uninitialized => "Uninitialized".to_string(),
                LaunchpoolStatus::Initialized => "Initialized".to_string(),
                LaunchpoolStatus::Launched => "Launched".to_string(),
                LaunchpoolStatus::Finished => "Finished".to_string(),
                LaunchpoolStatus::ClaimedProtocolReward => "ClaimedProtocolReward".to_string(),
            },
        }
    }
}
