use serde::Serialize;
use launchpool::accounts::StakePosition;
use launchpool::types::PositionStatus;
use utilities::math::{Q64_128, U192};
use crate::launchpool::core::address_derive::get_stake_position_pda;

#[derive(Serialize)]
pub struct StakePositionVM {
    pub key: String,
    pub authority: String,
    pub launchpool: String,
    pub amount: String,
    pub reward_earned: String,
    pub reward_debt: String,
    pub status: String,
}
impl From<StakePosition> for StakePositionVM {
    fn from(stake_position: StakePosition) -> Self {
        let amount = Q64_128::new(U192([
            stake_position.amount.value[0],
            stake_position.amount.value[1],
            stake_position.amount.value[2],
        ]));
        let reward_earned = Q64_128::new(U192([
            stake_position.reward_earned.value[0],
            stake_position.reward_earned.value[1],
            stake_position.reward_earned.value[2],
        ]));
        let reward_debt = Q64_128::new(U192([
            stake_position.reward_debt.value[0],
            stake_position.reward_debt.value[1],
            stake_position.reward_debt.value[2],
        ]));
        Self{
            key: get_stake_position_pda(&stake_position.authority, &stake_position.launchpool).0.to_string(),
            authority: stake_position.authority.to_string(),
            launchpool: stake_position.launchpool.to_string(),
            amount: amount.as_u64().to_string(),
            reward_earned: reward_earned.as_u64().to_string(),
            reward_debt: reward_debt.as_u64().to_string(),
            status: match stake_position.status{
                PositionStatus::Uninitialized => "Uninitialized".to_string(),
                PositionStatus::Initialized => "Initialized".to_string(),
                PositionStatus::Opened => "Opened".to_string(),
                PositionStatus::Closed => "Closed".to_string(),
            },
        }
    }
}
