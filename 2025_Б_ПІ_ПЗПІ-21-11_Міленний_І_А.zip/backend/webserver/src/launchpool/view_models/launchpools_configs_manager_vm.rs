use serde::{Serialize};
use solana_sdk::pubkey::{Pubkey};
use launchpool::accounts::LaunchpoolsConfigsManager;
use crate::launchpool::core::address_derive::get_launchpools_configs_manager_pda;

#[derive(Serialize)]
pub struct LaunchpoolsConfigsManagerVM{
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub key: Pubkey,
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub authority: Pubkey,
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    pub head_authority: Pubkey,
}

impl From<LaunchpoolsConfigsManager> for LaunchpoolsConfigsManagerVM{

    fn from(value: LaunchpoolsConfigsManager) -> Self {
        Self{
            key: get_launchpools_configs_manager_pda().0,
            authority: value.authority,
            head_authority: value.head_authority
        }
    }
}