use scylla::DeserializeRow;
use serde::Serialize;

#[derive(DeserializeRow, Serialize, Debug)]
pub struct LaunchpoolRow {
    pub launchpool: String,
    pub launchpools_config: String,
    pub reward_mint: String,
    pub stakable_mint: String
}