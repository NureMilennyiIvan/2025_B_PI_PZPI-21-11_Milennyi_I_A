use std::collections::HashMap;
use crate::launchpool::models::{LaunchpoolAddress, LaunchpoolKeys, LaunchpoolKeysScylla, LaunchpoolWithStatus, LaunchpoolsConfigKeys, LaunchpoolsConfigKeysScylla, StakePositionAddress, StakePositionKeys, StakePositionKeysScylla};
use crate::launchpool::view_models::{LaunchpoolRow, LaunchpoolsConfigAddress};
use crate::utils::clients::ScyllaDbClient;
use anyhow::{Context, Result as AnyResult};
use scylla::client::session::Session;
use scylla::errors::DeserializationError;
use solana_sdk::pubkey::Pubkey;
use tracing::debug;
use launchpool::accounts::Launchpool;

pub struct LaunchpoolScyllaDbClient {
    launchpool_session: Session,
}
impl LaunchpoolScyllaDbClient {
    pub fn new(launchpool_session: Session) -> Self {
        Self { launchpool_session }
    }

    pub async fn fetch_launchpool_keys(
        &self,
        launchpool: &Pubkey,
    ) -> AnyResult<Option<LaunchpoolKeys>> {
        let rows = self
            .launchpool_session
            .query_unpaged(
                "SELECT launchpools_config, reward_mint FROM launchpools WHERE launchpool = ?",
                (launchpool.to_string(),),
            )
            .await
            .context("failed to fetch launchpool keys")?
            .into_rows_result()?;

        debug!(
            ?launchpool,
            rows = rows.rows_num(),
            "Fetched launchpool keys rows"
        );

        if rows.rows_num() == 0 {
            return Ok(None);
        }

        let launchpool_keys: LaunchpoolKeys =
            rows.first_row::<LaunchpoolKeysScylla>()?.try_into()?;
        debug!(?launchpool, "Parsed LaunchpoolKeys");
        Ok(Some(launchpool_keys))
    }

    pub async fn fetch_launchpools_config_keys(
        &self,
        launchpools_config: &Pubkey,
    ) -> AnyResult<Option<LaunchpoolsConfigKeys>> {
        let rows = self
            .launchpool_session
            .query_unpaged(
                "SELECT stakable_mint FROM initialize_launchpools_config_events WHERE launchpools_config = ?",
                (launchpools_config.to_string(),),
            )
            .await
            .context("failed to fetch launchpools_config keys")?
            .into_rows_result()?;

        debug!(
            ?launchpools_config,
            rows = rows.rows_num(),
            "Fetched launchpools_config keys rows"
        );

        if rows.rows_num() == 0 {
            return Ok(None);
        }

        let keys: LaunchpoolsConfigKeys = rows
            .first_row::<LaunchpoolsConfigKeysScylla>()?
            .try_into()?;
        debug!(?launchpools_config, "Parsed LaunchpoolsConfigKeys");
        Ok(Some(keys))
    }
    pub async fn fetch_launchpools_configs_addresses(
        &self,
        limit: Option<u32>,
    ) -> AnyResult<Vec<LaunchpoolsConfigAddress>> {
        let rows = match limit {
            Some(limit) => self
                .launchpool_session
                .query_unpaged(
                    "SELECT launchpools_config FROM initialize_launchpools_config_events LIMIT ?",
                    (limit as i64,),
                )
                .await,
            None => {
                self.launchpool_session
                    .query_unpaged(
                        "SELECT launchpools_config FROM initialize_launchpools_config_events",
                        (),
                    )
                    .await
            }
        }
        .context("failed to fetch launchpools_config addresses")?
        .into_rows_result()?;

        debug!(
            ?limit,
            rows = rows.rows_num(),
            "Fetched launchpools_configs addresses rows"
        );

        if rows.rows_num() == 0 {
            return Ok(vec![]);
        }
        let addresses: Result<Vec<LaunchpoolsConfigAddress>, DeserializationError> =
            rows.rows::<LaunchpoolsConfigAddress>()?.collect();
        Ok(addresses?)
    }

    pub async fn fetch_launchpools_with_statuses(&self) -> AnyResult<HashMap<String, i8>> {
        let rows = self
            .launchpool_session
            .query_unpaged(
                "SELECT * FROM launchpools_status",
                (),
            )
            .await
            .context("failed to fetch launchpools_with_statuses keys")?
            .into_rows_result()?;
        debug!(
            rows = rows.rows_num(),
            "Fetched launchpools_with_statuses addresses rows"
        );

        if rows.rows_num() == 0 {
            return Ok(HashMap::new());
        }
        let launchpools: HashMap<String, i8> =
            rows.rows::<LaunchpoolWithStatus>()?.map(|row_result| {
                let LaunchpoolWithStatus { launchpool, status } = row_result?;
                Ok((launchpool, status))
            }).collect::<Result<_, DeserializationError>>()?;
        Ok(launchpools)
    }

    pub async fn fetch_launchpools_addresses_by_stakable_mint(
        &self,
        stakable_mint: &Pubkey,
        limit: Option<u32>,
    ) -> AnyResult<Vec<LaunchpoolAddress>> {
        let rows = match limit {
            Some(limit) => self
                .launchpool_session
                .query_unpaged(
                    "SELECT launchpool FROM launchpools_by_stakable_mint WHERE stakable_mint = ? LIMIT ?",
                    (stakable_mint.to_string(), limit as i64,),
                )
                .await,
            None => {
                self.launchpool_session
                    .query_unpaged(
                        "SELECT launchpool FROM launchpools_by_stakable_mint WHERE stakable_mint = ?",
                        (stakable_mint.to_string(), ),
                    )
                    .await
            }
        }
            .context("failed to fetch launchpools addresses by stakable mint")?
            .into_rows_result()?;

        debug!(
            ?limit,
            rows = rows.rows_num(),
            "Fetched launchpools addresses by stakable mint rows"
        );

        if rows.rows_num() == 0 {
            return Ok(vec![]);
        }
        let addresses: Result<Vec<LaunchpoolAddress>, DeserializationError> =
            rows.rows::<LaunchpoolAddress>()?.collect();
        Ok(addresses?)
    }

    pub async fn fetch_launchpool_rows(&self, launchpools_addresses: Vec<LaunchpoolAddress>) -> AnyResult<Vec<LaunchpoolRow>> {
        if launchpools_addresses.is_empty() {
            let rows = self
                .launchpool_session
                .query_unpaged(
                    "SELECT launchpool, launchpools_config, reward_mint, stakable_mint FROM launchpools",
                    (),
                )
                .await
                .context("failed to fetch launchpool rows")?
                .into_rows_result()?;
            debug!(
            rows = rows.rows_num(),
            "Fetched launchpool rows"
        );

            if rows.rows_num() == 0 {
                return Ok(vec![]);
            }
            return Ok(rows.rows::<LaunchpoolRow>()?.collect::<Result<_, _>>()?);
        }
        let mut results: Vec<LaunchpoolRow> = Vec::with_capacity(launchpools_addresses.len());
        for batch in launchpools_addresses.chunks(100) {
            let placeholders = batch.iter().map(|_| "?").collect::<Vec<_>>().join(", ");

            let query = format!("SELECT launchpool, launchpools_config, reward_mint, stakable_mint FROM launchpools WHERE launchpool IN ({})", placeholders);
            let values: Vec<String> = batch.iter().map(|address| address.launchpool.clone()).collect();
            let rows = self.launchpool_session.query_unpaged(query,values).await?.into_rows_result()?;
            results.extend(rows.rows::<LaunchpoolRow>()?.collect::<Result<Vec<LaunchpoolRow>, DeserializationError>>()?);
            debug!(rows = rows.rows_num(), "Batch fetched launchpool rows");
        }
        Ok(results)
    }

    pub async fn fetch_stake_position_keys(
        &self,
        stake_position: &Pubkey,
    ) -> AnyResult<Option<StakePositionKeys>> {
        let rows = self
            .launchpool_session
            .query_unpaged(
                "SELECT user, launchpool FROM stake_positions WHERE stake_position = ?",
                (stake_position.to_string(),),
            )
            .await
            .context("failed to fetch stake_position keys")?
            .into_rows_result()?;

        debug!(
            ?stake_position,
            rows = rows.rows_num(),
            "Fetched stake_position keys rows"
        );

        if rows.rows_num() == 0 {
            return Ok(None);
        }

        let keys: StakePositionKeys = rows.first_row::<StakePositionKeysScylla>()?.try_into()?;
        debug!(?stake_position, "Parsed StakePositionKeys");
        Ok(Some(keys))
    }

    pub async fn fetch_stake_positions_by_user(
        &self,
        user: &Pubkey,
    ) -> AnyResult<Vec<StakePositionAddress>> {
        let rows = self
            .launchpool_session
            .query_unpaged(
                "SELECT stake_position FROM stake_positions_by_user WHERE user = ?",
                (user.to_string(),),
            )
            .await
            .context("failed to fetch stake_position addresses")?
            .into_rows_result()?;

        debug!(
            ?user,
            rows = rows.rows_num(),
            "Fetched stake_position addresses by user rows"
        );

        if rows.rows_num() == 0 {
            return Ok(vec![]);
        }

        let addresses = rows.rows::<StakePositionAddress>()?.collect::<Result<Vec<StakePositionAddress>, DeserializationError>>()?;
        debug!(?user, "Parsed StakePositionAddress");
        Ok(addresses)
    }
}
impl ScyllaDbClient for LaunchpoolScyllaDbClient {
    fn session(&self) -> &Session {
        &self.launchpool_session
    }
}
