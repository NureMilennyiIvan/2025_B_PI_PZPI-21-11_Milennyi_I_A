use super::{LaunchpoolScyllaDbClient, LaunchpoolSolanaRpcClient};
use crate::launchpool::models::{LaunchpoolAddress, LaunchpoolKeys, LaunchpoolsConfigKeys, StakePositionKeys};
use crate::utils::clients::{CacheRegistry, ProgramContext, SolanaRpcClient};
use anyhow::{anyhow, Result as AnyResult};
use async_trait::async_trait;
use launchpool::accounts::{Launchpool, LaunchpoolsConfigsManager, StakePosition};
use solana_sdk::pubkey::Pubkey;
use std::ops::Deref;
use std::str::FromStr;
use std::sync::Arc;
use tracing::debug;
use launchpool::types::LaunchpoolStatus;
use crate::launchpool::core::address_derive::{get_launchpools_configs_manager_pda, get_stake_position_pda};
use crate::launchpool::view_models::{LaunchpoolRow, LaunchpoolVM, LaunchpoolsConfigAddress, LaunchpoolsConfigVM, LaunchpoolsConfigsManagerVM, StakePositionVM};
use crate::liquidity_pool::core::address_derive::get_amms_configs_manager_pda;
use crate::liquidity_pool::models::CpAmmKeys;
use crate::liquidity_pool::view_models::{AmmsConfigVM, CpAmmVM};

pub struct LaunchpoolContext {
    solana_rpc_client: Arc<LaunchpoolSolanaRpcClient>,
    scylla_db_client: Arc<LaunchpoolScyllaDbClient>,
    cache_registry: Arc<CacheRegistry>,
}
impl LaunchpoolContext {
    pub fn new(
        solana_rpc_client: Arc<LaunchpoolSolanaRpcClient>,
        scylla_db_client: Arc<LaunchpoolScyllaDbClient>,
        cache_registry: Arc<CacheRegistry>,
    ) -> Self {
        Self {
            solana_rpc_client,
            scylla_db_client,
            cache_registry,
        }
    }
    pub async fn get_launchpools_configs_manager_vm(&self) -> AnyResult<LaunchpoolsConfigsManagerVM>{
        let key = get_launchpools_configs_manager_pda().0;
        let manager = self.solana_rpc_client.fetch_launchpools_configs_manager(&key).await?;
        Ok(manager.into())
    }
    pub async fn get_launchpools_config_vm(&self, launchpools_config_key: &Pubkey) -> AnyResult<LaunchpoolsConfigVM>{
        let config = self.solana_rpc_client.fetch_launchpools_config(&launchpools_config_key).await?;
        Ok(config.into())
    }
    pub async fn get_launchpools_configs_vms(&self, limit: Option<u32>) -> AnyResult<Vec<LaunchpoolsConfigVM>> {
        let addresses = self.get_launchpools_configs_addresses(limit).await?.into_iter().map(|address| Pubkey::from_str(address.launchpools_config.as_str())).collect::<Result<Vec<_>, _>>()?;
        self.solana_rpc_client().fetch_launchpools_configs(&addresses).await.map(|vms| vms.into_iter().map(|config| config.into()).collect::<Vec<LaunchpoolsConfigVM>>())
    }
    pub async fn get_launchpools_configs_addresses(&self, limit: Option<u32>) -> AnyResult<Vec<LaunchpoolsConfigAddress>> {
        self.scylla_db_client().fetch_launchpools_configs_addresses(limit).await
    }
    pub async fn get_active_launchpool_rows(&self, limit: Option<u32>, stakable_mint: Option<Pubkey>) -> AnyResult<Vec<LaunchpoolRow>> {
        let scylla_db_client = self.scylla_db_client.clone();
        let launchpools = match stakable_mint{
            None => vec![],
            Some(mint) => {
                let pools = scylla_db_client.fetch_launchpools_addresses_by_stakable_mint(&mint, None).await?;
                if pools.is_empty(){
                    return Ok(vec![]);
                }
                pools
            }
        };
        let (launchpools_with_statuses, launchpool_rows) = tokio::try_join!(
            scylla_db_client.fetch_launchpools_with_statuses(),
            scylla_db_client.fetch_launchpool_rows(launchpools),
        )?;
        let active_launchpool_rows: Vec<LaunchpoolRow> = launchpool_rows.into_iter().filter(|row|  launchpools_with_statuses.get(&row.launchpool).map(|status| *status == LaunchpoolStatus::Launched as i8).unwrap_or(false)).collect();
        match limit {
            None => Ok(active_launchpool_rows),
            Some(number) => Ok(active_launchpool_rows.into_iter().take(number as usize).collect()),
        }
    }

    pub async fn get_initialized_launchpool_rows(&self, limit: Option<u32>) -> AnyResult<Vec<LaunchpoolRow>> {
        let scylla_db_client = self.scylla_db_client.clone();
        let launchpools = scylla_db_client
            .fetch_launchpools_with_statuses()
            .await?
            .into_iter()
            .filter(|(_, status)| *status == LaunchpoolStatus::Initialized as i8)
            .map(|(pubkey, _)| LaunchpoolAddress {
                launchpool: pubkey
            } )
            .take(limit.map(|l| l as usize).unwrap_or(usize::MAX))
            .collect::<Vec<LaunchpoolAddress>>();
        if launchpools.is_empty() {
            return Ok(vec![]);
        }
        scylla_db_client.fetch_launchpool_rows(launchpools).await
    }
    pub async fn get_launchpool_vm(&self, launchpool_key: &Pubkey, user: &Option<Pubkey>) -> AnyResult<LaunchpoolVM>{
        let launchpool_keys = self.get_launchpool_keys(launchpool_key).await?;
        let solana_rpc_client = self.solana_rpc_client().clone();
        let (launchpool, launchpools_config, stake_position) = tokio::try_join!(
            solana_rpc_client.fetch_launchpool(launchpool_key),
            solana_rpc_client.fetch_launchpools_config(&launchpool_keys.launchpools_config),
            async {
                match user{
                    None => Ok(None),
                    Some(user) => {
                        Ok(self.get_stake_position_vm(&launchpool_key, user).await.ok())
                    }
                }
            },
        )?;

        let (reward_token_data, reward_balance, stakable_mint_data_with_ata) = tokio::try_join!(
            self.get_token_mint(&launchpool.reward_mint),
            async {
                Ok(solana_rpc_client.fetch_token_account_balance(&launchpool.reward_vault).await)
            },
            self.get_token_with_ata_balance(&launchpools_config.stakable_mint, user)
        )?;
        Ok(LaunchpoolVM::new(
            launchpool,
            launchpools_config,
            stakable_mint_data_with_ata.ok_or(anyhow!("missing token mint"))?,
            ((*reward_token_data).clone(), reward_balance),
            stake_position,
        ))
    }
    pub async fn get_stake_position_vm(&self, launchpool_key: &Pubkey, user: &Pubkey) -> AnyResult<StakePositionVM>{
        let stake_position_key = get_stake_position_pda(user, launchpool_key).0;
        let stake_position_vm: StakePositionVM = self.solana_rpc_client().fetch_stake_position(
            &stake_position_key
        ).await?.into();
        Ok(stake_position_vm)
    }
    pub async fn get_stake_position_vms_by_user(&self, user: &Pubkey) -> AnyResult<Vec<StakePositionVM>> {
        let addresses = self.scylla_db_client.fetch_stake_positions_by_user(user).await?.into_iter().map(|address| Pubkey::from_str(address.stake_position.as_str())).collect::<Result<Vec<_>, _>>()?;
        self.solana_rpc_client().fetch_stake_positions(&addresses).await.map(|vms| vms.into_iter().map(|config| config.into()).collect::<Vec<StakePositionVM>>())
    }
    pub async fn get_launchpool_keys(
        &self,
        launchpool_key: &Pubkey,
    ) -> AnyResult<Arc<LaunchpoolKeys>> {
        debug!(?launchpool_key, "Fetching launchpool keys from launchpool_keys_cache");
        let launchpool_keys_cache = self
            .cache_registry()
            .get::<Pubkey, Arc<LaunchpoolKeys>>("launchpool_keys_cache")
            .expect("launchpool_keys_cache must be registered");
        if let Some(launchpool_keys) = launchpool_keys_cache.get(launchpool_key).await {
            debug!(?launchpool_key, "Fetched launchpool keys");
            return Ok(launchpool_keys);
        }

        debug!(?launchpool_key, "Launchpool keys not in launchpool_keys_cache — fetching from launchpool_cache");
        let launchpool_cache = self
            .cache_registry()
            .get::<Pubkey, Arc<Launchpool>>("launchpool_cache")
            .expect("launchpool_cache must be registered");
        if let Some(launchpool) = launchpool_cache.get(launchpool_key).await {
            let launchpool_keys = Arc::new(LaunchpoolKeys::from(launchpool.deref().clone()));
            launchpool_keys_cache
                .insert(*launchpool_key, launchpool_keys.clone())
                .await;
            debug!(?launchpool_key, "Fetched launchpool keys");
            return Ok(launchpool_keys);
        }

        debug!(?launchpool_key, "Launchpool keys not in launchpool_cache — fetching from Events Storage");
        if let Some(launchpool_keys) = self
            .scylla_db_client()
            .fetch_launchpool_keys(launchpool_key)
            .await
            .ok()
            .flatten()
            .map(Arc::new)
        {
            launchpool_keys_cache
                .insert(*launchpool_key, launchpool_keys.clone())
                .await;
            return Ok(launchpool_keys);
        }

        debug!(?launchpool_key, "Launchpool keys not in Events Storage — fetching from Solana");
        let launchpool_account = self
            .solana_rpc_client()
            .fetch_launchpool(launchpool_key)
            .await?;
        launchpool_cache
            .insert(*launchpool_key, Arc::new(launchpool_account.clone()))
            .await;
        let launchpool_keys = Arc::new(LaunchpoolKeys::from(launchpool_account));
        launchpool_keys_cache
            .insert(*launchpool_key, launchpool_keys.clone())
            .await;
        Ok(launchpool_keys)
    }

    pub async fn get_launchpools_config_keys(
        &self,
        config_key: &Pubkey,
    ) -> AnyResult<Arc<LaunchpoolsConfigKeys>> {
        debug!(?config_key, "Fetching launchpools config keys from launchpools_config_keys_cache");
        let config_keys_cache = self
            .cache_registry()
            .get::<Pubkey, Arc<LaunchpoolsConfigKeys>>("launchpools_config_keys_cache")
            .expect("launchpools_config_keys_cache must be registered");

        if let Some(config_keys) = config_keys_cache.get(config_key).await {
            debug!(?config_key, "Fetched launchpools config keys");
            return Ok(config_keys);
        }

        debug!(?config_key, "Launchpools config keys not in keys cache — fetching from Events Storage");
        if let Some(config_keys) = self
            .scylla_db_client()
            .fetch_launchpools_config_keys(config_key)
            .await
            .ok()
            .flatten()
            .map(Arc::new)
        {
            config_keys_cache.insert(*config_key, config_keys.clone()).await;
            return Ok(config_keys);
        }

        debug!(?config_key, "Launchpools config keys not in Events Storage — fetching from Solana");
        let config_account = self
            .solana_rpc_client()
            .fetch_launchpools_config(config_key)
            .await?;

        let config_keys = Arc::new(LaunchpoolsConfigKeys::from(config_account));
        config_keys_cache.insert(*config_key, config_keys.clone()).await;
        Ok(config_keys)
    }

    pub async fn get_stake_position_keys(
        &self,
        stake_position_key: &Pubkey,
    ) -> AnyResult<Arc<StakePositionKeys>> {
        debug!(?stake_position_key, "Fetching stake position keys from stake_position_keys_cache");
        let position_keys_cache = self
            .cache_registry()
            .get::<Pubkey, Arc<StakePositionKeys>>("stake_position_keys_cache")
            .expect("stake_position_keys_cache must be registered");

        if let Some(position_keys) = position_keys_cache.get(stake_position_key).await {
            debug!(?stake_position_key, "Fetched stake position keys");
            return Ok(position_keys);
        }

        debug!(?stake_position_key, "Stake position keys not in keys cache — fetching from stake_position_cache");
        let position_cache = self
            .cache_registry()
            .get::<Pubkey, Arc<StakePosition>>("stake_position_cache")
            .expect("stake_position_cache must be registered");

        if let Some(position) = position_cache.get(stake_position_key).await {
            let position_keys = Arc::new(StakePositionKeys::from(position.deref().clone()));
            position_keys_cache
                .insert(*stake_position_key, position_keys.clone())
                .await;
            debug!(?stake_position_key, "Fetched stake position keys");
            return Ok(position_keys);
        }

        debug!(?stake_position_key, "Stake position keys not in position cache — fetching from Events Storage");
        if let Some(position_keys) = self
            .scylla_db_client()
            .fetch_stake_position_keys(stake_position_key)
            .await
            .ok()
            .flatten()
            .map(Arc::new)
        {
            position_keys_cache
                .insert(*stake_position_key, position_keys.clone())
                .await;
            return Ok(position_keys);
        }

        debug!(?stake_position_key, "Stake position keys not in Events Storage — fetching from Solana");
        let position_account = self
            .solana_rpc_client()
            .fetch_stake_position(stake_position_key)
            .await?;

        position_cache
            .insert(*stake_position_key, Arc::new(position_account.clone()))
            .await;

        let position_keys = Arc::new(StakePositionKeys::from(position_account));
        position_keys_cache
            .insert(*stake_position_key, position_keys.clone())
            .await;

        Ok(position_keys)
    }
}

#[async_trait]
impl ProgramContext<LaunchpoolScyllaDbClient, LaunchpoolSolanaRpcClient> for LaunchpoolContext {
    fn scylla_db_client(&self) -> Arc<LaunchpoolScyllaDbClient> {
        self.scylla_db_client.clone()
    }

    fn solana_rpc_client(&self) -> Arc<LaunchpoolSolanaRpcClient> {
        self.solana_rpc_client.clone()
    }

    fn cache_registry(&self) -> Arc<CacheRegistry> {
        self.cache_registry.clone()
    }
}