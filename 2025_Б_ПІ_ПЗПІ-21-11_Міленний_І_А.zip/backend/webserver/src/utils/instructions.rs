use solana_sdk::{pubkey::Pubkey, instruction::Instruction, compute_budget::ComputeBudgetInstruction, system_instruction};
use solana_sdk::bpf_loader_upgradeable::close;
use solana_sdk::instruction::AccountMeta;
use spl_token::instruction::TokenInstruction;
use crate::utils::constants::{ASSOCIATED_TOKEN_PROGRAM_ID, NATIVE_MINT, SYSTEM_PROGRAM_ID, TOKEN_PROGRAM_ID};

pub fn set_compute_budget_ix(cu_amount: u32) -> Instruction{
    ComputeBudgetInstruction::set_compute_unit_limit(cu_amount)
}
pub fn wrap_sol(signer: &Pubkey, recipient_ata: &Pubkey, lamports: u64) -> [Instruction; 3]{
    let create_associated_token_account_idempotent = Instruction {
        program_id: ASSOCIATED_TOKEN_PROGRAM_ID,
        accounts: vec![
            AccountMeta::new(*signer, true),
            AccountMeta::new(*recipient_ata, false),
            AccountMeta::new_readonly(*signer, false),
            AccountMeta::new_readonly(NATIVE_MINT, false),
            AccountMeta::new_readonly(SYSTEM_PROGRAM_ID, false),
            AccountMeta::new_readonly(TOKEN_PROGRAM_ID, false),
        ],
        data: vec![1],
    };
    let transfer = system_instruction::transfer(
        signer,
        recipient_ata,
        lamports,
    );
    let sync_native = Instruction {
        program_id: TOKEN_PROGRAM_ID,
        accounts: vec![AccountMeta::new(*recipient_ata, false)],
        data: TokenInstruction::SyncNative.pack(),
    };
    [create_associated_token_account_idempotent, transfer, sync_native]
}
pub fn unwrap_sol(sender: &Pubkey, sender_ata: &Pubkey) -> Instruction{
    let mut accounts = Vec::with_capacity(4);
    accounts.push(AccountMeta::new(*sender_ata, false));
    accounts.push(AccountMeta::new(*sender, false));
    accounts.push(AccountMeta::new_readonly(
        *sender,
        true,
    ));
    Instruction {
        program_id: TOKEN_PROGRAM_ID,
        accounts,
        data: TokenInstruction::CloseAccount.pack()
    }
}