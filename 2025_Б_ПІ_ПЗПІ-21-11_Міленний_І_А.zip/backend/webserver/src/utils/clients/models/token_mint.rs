use serde::{Deserialize, Serialize};
use solana_sdk::account::Account;
use solana_sdk::program_error::ProgramError;
use solana_sdk::program_pack::Pack;
use solana_sdk::pubkey::Pubkey;
use spl_token::state::Mint;
use spl_token_2022::extension::{BaseStateWithExtensions, StateWithExtensions};
use spl_token_2022::extension::transfer_fee::TransferFeeConfig;
use crate::utils::constants::{TOKEN_PROGRAM_ID, TOKEN_PROGRAM_2022_ID};

#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct TokenMint{
    decimals: u8,
    transfer_fee_basis_points: u16,
    supply: String,
    maximum_fee: String,
    #[serde(with = "serde_with::As::<serde_with::DisplayFromStr>")]
    program: Pubkey
}

impl TryFrom<Account> for TokenMint {
    type Error = ProgramError;

    fn try_from(value: Account) -> Result<Self, Self::Error> {
        let Account {mut data, owner, ..} = value;
        if owner == TOKEN_PROGRAM_ID {
            let mint = Mint::unpack(&data)?;
            Ok(TokenMint{
                decimals: mint.decimals,
                supply: mint.supply.to_string(),
                transfer_fee_basis_points: 0,
                maximum_fee: "0".to_string(),
                program: owner
            })
        }
        else if owner == TOKEN_PROGRAM_2022_ID{
            let mint_data = StateWithExtensions::<spl_token_2022::state::Mint>::unpack(&data)?;
            let option_fee = mint_data.get_extension::<TransferFeeConfig>().map(|transfer_fee_config| transfer_fee_config.older_transfer_fee).ok();
            Ok(TokenMint{
                decimals: mint_data.base.decimals,
                supply: mint_data.base.supply.to_string(),
                transfer_fee_basis_points: option_fee.map(|fee| u16::from_le_bytes(fee.transfer_fee_basis_points.0)).unwrap_or(0),
                maximum_fee: option_fee.map(|fee| u64::from_le_bytes(fee.maximum_fee.0)).unwrap_or(0).to_string(),
                program: owner
            })
        }
        else{
            Err(ProgramError::IncorrectProgramId)
        }
    }
}
impl TokenMint{
    pub fn program(&self) -> &Pubkey {
        &self.program
    }
}