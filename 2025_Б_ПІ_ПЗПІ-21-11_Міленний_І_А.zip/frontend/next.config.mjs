import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({
    path: path.resolve(__dirname, "../.env.routes"),
});

const makePublic = (keys) =>
    keys.reduce((env, key) => {
        env[`NEXT_PUBLIC_${key}`] = process.env[key];
        return env;
    }, {});

const launchpoolKeys = [
    "LAUNCHPOOL_SCOPE",
    "INIT_LAUNCHPOOL_CONFIGS_MANAGER",
    "UPDATE_LAUNCHPOOL_CONFIGS_MANAGER_AUTHORITY",
    "UPDATE_LAUNCHPOOL_CONFIGS_MANAGER_HEAD_AUTHORITY",
    "INIT_LAUNCHPOOLS_CONFIG",
    "UPDATE_LAUNCHPOOLS_CONFIG_REWARD_AUTHORITY",
    "UPDATE_LAUNCHPOOLS_CONFIG_PROTOCOL_REWARD_SHARE",
    "UPDATE_LAUNCHPOOLS_CONFIG_POSITION_SIZES",
    "UPDATE_LAUNCHPOOLS_CONFIG_DURATION",
    "INIT_LAUNCHPOOL",
    "LAUNCH_LAUNCHPOOL",
    "OPEN_STAKE_POSITION",
    "INCREASE_STAKE_POSITION",
    "CLOSE_STAKE_POSITION",
    "COLLECT_PROTOCOL_REWARD",
    "FETCH_LAUNCHPOOLS_CONFIGS_MANAGER_VM",
    "FETCH_LAUNCHPOOLS_CONFIGS_ADDRESSES",
    "FETCH_LAUNCHPOOLS_CONFIG_VM",
    "FETCH_LAUNCHPOOLS_CONFIG_VMS",
    "FETCH_ACTIVE_LAUNCHPOOL_ROWS",
    "FETCH_INITIALIZED_LAUNCHPOOL_ROWS",
    "FETCH_LAUNCHPOOL_VM",
    "FETCH_STAKE_POSITION_VM",
    "FETCH_STAKE_POSITION_VMS_BY_USER",
    "FETCH_TOKEN_MINT_WITH_ATA_BALANCE"
];

const liquidityKeys = [
    "LIQUIDITY_POOL_SCOPE",
    "INIT_AMMS_CONFIGS_MANAGER",
    "UPDATE_AMMS_CONFIGS_MANAGER_AUTHORITY",
    "UPDATE_AMMS_CONFIGS_MANAGER_HEAD_AUTHORITY",
    "INIT_AMMS_CONFIG",
    "UPDATE_AMMS_CONFIG_FEE_AUTHORITY",
    "UPDATE_AMMS_CONFIG_PROTOCOL_FEE_RATE",
    "UPDATE_AMMS_CONFIG_PROVIDERS_FEE_RATE",
    "CREATE_CP_AMM",
    "INIT_CP_AMM",
    "LAUNCH_CP_AMM",
    "PROVIDE_TO_CP_AMM",
    "WITHDRAW_FROM_CP_AMM",
    "SWAP_IN_CP_AMM",
    "COLLECT_FEES_FROM_CP_AMM",
    "FETCH_AMMS_CONFIGS_MANAGER_VM",
    "FETCH_AMMS_CONFIGS_ADDRESSES",
    "FETCH_AMMS_CONFIG_VM",
    "FETCH_AMMS_CONFIG_VMS",
    "FETCH_LAUNCHED_CP_AMM_ROWS",
    "FETCH_TOKEN_MINT_WITH_ATA_BALANCE",
    "FETCH_CP_AMM_VM",
    "CP_AMM_TRADES_WS",
    "USER_TRADES_WS"
];

const nextConfig = {
    reactStrictMode: false,

    async redirects() {
        return [
            {
                source: '/',
                destination: '/liquidity-pools',
                permanent: false,
            },
        ];
    },

    env: {
        ...makePublic(launchpoolKeys),
        ...makePublic(liquidityKeys),
    },
};

export default nextConfig;
