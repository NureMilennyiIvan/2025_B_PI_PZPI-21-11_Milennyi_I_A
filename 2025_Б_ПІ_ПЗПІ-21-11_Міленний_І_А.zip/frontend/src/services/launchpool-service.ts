import {PublicKey} from "@solana/web3.js";
import {post, postBase64Tx, postBase64TxAndPubkey} from "@/helpers";
import {useQuery} from "@tanstack/react-query";
import {LaunchpoolsConfigsManagerVM} from "@/models/launchpools-configs-manager-vm";
import {LaunchpoolRow} from "@/models/launchpool-row";
import {LaunchpoolsConfigVM} from "@/models/launchpools-config-vm";
import BN from "bn.js";
import {LaunchpoolsConfigAddress} from "@/models/launchpools-config-address";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import {LaunchpoolVM} from "@/models/launchpool-vm";
import {StakePositionVM} from "@/models/stake-position-vm";

export type LaunchpoolRoutes = {
    baseUrl: string;
    routes: {
        LAUNCHPOOL_SCOPE: string;
        INIT_LAUNCHPOOL_CONFIGS_MANAGER: string;
        UPDATE_LAUNCHPOOL_CONFIGS_MANAGER_AUTHORITY: string;
        UPDATE_LAUNCHPOOL_CONFIGS_MANAGER_HEAD_AUTHORITY: string;
        INIT_LAUNCHPOOLS_CONFIG: string;
        UPDATE_LAUNCHPOOLS_CONFIG_REWARD_AUTHORITY: string;
        UPDATE_LAUNCHPOOLS_CONFIG_PROTOCOL_REWARD_SHARE: string;
        UPDATE_LAUNCHPOOLS_CONFIG_DURATION: string;
        UPDATE_LAUNCHPOOLS_CONFIG_POSITION_SIZES: string;
        INIT_LAUNCHPOOL: string;
        LAUNCH_LAUNCHPOOL: string;
        OPEN_STAKE_POSITION: string;
        INCREASE_STAKE_POSITION: string;
        CLOSE_STAKE_POSITION: string;
        COLLECT_PROTOCOL_REWARD: string;
        FETCH_LAUNCHPOOLS_CONFIGS_MANAGER_VM: string;
        FETCH_LAUNCHPOOLS_CONFIGS_ADDRESSES: string;
        FETCH_LAUNCHPOOLS_CONFIG_VM: string;
        FETCH_LAUNCHPOOLS_CONFIG_VMS: string;
        FETCH_ACTIVE_LAUNCHPOOL_ROWS: string;
        FETCH_INITIALIZED_LAUNCHPOOL_ROWS: string;
        FETCH_LAUNCHPOOL_VM: string;
        FETCH_STAKE_POSITION_VM: string;
        FETCH_STAKE_POSITION_VMS_BY_USER: string;
        FETCH_TOKEN_MINT_WITH_ATA_BALANCE: string;
    };
}

export class LaunchpoolService {
    private readonly routes: LaunchpoolRoutes;

    constructor(routes: LaunchpoolRoutes) {
        this.routes = routes;
    }

    private getRoute(template: string, params: Record<string, string>): string {
        return Object.entries(params).reduce(
            (route, [key, value]) => route.replace(`{${key}}`, value),
            template
        );
    }
    fetchTokenMintWithAtaBalance = (mint: PublicKey | undefined, user: PublicKey | undefined) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["mintWithAta", mint, user],
            queryFn: async (): Promise<TokenWithAtaBalance | null> => {
                const route = this.getRoute(this.routes.routes.FETCH_TOKEN_MINT_WITH_ATA_BALANCE, {
                    mint: mint!.toString()
                });
                const response: any = (await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
                    user: user?.toBase58() ?? null
                }));
                return TokenWithAtaBalance.tryFromJSON(response)
            },
            enabled: !!mint,
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 2_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchLaunchpoolsConfigsManagerVM = () => {
        const { data, isLoading, error } = useQuery({
            queryKey: ["launchpoolsConfigsManagerVM"],
            queryFn: async (): Promise<LaunchpoolsConfigsManagerVM> => {
                //return Promise.resolve(LaunchpoolsConfigsManagerVM.mock());
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, this.routes.routes.FETCH_LAUNCHPOOLS_CONFIGS_MANAGER_VM, {});
                return LaunchpoolsConfigsManagerVM.fromJSON(response);
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });
        return { data, isLoading, error };
    };
    fetchLaunchpoolsConfigsAddresses = (limit?: number) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["launchpoolsConfigsAddresses", limit],
            queryFn: async (): Promise<LaunchpoolsConfigAddress[]> => {
/*                return Promise.resolve([
                    LaunchpoolsConfigAddress.mock(),
                    LaunchpoolsConfigAddress.mock(),
                    LaunchpoolsConfigAddress.mock()
                ]);*/
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, this.routes.routes.FETCH_LAUNCHPOOLS_CONFIGS_ADDRESSES, {
                    limit: limit ?? null
                });
                return (response as any[]).map(addr => LaunchpoolsConfigAddress.fromJSON(addr));
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchLaunchpoolsConfigVM = (address: PublicKey) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["launchpoolsConfigVM", address],
            queryFn: async (): Promise<LaunchpoolsConfigVM> => {
/*                return Promise.resolve(
                    LaunchpoolsConfigVM.mock()
                );*/
                const route = this.getRoute(this.routes.routes.FETCH_LAUNCHPOOLS_CONFIG_VM, {
                    launchpools_config: address.toBase58()
                });
                const response = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {});
                return LaunchpoolsConfigVM.fromJSON(response);
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchLaunchpoolsConfigVMs = (limit?: number) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["launchpoolsConfigVMs", limit],
            queryFn: async (): Promise<LaunchpoolsConfigVM[]> => {
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, this.routes.routes.FETCH_LAUNCHPOOLS_CONFIG_VMS, {
                    limit: limit ?? null
                });
                return (response as any[]).map(addr => LaunchpoolsConfigVM.fromJSON(addr));
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchActiveLaunchpoolRows = (limit?: number, stakableMint?: PublicKey) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["launchpoolRows", limit, stakableMint],
            queryFn: async (): Promise<LaunchpoolRow[]> => {
  /*              return Promise.resolve([
                    LaunchpoolRow.mock(),
                    LaunchpoolRow.mock(),
                    LaunchpoolRow.mock(),
                    LaunchpoolRow.mock(),
                    LaunchpoolRow.mock(),
                ]);*/
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, this.routes.routes.FETCH_ACTIVE_LAUNCHPOOL_ROWS, {
                    limit: limit ?? null,
                    stakable_mint: stakableMint?.toBase58() ?? null
                });
                return (response as any[]).map(addr => LaunchpoolRow.fromJSON(addr));
            },
            gcTime: 60_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1,
        });
        return { data, isLoading, error, };
    };
    fetchInitializedLaunchpoolRows = (limit?: number,) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["initializedLaunchpoolRows", limit],
            queryFn: async (): Promise<LaunchpoolRow[]> => {
                /*              return Promise.resolve([
                                  LaunchpoolRow.mock(),
                                  LaunchpoolRow.mock(),
                                  LaunchpoolRow.mock(),
                                  LaunchpoolRow.mock(),
                                  LaunchpoolRow.mock(),
                              ]);*/
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, this.routes.routes.FETCH_INITIALIZED_LAUNCHPOOL_ROWS, {
                    limit: limit ?? null,
                });
                return (response as any[]).map(addr => LaunchpoolRow.fromJSON(addr));
            },
            gcTime: 60_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1,
        });
        return { data, isLoading, error, };
    };

    fetchLaunchpoolVM = (launchpool: PublicKey | undefined, user: PublicKey | undefined) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["launchpoolVM", launchpool, user],
            queryFn: async (): Promise<LaunchpoolVM> => {
                const route = this.getRoute(this.routes.routes.FETCH_LAUNCHPOOL_VM, {
                    launchpool: launchpool!.toString()
                });
                const response: any = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
                    user: user?.toBase58() ?? null
                });
                return LaunchpoolVM.fromJSON(response)
            },
            enabled: !!launchpool,
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 1_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchStakePositionsVMsByUser = (user: PublicKey) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["stakePositionVMs", user],
            queryFn: async (): Promise<StakePositionVM[]> => {
                const route = this.getRoute(this.routes.routes.FETCH_STAKE_POSITION_VMS_BY_USER, {
                    user: user.toString()
                });
                const response: any[] = await post(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {}) as any[];
                return (response as any[]).map(addr => StakePositionVM.fromJSON(addr));
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 2_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    async updateLaunchpoolsConfigsManagerAuthority(authority: PublicKey, new_authority: PublicKey): Promise<string> {
/*        return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE,
            this.routes.routes.UPDATE_LAUNCHPOOL_CONFIGS_MANAGER_AUTHORITY, {
                authority: authority.toBase58(),
                new_authority: new_authority.toBase58()
            });
    }

    async updateLaunchpoolsConfigsManagerHeadAuthority(head_authority: PublicKey, new_head_authority: PublicKey): Promise<string> {
/*        return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE,
            this.routes.routes.UPDATE_LAUNCHPOOL_CONFIGS_MANAGER_HEAD_AUTHORITY, {
                head_authority: head_authority.toBase58(),
                new_head_authority: new_head_authority.toBase58()
            });
    }

    async initializeLaunchpoolsConfig(
        authority: PublicKey,
        launchpoolsConfigsManager: PublicKey,
        rewardAuthority: PublicKey,
        stakableMint: PublicKey,
        minPositionSize: BN,
        maxPositionSize: BN,
        protocolRewardShareBasisPoints: number,
        duration: BN
    ): Promise<[string, string]> {
/*        return ["LUdyIDNFQg==\n" +
        "K0kuMmV0dlZd\n" +
        "d2tRKks4NXk+VidiL0dXSQ==\n" +
        "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
        "TE58JDRlLGA=", ""];*/
        const route = this.getRoute(this.routes.routes.INIT_LAUNCHPOOLS_CONFIG, {
            launchpools_configs_manager: launchpoolsConfigsManager.toString()
        });
        return postBase64TxAndPubkey(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            reward_authority: rewardAuthority.toBase58(),
            stakable_mint: stakableMint.toBase58(),
            min_position_size: minPositionSize.toString(),
            max_position_size: maxPositionSize.toString(),
            protocol_reward_share_basis_points: protocolRewardShareBasisPoints,
            duration: duration.toString()
        });
    }

    async updateLaunchpoolsConfigRewardAuthority(launchpoolsConfig: PublicKey, authority: PublicKey, newRewardAuthority: PublicKey): Promise<string> {
        const route = this.getRoute(this.routes.routes.UPDATE_LAUNCHPOOLS_CONFIG_REWARD_AUTHORITY, {
            launchpools_config: launchpoolsConfig.toString()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_reward_authority: newRewardAuthority.toBase58()
        });
    }

    async updateLaunchpoolsConfigProtocolRewardShare(launchpoolsConfig: PublicKey, authority: PublicKey, newProtocolRewardShareBasisPoints: number): Promise<string> {
        const route = this.getRoute(this.routes.routes.UPDATE_LAUNCHPOOLS_CONFIG_PROTOCOL_REWARD_SHARE, {
            launchpools_config: launchpoolsConfig.toBase58()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_protocol_reward_share_basis_points: newProtocolRewardShareBasisPoints
        });
    }

    async updateLaunchpoolsConfigDuration(launchpoolsConfig: PublicKey, authority: PublicKey, newDuration: BN): Promise<string> {
        const route = this.getRoute(this.routes.routes.UPDATE_LAUNCHPOOLS_CONFIG_DURATION, {
            launchpools_config: launchpoolsConfig.toString()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_duration: newDuration.toString()
        });
    }

    async updateLaunchpoolsConfigPositionSizes(launchpoolsConfig: PublicKey, authority: PublicKey, newMinPositionSize: BN, newMaxPositionSize: BN): Promise<string> {
        const route = this.getRoute(this.routes.routes.UPDATE_LAUNCHPOOLS_CONFIG_POSITION_SIZES, {
            launchpools_config: launchpoolsConfig.toBase58()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_min_position_size: newMinPositionSize.toString(),
            new_max_position_size: newMaxPositionSize.toString()
        });
    }

    async initializeLaunchpool(
        authority: PublicKey,
        launchpoolsConfig: PublicKey,
        rewardMint: PublicKey,
        initialRewardAmount: BN
    ): Promise<[string, string]> {
        const route = this.getRoute(this.routes.routes.INIT_LAUNCHPOOL, {
            launchpools_config: launchpoolsConfig.toString()
        });
        return postBase64TxAndPubkey(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            reward_mint: rewardMint.toBase58(),
            initial_reward_amount: initialRewardAmount.toString()
        });
    }

    async launchLaunchpool(authority: PublicKey, launchpool: PublicKey, startTimestamp: number): Promise<string> {
        const route = this.getRoute(this.routes.routes.LAUNCH_LAUNCHPOOL, {
            launchpool: launchpool.toBase58()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            authority: authority.toBase58(),
            start_timestamp: startTimestamp.toString()
        });
    }

    async openStakePosition(
        signer: PublicKey,
        signerStakableAccount: PublicKey | null,
        launchpool: PublicKey,
        stakeAmount: BN
    ): Promise<[string, string]> {
        const route = this.getRoute(this.routes.routes.OPEN_STAKE_POSITION, {
            launchpool: launchpool.toBase58()
        });
        console.log(signerStakableAccount?.toBase58() ?? null)
        return postBase64TxAndPubkey(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            signer: signer.toBase58(),
            signer_stakable_account: signerStakableAccount?.toBase58() ?? null,
            stake_amount: stakeAmount.toString()
        });
    }

    async increaseStakePosition(
        signer: PublicKey,
        signerStakableAccount: PublicKey | null,
        stakePosition: PublicKey,
        stakeIncreaseAmount: BN
    ): Promise<string> {
        const route = this.getRoute(this.routes.routes.INCREASE_STAKE_POSITION, {
            stake_position: stakePosition.toBase58()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            signer: signer.toBase58(),
            signer_stakable_account: signerStakableAccount?.toBase58() ?? null,
            stake_increase_amount: stakeIncreaseAmount.toString()
        });
    }

    async closeStakePosition(
        signer: PublicKey,
        signerStakableAccount: PublicKey | null,
        stakePosition: PublicKey
    ): Promise<string> {
        const route = this.getRoute(this.routes.routes.CLOSE_STAKE_POSITION, {
            stake_position: stakePosition.toBase58()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            signer: signer.toBase58(),
            signer_stakable_account: signerStakableAccount?.toBase58() ?? null,
        });
    }

    async collectProtocolReward(signer: PublicKey, launchpool: PublicKey): Promise<string> {
        const route = this.getRoute(this.routes.routes.COLLECT_PROTOCOL_REWARD, {
            launchpool: launchpool.toBase58()
        });
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LAUNCHPOOL_SCOPE, route, {
            signer: signer.toBase58()
        });
    }
}