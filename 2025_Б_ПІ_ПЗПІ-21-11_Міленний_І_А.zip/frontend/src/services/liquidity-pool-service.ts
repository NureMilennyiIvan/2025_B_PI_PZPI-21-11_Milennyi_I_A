import {AmmsConfigsManagerVM} from "@/models/amms-configs-manager-vm";
import {useQuery} from "@tanstack/react-query";
import {CpAmmRow} from "@/models/cp-amm-row";
import {PublicKey} from "@solana/web3.js";
import {AmmsConfigVM} from "@/models/amms-config-vm";
import {post, postBase64Tx, postBase64TxAndPubkey} from "@/helpers";
import {AmmsConfigAddress} from "@/models/amms-config-address";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import BN from "bn.js";
import {CpAmmVM} from "@/models/cp-amm-vm";

export type LiquidityPoolRoutes = {
    baseUrl: string;
    wsUrl: string;
    routes: {
        LIQUIDITY_POOL_SCOPE: string;
        INIT_AMMS_CONFIGS_MANAGER: string;
        UPDATE_AMMS_CONFIGS_MANAGER_AUTHORITY: string;
        UPDATE_AMMS_CONFIGS_MANAGER_HEAD_AUTHORITY: string;
        INIT_AMMS_CONFIG: string;
        UPDATE_AMMS_CONFIG_FEE_AUTHORITY: string;
        UPDATE_AMMS_CONFIG_PROTOCOL_FEE_RATE: string,
        UPDATE_AMMS_CONFIG_PROVIDERS_FEE_RATE: string;
        CREATE_CP_AMM: string;
        PROVIDE_TO_CP_AMM: string;
        WITHDRAW_FROM_CP_AMM: string;
        SWAP_IN_CP_AMM: string;
        COLLECT_FEES_FROM_CP_AMM: string;
        FETCH_AMMS_CONFIGS_MANAGER_VM: string;
        FETCH_AMMS_CONFIGS_ADDRESSES: string;
        FETCH_AMMS_CONFIG_VM: string;
        FETCH_AMMS_CONFIG_VMS: string;
        FETCH_LAUNCHED_CP_AMM_ROWS: string;
        FETCH_TOKEN_MINT_WITH_ATA_BALANCE: string;
        FETCH_CP_AMM_VM: string;
        CP_AMM_TRADES_WS: string;
        USER_TRADES_WS: string
    };
}

export class LiquidityPoolService {
    private readonly routes: LiquidityPoolRoutes;

    constructor(routes: LiquidityPoolRoutes) {
        this.routes = routes;
    }

    private getRoute(template: string, params: Record<string, string>): string {
        return Object.entries(params).reduce(
            (route, [key, value]) => route.replace(`{${key}}`, value),
            template
        );
    }
    fetchTokenMintWithAtaBalance = (mint: PublicKey | undefined, user: PublicKey | undefined) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["mintWithAta", mint, user],
            queryFn: async (): Promise<TokenWithAtaBalance | null> => {
                const route = this.getRoute(this.routes.routes.FETCH_TOKEN_MINT_WITH_ATA_BALANCE, {
                    mint: mint!.toString()
                });
                const response: any = (await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
                    user: user?.toBase58() ?? null
                }));
                return TokenWithAtaBalance.tryFromJSON(response)
            },
            enabled: !!mint,
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 2_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchAmmsConfigsManagerVM = () => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["ammsConfigsManagerVM"],
            queryFn: async (): Promise<AmmsConfigsManagerVM> => {
                //return Promise.resolve(AmmsConfigsManagerVM.mock());
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, this.routes.routes.FETCH_AMMS_CONFIGS_MANAGER_VM, {});
                return AmmsConfigsManagerVM.fromJSON(response);
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchAmmsConfigsAddresses = (limit?: number) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["ammsConfigsAddresses", limit],
            queryFn: async (): Promise<AmmsConfigAddress[]> => {
/*                return Promise.resolve([
                    AmmsConfigAddress.mock(),
                    AmmsConfigAddress.mock(),
                    AmmsConfigAddress.mock()
                ]);*/
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, this.routes.routes.FETCH_AMMS_CONFIGS_ADDRESSES, {
                    limit: limit ?? null
                });
                return (response as any[]).map(addr => AmmsConfigAddress.fromJSON(addr));
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchAmmsConfigVMs = (limit?: number) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["ammsConfigVMs", limit],
            queryFn: async (): Promise<AmmsConfigVM[]> => {
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, this.routes.routes.FETCH_AMMS_CONFIG_VMS, {
                    limit: limit ?? null
                });
                return (response as any[]).map(addr => AmmsConfigVM.fromJSON(addr));
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchAmmsConfigVM = (address: PublicKey) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["ammsConfigVM", address],
            queryFn: async (): Promise<AmmsConfigVM> => {
/*                return Promise.resolve(
                    AmmsConfigVM.mock()
                );*/
                const route = this.getRoute(this.routes.routes.FETCH_AMMS_CONFIG_VM, {
                    amms_config: address.toBase58()
                });
                const response = await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {});
                return AmmsConfigVM.fromJSON(response);
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 10_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    fetchCpAmmRows = (limit?: number, baseMint?: PublicKey, quoteMint?: PublicKey) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["cpAmmRows", limit, baseMint, quoteMint],
            queryFn: async (): Promise<CpAmmRow[]> => {
/*                return Promise.resolve([
                    CpAmmRow.mock(),
                    CpAmmRow.mock(),
                    CpAmmRow.mock(),
                    CpAmmRow.mock(),
                    CpAmmRow.mock(),
                ]);*/
                const response: unknown = await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, this.routes.routes.FETCH_LAUNCHED_CP_AMM_ROWS, {
                    limit: limit ?? null,
                    base_mint: baseMint?.toBase58() ?? null,
                    quote_mint: quoteMint?.toBase58() ?? null
                });
                return (response as any[]).map(addr => CpAmmRow.fromJSON(addr));

            },
            gcTime: 60_000,
            refetchOnWindowFocus: true,
            refetchInterval: 30_000,
            retry: 1,
        });

        return { data, isLoading, error, };
    };
    fetchCpAmmVM = (cp_amm: PublicKey, user: PublicKey | undefined) => {
        const { data, isLoading, error, } = useQuery({
            queryKey: ["cpAmmVM", cp_amm, user],
            queryFn: async (): Promise<CpAmmVM> => {
                const route = this.getRoute(this.routes.routes.FETCH_CP_AMM_VM, {
                    cp_amm: cp_amm.toString()
                });
                const response: any = await post(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
                    user: user?.toBase58() ?? null
                });
                return CpAmmVM.fromJSON(response)
            },
            gcTime: 10_000,
            refetchOnWindowFocus: true,
            refetchInterval: 1_000,
            retry: 1
        });

        return { data, isLoading, error, };
    };
    getCpAmmTradesWS = (cp_amm: PublicKey) =>{
        const route = this.getRoute(this.routes.routes.CP_AMM_TRADES_WS, {
            cp_amm: cp_amm.toString()
        });
        return new WebSocket(`${this.routes.wsUrl}${this.routes.routes.LIQUIDITY_POOL_SCOPE}${route}`);
    }
    getUserTradesWS = (user: PublicKey) =>{
        const route = this.getRoute(this.routes.routes.USER_TRADES_WS, {
            user: user.toString()
        });
        return new WebSocket(`${this.routes.wsUrl}${this.routes.routes.LIQUIDITY_POOL_SCOPE}${route}`);
    }
    updateAmmsConfigsManagerAuthority = async (authority: PublicKey, new_authority: PublicKey) => {
/*        return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        return await postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, this.routes.routes.UPDATE_AMMS_CONFIGS_MANAGER_AUTHORITY, {
            authority: authority.toBase58(),
            new_authority: new_authority.toBase58()
        });
    }
    updateAmmsConfigsManagerHeadAuthority = async (authority: PublicKey, new_authority: PublicKey) => {
/*        return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        return await postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, this.routes.routes.UPDATE_AMMS_CONFIGS_MANAGER_HEAD_AUTHORITY, {
            head_authority: authority.toBase58(),
            new_head_authority: new_authority.toBase58()
        });
    }

    initializeAmmsConfig = async (
        authority: PublicKey,
        amms_configs_manager: PublicKey,
        fee_authority: PublicKey,
        protocol_fee_rate_basis_points: number,
        providers_fee_rate_basis_points: number
    ): Promise<[string,string]> => {
/*        return ["LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=", ""];*/
        const route = this.routes.routes.INIT_AMMS_CONFIG.replace(
            "{amms_configs_manager}",
            amms_configs_manager.toString()
        );
        return postBase64TxAndPubkey(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            authority: authority.toBase58(),
            fee_authority: fee_authority.toBase58(),
            protocol_fee_rate_basis_points,
            providers_fee_rate_basis_points
        });
    };

    updateAmmsConfigFeeAuthority = async (authority: PublicKey,  amms_config: PublicKey, new_fee_authority: PublicKey) => {
/*        return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        const route = this.routes.routes.UPDATE_AMMS_CONFIG_FEE_AUTHORITY.replace(
            "{amms_config}",
            amms_config.toBase58()
        );
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_fee_authority: new_fee_authority.toBase58()
        });
    }

    updateAmmsConfigProtocolFeeRate = async (authority: PublicKey,  amms_config: PublicKey, newProtocolFeeRateBasisPoints: number) => {
       /* return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        const route = this.routes.routes.UPDATE_AMMS_CONFIG_PROTOCOL_FEE_RATE.replace(
            "{amms_config}",
            amms_config.toBase58()
        );
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_protocol_fee_rate_basis_points: newProtocolFeeRateBasisPoints
        });
    }
    updateAmmsConfigProvidersFeeRate = async (authority: PublicKey,  amms_config: PublicKey, newProvidersFeeRateBasisPoints: number) => {
/*        return "LUdyIDNFQg==\n" +
            "K0kuMmV0dlZd\n" +
            "d2tRKks4NXk+VidiL0dXSQ==\n" +
            "Y1EkWjg0RCBiT1c1QDlAcSM8TiU1KEJvTQ==\n" +
            "TE58JDRlLGA=";*/
        const route = this.routes.routes.UPDATE_AMMS_CONFIG_PROVIDERS_FEE_RATE.replace(
            "{amms_config}",
            amms_config.toBase58()
        );
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            authority: authority.toBase58(),
            new_providers_fee_rate_basis_points: newProvidersFeeRateBasisPoints
        });
    }

    createCpAmm = async (
        creator: PublicKey,
        amms_config: PublicKey,
        base_mint: PublicKey,
        quote_mint: PublicKey,
        base_liquidity: BN,
        quote_liquidity: BN
    ): Promise<[string,string]> => {
        const route = this.routes.routes.CREATE_CP_AMM.replace("{amms_config}", amms_config.toString());
        return postBase64TxAndPubkey(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            signer: creator.toString(),
            base_mint: base_mint.toString(),
            quote_mint: quote_mint.toString(),
            base_liquidity: base_liquidity.toString(),
            quote_liquidity: quote_liquidity.toString()
        });
    };

    provideToCpAmm = async (
        signer: PublicKey,
        cp_amm: PublicKey,
        base_liquidity: BN,
        quote_liquidity: BN
    ): Promise<string> => {
        const route = this.routes.routes.PROVIDE_TO_CP_AMM.replace("{cp_amm}", cp_amm.toString());
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            signer: signer.toString(),
            base_liquidity: base_liquidity.toString(),
            quote_liquidity: quote_liquidity.toString()
        });
    };

    withdrawFromCpAmm = async (
        signer: PublicKey,
        cp_amm: PublicKey,
        lp_tokens: BN
    ): Promise<string> => {
        const route = this.routes.routes.WITHDRAW_FROM_CP_AMM.replace("{cp_amm}", cp_amm.toString());
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            signer: signer.toString(),
            lp_tokens: lp_tokens.toString()
        });
    };

    swapInCpAmm = async (
        signer: PublicKey,
        cp_amm: PublicKey,
        swap_amount: BN,
        estimated_result: BN,
        allowed_slippage: BN,
        is_in_out: boolean
    ): Promise<string> => {
        const route = this.routes.routes.SWAP_IN_CP_AMM.replace("{cp_amm}", cp_amm.toString());
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            signer: signer.toString(),
            swap_amount: swap_amount.toString(),
            estimated_result: estimated_result.toString(),
            allowed_slippage: allowed_slippage.toString(),
            is_in_out
        });
    };

    collectFeesFromCpAmm = async (
        signer: PublicKey,
        cp_amm: PublicKey,
    ): Promise<string> => {
        const route = this.routes.routes.COLLECT_FEES_FROM_CP_AMM.replace("{cp_amm}", cp_amm.toString());
        return postBase64Tx(this.routes.baseUrl, this.routes.routes.LIQUIDITY_POOL_SCOPE, route, {
            signer: signer.toString()
        });
    };

}