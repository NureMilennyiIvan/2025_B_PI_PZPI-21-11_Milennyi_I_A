import React from "react";
import {BN} from "@coral-xyz/anchor";
import {PublicKey} from "@solana/web3.js";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";

export const handleTokenInputChange = (e: React.ChangeEvent<HTMLInputElement>, setTokenInput: React.Dispatch<React.SetStateAction<string>>) => {
    const newValue = e.target.value;
    const regex = /^(0|([1-9]\d*))(\.\d+)?$/;
    const dotCount = (newValue.match(/\./g) || []).length;
    if (
        dotCount <= 1 &&
        (
            regex.test(newValue) ||
            newValue === "" ||
            (newValue.endsWith('.') && newValue.length > 1)
        ) &&
        newValue.length < 15
    ) {
        setTokenInput(newValue);
    }
};
export const handlePercentageAmountClick = (tokenData: TokenWithAtaBalance, percentage: number, setTokenInput: React.Dispatch<React.SetStateAction<string>>) => {
    const amount = tokenData.balance.mul(new BN(percentage)).div(new BN(100));
    setTokenInput(bnToString(amount, tokenData.decimals));
};

export const shortenAddress = (
    input: string | PublicKey,
    visible: number = 4
): string => {
    const address = typeof input === "string" ? input : input.toBase58();
    if (address.length <= visible * 2) return address;
    return `${address.slice(0, visible)}…${address.slice(-visible)}`;
};
export const parseStringToBN = (str: string, decimals: number): BN => {
    if (!str || str.trim() === "." || str === "") return new BN(0);

    const [intStrRaw, fracStrRaw = ""] = str.split(".");

    const intStr = intStrRaw === "" ? "0" : intStrRaw;
    const fracStr = fracStrRaw.padEnd(decimals, '0').slice(0, decimals);

    const scale = new BN(10).pow(new BN(decimals));
    const intBN = new BN(intStr).mul(scale);
    const fracBN = new BN(fracStr || "0");

    return intBN.add(fracBN);
};

export const bnToString = (value: BN, decimals: number = 0): string => {
    const scale = new BN(10).pow(new BN(decimals));
    const integerPart = value.div(scale).toString();
    const fractionalPartBN = value.mod(scale);
    const fractionalStrRaw = fractionalPartBN.toString(10).padStart(decimals, '0');
    const fractionalTrimmed = fractionalStrRaw.replace(/0+$/, '');

    return fractionalTrimmed.length > 0
        ? `${integerPart}.${fractionalTrimmed}`
        : integerPart;
};

export const shiftDecimalRight = (ratioStr: string): { int: BN, decimalPlaces: number } =>{
    const [intPart, fracPart = ""] = ratioStr.split(".");
    const digits = intPart + fracPart;
    const decimalPlaces = fracPart.length;
    return {
        int: new BN(digits.replace(/^0+(?=\d)/, "") || "0"),
        decimalPlaces
    };
}

export const handlePubkeyChange = (
    value: string,
    setStr: React.Dispatch<React.SetStateAction<string>>,
    setPubkey: React.Dispatch<React.SetStateAction<PublicKey | undefined>>
) => {
    setStr(value);
    try {
        setPubkey(new PublicKey(value));
    } catch {
        setPubkey(undefined);
    }
};