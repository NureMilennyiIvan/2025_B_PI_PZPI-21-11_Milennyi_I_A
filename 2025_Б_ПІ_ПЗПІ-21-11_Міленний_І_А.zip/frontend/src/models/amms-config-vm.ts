import { PublicKey } from "@solana/web3.js";

export class AmmsConfigVM {
    constructor(
        public key: PublicKey,
        public feeAuthority: string,
        public providersFeeRate: number,
        public protocolFeeRate: number
    ) {}

    static fromJSON(obj: any): AmmsConfigVM {
        return new AmmsConfigVM(
            new PublicKey(obj.key),
            obj.fee_authority,
            obj.providers_fee_rate_basis_points,
            obj.protocol_fee_rate_basis_points
        );
    }

    static mock(): AmmsConfigVM {
        return new AmmsConfigVM(
            PublicKey.unique(),
            PublicKey.unique().toBase58(),
            121,
            12
        );
    }

    getProvidersFeeRatesAsPercent(): string {
        return (this.providersFeeRate / 100).toFixed(2);
    }
    getProtocolFeeRatesAsPercent(): string {
        return (this.protocolFeeRate / 100).toFixed(2);
    }
}
