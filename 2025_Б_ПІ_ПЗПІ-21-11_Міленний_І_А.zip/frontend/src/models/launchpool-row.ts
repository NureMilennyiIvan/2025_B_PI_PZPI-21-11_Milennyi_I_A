import { PublicKey } from "@solana/web3.js";

export class LaunchpoolRow {
    public launchpool: string;
    public launchpoolsConfig: string;
    public rewardMint: string;
    public stakableMint: string;

    constructor(
        launchpool: string,
        launchpoolsConfig: string,
        rewardMint: string,
        stakableMint: string,
    ) {
        this.launchpool = launchpool;
        this.launchpoolsConfig = launchpoolsConfig;
        this.rewardMint = rewardMint;
        this.stakableMint = stakableMint;
    }

    static fromJSON(json: any): LaunchpoolRow {
        return new LaunchpoolRow(
            json.launchpool,
            json.launchpools_config,
            json.reward_mint,
            json.stakable_mint,
        );
    }
    static mock(): LaunchpoolRow {
        return new LaunchpoolRow(
            PublicKey.unique().toBase58(),
            PublicKey.unique().toBase58(),
            PublicKey.unique().toBase58(),
            PublicKey.unique().toBase58(),
        );
    }
}