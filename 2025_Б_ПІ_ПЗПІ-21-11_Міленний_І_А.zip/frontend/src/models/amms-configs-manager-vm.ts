import { PublicKey } from "@solana/web3.js";

export class AmmsConfigsManagerVM {
    constructor(
        public key: PublicKey,
        public authority: string,
        public headAuthority: string
    ) {}

    static fromJSON(obj: any): AmmsConfigsManagerVM {
        return new AmmsConfigsManagerVM(
            obj.key,
            obj.authority,
            obj.head_authority
        );
    }

    toJSON(): {key: PublicKey, authority: string; headAuthority: string } {
        return {
            key: this.key,
            authority: this.authority,
            headAuthority: this.headAuthority
        };
    }
    static mock(): AmmsConfigsManagerVM {
        return new AmmsConfigsManagerVM(
            PublicKey.unique(),
            "FBKiKFe3x71qtZ9TMZvA7Qt9Vc7WBAaQS7LsePpbxGbG",
            "FBKiKFe3x71qtZ9TMZvA7Qt9Vc7WBAaQS7LsePpbxGbG",
        );
    }
}
