import { PublicKey } from "@solana/web3.js";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import BN from "bn.js";
import {StakePositionVM} from "@/models/stake-position-vm";

export class LaunchpoolVM {
    constructor(
        public launchpoolsConfig: PublicKey,
        public stakableMint: PublicKey,
        public rewardMint: PublicKey,
        public rewardVault: PublicKey,
        public stakableTokenData: TokenWithAtaBalance,
        public rewardTokenData: TokenWithAtaBalance,
        public initialRewardAmount: BN,
        public participantsRewardAmount: BN,
        public protocolRewardAmount: BN,
        public protocolRewardLeftToObtain: BN,
        public participantsRewardLeftToObtain: BN,
        public stakedAmount: BN,
        public participantsRewardLeftToDistribute: BN,
        public rewardRate: number,
        public rewardPerToken: number,
        public minPositionSize: BN,
        public maxPositionSize: BN,
        public status: "Uninitialized" | "Initialized" | "Launched" | "Finished" | "ClaimedProtocolReward",
        public duration: number,
        public startTimestamp: number,
        public endTimestamp: number,
        public lastUpdateTimestamp: number,
        public stakePositionVM: StakePositionVM | null
    ) {}

    static fromJSON(obj: any): LaunchpoolVM {
        return new LaunchpoolVM(
            new PublicKey(obj.launchpools_config),
            new PublicKey(obj.stakable_mint),
            new PublicKey(obj.reward_mint),
            new PublicKey(obj.reward_vault),
            TokenWithAtaBalance.fromJSON(obj.stakable_token_data as any[]),
            TokenWithAtaBalance.fromJSON(obj.reward_token_data as any[]),
            new BN(obj.initial_reward_amount),
            new BN(obj.participants_reward_amount),
            new BN(obj.protocol_reward_amount),
            new BN(obj.protocol_reward_left_to_obtain),
            new BN(obj.participants_reward_left_to_obtain),
            new BN(obj.staked_amount),
            new BN(obj.participants_reward_left_to_distribute),
            parseFloat(obj.reward_rate),
            parseFloat(obj.reward_per_token),
            new BN(obj.min_position_size),
            new BN(obj.max_position_size),
            obj.status,
            Number(obj.duration),
            Number(obj.start_timestamp) * 1000,
            Number(obj.end_timestamp) * 1000,
            Number(obj.last_update_timestamp) * 1000,
            StakePositionVM.tryFromJSON(obj.stake_position_vm)
        );
    }
}
