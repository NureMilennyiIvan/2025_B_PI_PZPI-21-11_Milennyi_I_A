import { PublicKey } from "@solana/web3.js";

export class CpAmmRow {
    public cpAmm: PublicKey;
    public ammsConfig: string;
    public baseMint: string;
    public quoteMint: string;
    public lpMint: string;

    constructor(
        cpAmm: PublicKey,
        ammsConfig: string,
        baseMint: string,
        quoteMint: string,
        lpMint: string,
    ) {
        this.cpAmm = cpAmm;
        this.ammsConfig = ammsConfig;
        this.baseMint = baseMint;
        this.quoteMint = quoteMint;
        this.lpMint = lpMint;
    }

    static fromJSON(json: any): CpAmmRow {
        return new CpAmmRow(
            new PublicKey(json.cp_amm),
            json.amms_config,
            json.base_mint,
            json.quote_mint,
            json.lp_mint
        );
    }
    static mock(): CpAmmRow {
        return new CpAmmRow(
            PublicKey.unique(),
            PublicKey.unique().toString(),
            PublicKey.unique().toString(),
            PublicKey.unique().toString(),
            PublicKey.unique().toString(),
        );
    }
}