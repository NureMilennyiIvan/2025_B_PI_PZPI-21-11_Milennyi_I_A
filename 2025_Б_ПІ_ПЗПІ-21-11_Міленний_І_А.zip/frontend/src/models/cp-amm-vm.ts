import { PublicKey } from "@solana/web3.js";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import BN from "bn.js";
import {shiftDecimalRight} from "@/utils";
import sqrt from "bn-sqrt";

export class CpAmmVM {
    constructor(
        public ammsConfig: PublicKey,
        public baseMint: PublicKey,
        public quoteMint: PublicKey,
        public lpMint: PublicKey,
        public feeAuthority: PublicKey,
        public baseTokenData: TokenWithAtaBalance,
        public quoteTokenData: TokenWithAtaBalance,
        public lpTokenData: TokenWithAtaBalance,
        public constantProduct: BN,
        public baseQuoteRatio: number,
        public baseLiquidity: BN,
        public quoteLiquidity: BN,
        public lpTokensSupply: BN,
        public protocolBaseFeesToRedeem: BN,
        public protocolQuoteFeesToRedeem: BN,
        public providersFeeRate: number,
        public protocolFeeRate: number
    ) {}

    static fromJSON(obj: any): CpAmmVM {
        return new CpAmmVM(
            new PublicKey(obj.amms_config),
            new PublicKey(obj.base_mint),
            new PublicKey(obj.quote_mint),
            new PublicKey(obj.lp_mint),
            new PublicKey(obj.fee_authority),
            TokenWithAtaBalance.fromJSON(obj.base_token_data as any[]),
            TokenWithAtaBalance.fromJSON(obj.quote_token_data as any[]),
            TokenWithAtaBalance.fromJSON(obj.lp_token_data as any[]),
            new BN(obj.constant_product),
            parseFloat(obj.base_quote_ratio),
            new BN(obj.base_liquidity),
            new BN(obj.quote_liquidity),
            new BN(obj.lp_tokens_supply),
            new BN(obj.protocol_base_fees_to_redeem),
            new BN(obj.protocol_quote_fees_to_redeem),
            obj.providers_fee_rate_basis_points,
            obj.protocol_fee_rate_basis_points
        );
    }
    getTotalFeeRatesAsPercent(): string {
        return ((this.providersFeeRate + this.protocolFeeRate) / 100).toFixed(2);
    }
    getProvidersFeeRatesAsPercent(): string {
        return (this.providersFeeRate / 100).toFixed(2);
    }
    getProtocolFeeRatesAsPercent(): string {
        return (this.protocolFeeRate / 100).toFixed(2);
    }
    getBasePrice(): string {
        return (1 / (this.baseQuoteRatio / (10 ** this.quoteTokenData.decimals))).toFixed(9 + this.quoteTokenData.decimals);
    }
    getQuotePrice(): string {
        return (this.baseQuoteRatio / (10 ** this.quoteTokenData.decimals)).toFixed(9 + this.quoteTokenData.decimals);
    }
    getBaseMintFeeAsPercent(): string {
        return (this.baseTokenData.transferFeeBasisPoints / 100).toFixed(2);
    }
    getQuoteMintFeeAsPercent(): string {
        return (this.quoteTokenData.transferFeeBasisPoints / 100).toFixed(2);
    }
    getLpMintFeeAsPercent(): string {
        return (this.lpTokenData.transferFeeBasisPoints / 100).toFixed(2);
    }

    calculateSwapAndFeeAmount(swapAmount: BN, slippageBasisPoints: number, isInOut: boolean){
        if (isInOut){
            let swapAmountTransferFee = swapAmount.muln(this.baseTokenData.transferFeeBasisPoints).divn(10000);
            swapAmountTransferFee = swapAmountTransferFee.gt(this.baseTokenData.maximumFee) ? this.baseTokenData.maximumFee : swapAmountTransferFee;
            const swapAmountPoolFee = swapAmount.sub(swapAmountTransferFee).muln(this.protocolFeeRate + this.providersFeeRate).divn(10000);
            const estimatedAmount = this.quoteLiquidity.sub(this.constantProduct.div(this.baseLiquidity.add(swapAmount.sub(swapAmountTransferFee).sub(swapAmountPoolFee))))
            let estimatedFee = estimatedAmount.muln(this.quoteTokenData.transferFeeBasisPoints).divn(10000);
            estimatedFee = estimatedFee.gt(this.quoteTokenData.maximumFee) ? this.quoteTokenData.maximumFee : estimatedFee;
            const estimatedAmountAfterFee = estimatedAmount.sub(estimatedFee);
            const allowedSlippage = estimatedAmountAfterFee.muln(slippageBasisPoints).divn(10000);
            return {
                estimatedFee,
                estimatedAmountAfterFee,
                allowedSlippage,
                swapAmountTransferFee,
                swapAmountPoolFee,
            };
        }
        else{
            let swapAmountTransferFee = swapAmount.muln(this.quoteTokenData.transferFeeBasisPoints).divn(10000);
            swapAmountTransferFee = swapAmountTransferFee.gt(this.quoteTokenData.maximumFee) ? this.quoteTokenData.maximumFee : swapAmountTransferFee;
            const swapAmountPoolFee = swapAmount.sub(swapAmountTransferFee).muln(this.protocolFeeRate + this.providersFeeRate).divn(10000);
            const estimatedAmount = this.baseLiquidity.sub(this.constantProduct.div(this.quoteLiquidity.add(swapAmount.sub(swapAmountTransferFee).sub(swapAmountPoolFee))))
            let estimatedFee = estimatedAmount.muln(this.baseTokenData.transferFeeBasisPoints).divn(10000);
            estimatedFee = estimatedFee.gt(this.baseTokenData.maximumFee) ? this.baseTokenData.maximumFee : estimatedFee;
            const estimatedAmountAfterFee = estimatedAmount.sub(estimatedFee);
            const allowedSlippage = estimatedAmountAfterFee.muln(slippageBasisPoints).divn(10000);
            return {
                estimatedFee,
                estimatedAmountAfterFee,
                allowedSlippage,
                swapAmountTransferFee,
                swapAmountPoolFee,
            };
        }

    }

    calculateProvide(baseProvide: BN)  {
        const { int: ratioInt, decimalPlaces } = shiftDecimalRight(this.baseQuoteRatio.toString());
        const scale = new BN(10).pow(new BN(decimalPlaces));
        const newBaseLiquidity = baseProvide.add(this.baseLiquidity);
        const newQuoteLiquidity = newBaseLiquidity.mul(scale).div(ratioInt);
        const providedQuote = newQuoteLiquidity.sub(this.quoteLiquidity);
        const newLpSupply = sqrt(newBaseLiquidity.mul(newQuoteLiquidity));
        const provideLp = newLpSupply.sub(this.lpTokensSupply);
        const shareScale = new BN(1_000_000_000);
        const share = Number(provideLp.mul(shareScale).div(newLpSupply)) / 1_000_000_0
        return {
            providedQuote,
            provideLp,
            share
        }
    }
    calculateWithdraw(withdrawLiquidity: BN)  {
        const totalLpSupply = this.lpTokensSupply;

        const withdrawBase = this.baseLiquidity.mul(withdrawLiquidity).div(totalLpSupply);
        const withdrawQuote = this.quoteLiquidity.mul(withdrawLiquidity).div(totalLpSupply);

        return {
            withdrawBase,
            withdrawQuote
        };
    }

    calculateShare(lpSupply: BN)  {
        const totalLpSupply = this.lpTokensSupply;
        const shareScale = new BN(1_000_000_000);
        const share = lpSupply.mul(shareScale).div(totalLpSupply);
        return share;
    }
}
