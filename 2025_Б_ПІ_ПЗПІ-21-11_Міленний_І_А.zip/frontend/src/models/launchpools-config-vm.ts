import { PublicKey } from "@solana/web3.js";
import BN from "bn.js";

export class LaunchpoolsConfigVM {
    constructor(
        public key: PublicKey,
        public rewardAuthority: string,
        public stakableMint: string,
        public minPositionSize: BN,
        public maxPositionSize: BN,
        public protocolRewardShareBasisPoints: number,
        public duration: number
    ) {}

    static fromJSON(obj: any): LaunchpoolsConfigVM {
        return new LaunchpoolsConfigVM(
            new PublicKey(obj.key),
            obj.reward_authority,
            obj.stakable_mint,
            new BN(obj.min_position_size),
            new BN(obj.max_position_size),
            obj.protocol_reward_share_basis_points,
            obj.duration
        );
    }

    toJSON(): {
        key: PublicKey,
        rewardAuthority: string;
        stakableMint: string;
        minPositionSize: string;
        maxPositionSize: string;
        protocolRewardShareBasisPoints: number;
        duration: number;
    } {
        return {
            key: this.key,
            rewardAuthority: this.rewardAuthority,
            stakableMint: this.stakableMint,
            minPositionSize: this.minPositionSize.toString(),
            maxPositionSize: this.maxPositionSize.toString(),
            protocolRewardShareBasisPoints: this.protocolRewardShareBasisPoints,
            duration: this.duration
        };
    }

    static mock(): LaunchpoolsConfigVM {
        return new LaunchpoolsConfigVM(
            PublicKey.unique(),
            PublicKey.unique().toBase58(),
            PublicKey.unique().toBase58(),
            new BN("1000000"),
            new BN("1000000000"),
            2500,
            3600
        );
    }

    getProtocolRewardSharePercent(): string {
        return (this.protocolRewardShareBasisPoints / 100).toFixed(2);
    }
}