import { PublicKey } from "@solana/web3.js";

export class AmmsConfigAddress {
    constructor(
        public ammsConfig: string
    ) {}

    static fromJSON(obj: any): AmmsConfigAddress {
        return new AmmsConfigAddress(
            obj.amms_config
        );
    }

    toJSON(): {
        amms_config: string;
    } {
        return {
            amms_config: this.ammsConfig
        };
    }

    static mock(): AmmsConfigAddress {
        return new AmmsConfigAddress(
            PublicKey.unique().toBase58()
        );
    }
}