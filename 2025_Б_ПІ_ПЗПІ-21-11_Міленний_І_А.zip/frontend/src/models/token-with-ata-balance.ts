import BN from "bn.js";

export class TokenWithAtaBalance {
    constructor(
        public decimals: number,
        public transferFeeBasisPoints: number,
        public maximumFee: BN,
        public balance: BN,
        public supply: BN
    ) {
    }

    static tryFromJSON(obj: any): TokenWithAtaBalance | null {
        if (obj === null || obj === undefined) {
            return null;
        }
        if (!Array.isArray(obj) || obj.length !== 2) {
            throw new Error("Invalid input: expected [mint, balance]");
        }
        const [mint, balance] = obj;

        const parsedBalance =
            (balance === null || balance === undefined ? null : new BN(balance)) ?? new BN(0);

        try {

            return new TokenWithAtaBalance(
                mint.decimals,
                mint.transfer_fee_basis_points,
                new BN(mint.maximum_fee),
                parsedBalance,
                new BN(mint.supply)
            );
        } catch (e) {
            throw new Error("Invalid mint object");
        }
    }

    static fromJSON(obj: any[]): TokenWithAtaBalance {
        if (!Array.isArray(obj) || obj.length !== 2) {
            throw new Error("Invalid input: expected [mint, balance]");
        }
        const [mint, balance] = obj;

        const parsedBalance =
            (balance === null || balance === undefined ? null : new BN(balance)) ?? new BN(0);

        try {
            return new TokenWithAtaBalance(
                mint.decimals,
                mint.transfer_fee_basis_points,
                new BN(mint.maximum_fee),
                parsedBalance,
                new BN(mint.supply)
            );
        } catch (e) {
            throw new Error("Invalid mint object");
        }

    }
}
