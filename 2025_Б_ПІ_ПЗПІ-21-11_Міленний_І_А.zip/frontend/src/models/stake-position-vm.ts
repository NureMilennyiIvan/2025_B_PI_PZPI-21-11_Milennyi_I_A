import BN from "bn.js";
import {PublicKey} from "@solana/web3.js";

export class StakePositionVM {
    constructor(
        public key: PublicKey,
        public authority: PublicKey,
        public launchpool: PublicKey,
        public amount: BN,
        public rewardEarned: BN,
        public rewardDebt: BN,
        public status: "Uninitialized" | "Initialized" | "Opened" | "Closed"
    ) {
    }

    static tryFromJSON(obj: any): StakePositionVM | null {
        if (obj === null || obj === undefined) {
            return null;
        }
        try {
            return new StakePositionVM(
                new PublicKey(obj.key),
                new PublicKey(obj.authority),
                new PublicKey(obj.launchpool),
                new BN(obj.amount),
                new BN(obj.reward_earned),
                new BN(obj.reward_debt),
                obj.status
            );
        } catch (e) {
            throw new Error("Invalid stake position object");
        }
    }
    static fromJSON(obj: any): StakePositionVM {
        try {
            return new StakePositionVM(
                new PublicKey(obj.key),
                new PublicKey(obj.authority),
                new PublicKey(obj.launchpool),
                new BN(obj.amount),
                new BN(obj.reward_earned),
                new BN(obj.reward_debt),
                obj.status
            );
        } catch (e) {
            throw new Error("Invalid stake position object");
        }
    }
}
