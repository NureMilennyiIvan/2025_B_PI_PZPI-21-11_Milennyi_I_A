import { PublicKey } from "@solana/web3.js";

export class LaunchpoolsConfigAddress {
    constructor(
        public launchpoolsConfig: string
    ) {}

    static fromJSON(obj: any): LaunchpoolsConfigAddress {
        return new LaunchpoolsConfigAddress(
            obj.launchpools_config
        );
    }

    toJSON(): {
        launchpools_config: string;
    } {
        return {
            launchpools_config: this.launchpoolsConfig
        };
    }

    static mock(): LaunchpoolsConfigAddress {
        return new LaunchpoolsConfigAddress(
            PublicKey.unique().toBase58()
        );
    }
}