import { PublicKey } from "@solana/web3.js";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import BN from "bn.js";
import {shiftDecimalRight} from "@/utils";
import sqrt from "bn-sqrt";

export class Trade {
    constructor(
        public signature: string,
        public timestamp: number,
        public swapper: PublicKey,
        public cpAmm: PublicKey,
        public swappedAmount: BN,
        public receivedAmount: BN,
        public isInOut: boolean,
    ) {}

    static fromJSON(obj: any): Trade {
        return new Trade(
            obj.signature,
            Number(obj.timestamp) * 1000,
            new PublicKey(obj.swapper),
            new PublicKey(obj.cp_amm),
            new BN(obj.swapped_amount),
            new BN(obj.received_amount),
            obj.is_in_out
        );
    }
}
