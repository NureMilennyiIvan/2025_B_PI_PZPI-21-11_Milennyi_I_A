import styles from "./styles.module.css";

interface LoadingErrorProps {
    error: Error;
}

export const LoadingError: React.FC<LoadingErrorProps> = ({error}) => {
    return (
        <div>
            <div className={styles.message}>Loading error: {error.message}</div>
        </div>
    );
};
export default LoadingError;