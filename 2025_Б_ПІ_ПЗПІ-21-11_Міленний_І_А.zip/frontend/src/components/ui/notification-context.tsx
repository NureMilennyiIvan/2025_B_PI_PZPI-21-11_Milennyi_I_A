"use client"
import {createContext, ReactNode, useContext, useState} from "react";
type NotificationType = "success" | "error";
interface Notification {
    type: NotificationType;
    message: string;
}
interface NotificationContextType {
    notify: (type: NotificationType, message: string) => void;
}
const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
    const [notification, setNotification] = useState<Notification | null>(null);

    const notify = (type: Notification["type"], message: string) => {
        setNotification({ type, message });
        setTimeout(() => setNotification(null), 4000);
    };

    return (
        <NotificationContext.Provider value={{ notify }}>
            {children}
            {notification && (
                <div style={{
                    position: "fixed",
                    bottom: "20px",
                    right: "20px",
                    padding: "12px 18px",
                    borderRadius: "8px",
                    backgroundColor: notification.type === "success" ? "#4caf50" : "#f44336",
                    color: "white",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
                    zIndex: 9999,
                    fontSize: "14px"
                }}>
                    {notification.message}
                </div>
            )}
        </NotificationContext.Provider>
    );
};

export const useNotification = () => {
    const context = useContext(NotificationContext);
    if (!context) throw new Error("useNotification must be used within NotificationProvider");
    return context;
};
