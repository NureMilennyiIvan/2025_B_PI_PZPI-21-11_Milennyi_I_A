"use client";

import {ReactNode} from "react";
import Link from "next/link";
import {WalletButton} from "@/components/solana/solana-wallet-adapter-provider";
import styles from "./styles.module.css";
import colors from "../../app/colors.module.css";
import {NotificationProvider} from "@/components/ui/notification-context";
import {usePublicKey} from "@/components/solana/solana-context-wrapper";

export const links = {
    launchpools: {label: "Launchpools", path: "/launchpools"},
    initializeLaunchpool: {label: "Initialize Launchpool", path: "/initialize"},
    liquidityPools: {label: "Liquidity Pools", path: "/liquidity-pools"},
    ammsConfigs: {label: "Amms Configs", path: "/amms-configs"},
    launchpoolsConfigs: {label: "Launchpools Configs", path: "/launchpools-configs"},
    createLiquidityPool: {label: "Create Liquidity Pool", path: "/create"},
    profile: {label: "Profile", path: "/profile"}
};

export const GeneralPageLayout = ({children}: { children: ReactNode }) => {
    const userPublicKey = usePublicKey();
    return (
        <div className={`${styles.layout} ${colors.colors}`}>
            <header className={styles.header}>
                <div className={styles.left}>Vondex</div>
                <nav className={styles.navbar}>
                    <ul className={styles.navList}>
                        <li className={styles.navItem}>
                            <Link href={links.liquidityPools.path}>{links.liquidityPools.label}</Link>
                        </li>
                        <li className={styles.navItem}>
                            <Link href={links.launchpools.path}>{links.launchpools.label}</Link>
                        </li>

                        {userPublicKey && (
                            <li className={styles.navItem}>
                                <Link href={links.profile.path}>{links.profile.label}</Link>
                            </li>
                        )}
                    </ul>

                </nav>
                <div className={styles.walletButton}>
                    <WalletButton/>
                </div>
            </header>
            <NotificationProvider>
                <main className={styles.main}>{children}</main>
            </NotificationProvider>
        </div>
    );
};