import styles from "./styles.module.css";

export const Loader = () => {
    return (
        <div>
            <div className={styles.message}>Loading ... </div>
        </div>
    );
};
export default Loader;