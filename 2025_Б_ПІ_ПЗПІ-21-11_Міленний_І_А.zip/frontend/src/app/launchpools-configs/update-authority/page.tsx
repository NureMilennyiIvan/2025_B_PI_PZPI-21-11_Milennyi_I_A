"use client"

import {
    usePublicKey,
    useSignAndSendBase64Transaction
} from "@/components/solana/solana-context-wrapper";
import {useRouter} from "next/navigation";
import {useEffect, useMemo, useState} from "react";
import LoadingError from "@/components/ui/error";
import Loader from "@/components/ui/loader";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import formStyles from "@/app/form-styles.module.css";

const Page = ()=> {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();
    const { notify } = useNotification();

    const [newAuthorityStr, setNewAuthorityStr] = useState("");
    const [isUpdating, setIsUpdating] = useState(false);

    const {data: launchpoolsConfigsManager, isLoading: isLaunchpoolsConfigsManager, error: errorLaunchpoolsConfigsManager} = launchpoolService.fetchLaunchpoolsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return launchpoolsConfigsManager.authority === user || launchpoolsConfigsManager.headAuthority === user;
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isLaunchpoolsConfigsManager ) {
            router.push("/");
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    if (errorLaunchpoolsConfigsManager) return <LoadingError error={errorLaunchpoolsConfigsManager} />;
    if (isLaunchpoolsConfigsManager || !launchpoolsConfigsManager) return <Loader />;

    const handleUpdateAuthority = async () => {
        try {
            setIsUpdating(true);
            const newAuthority = new PublicKey(newAuthorityStr);

            let base64Tx = await launchpoolService.updateLaunchpoolsConfigsManagerAuthority(
                userPublicKey!,
                newAuthority
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.launchpoolsConfigs.path}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsUpdating(false)
        }
    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Update Authority</label>
                </div>
                <div className={formStyles.inputContainer}>
                <input
                    type="text"
                    placeholder="Enter new authority pubkey"
                    value={newAuthorityStr}
                    onChange={(e) => setNewAuthorityStr(e.target.value.trim())}
                />
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                <button
                    className={formStyles.actionButton}
                    onClick={handleUpdateAuthority}
                    disabled={!isUserAuthority || !newAuthorityStr || isUpdating}
                >Update
                </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;