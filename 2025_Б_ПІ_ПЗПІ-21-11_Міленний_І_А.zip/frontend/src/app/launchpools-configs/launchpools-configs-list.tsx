"use client"
import styles from "../styles.module.css";
import {links} from "@/components/ui/general-page-layout";
import {useRouter} from "next/navigation";
import {LaunchpoolsConfigAddress} from "@/models/launchpools-config-address";
import {shortenAddress} from "@/utils";

interface LaunchpoolsConfigsListProps {
    launchpoolsConfigs: LaunchpoolsConfigAddress[];
}

export const LaunchpoolsConfigsList: React.FC<LaunchpoolsConfigsListProps> = ({launchpoolsConfigs}) => {
    const router = useRouter();

    if (launchpoolsConfigs.length === 0) {
        return <div className={styles.message}>No configs available.</div>;
    }
    return (
        <div className={styles.tableContainer}>
            {launchpoolsConfigs.length === 0 ? (
                <div className={styles.message}>No launchpools configs available.</div>
            ) : (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    {launchpoolsConfigs.map((config) => {
                        const key = config.launchpoolsConfig;
                        return (
                            <tr
                                key={key}
                                className={styles.tableRow}
                                onClick={() =>
                                    router.push(`${links.launchpoolsConfigs.path}/${key}`)
                                }
                            >
                                <td className={styles.clickable}>{shortenAddress(key)}</td>
                            </tr>
                        );
                    })}
                    </tbody>
                </table>
            )}
        </div>
    );
};