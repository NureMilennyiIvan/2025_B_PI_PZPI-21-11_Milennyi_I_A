"use client"
import {usePublicKey} from "@/components/solana/solana-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useEffect, useMemo} from "react";
import styles from "../styles.module.css";
import {useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import {LaunchpoolsConfigsList} from "@/app/launchpools-configs/launchpools-configs-list";

const Page = () => {
    const userPublicKey = usePublicKey();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();

    const {
        data: launchpoolsConfigsManager,
        isLoading: isLaunchpoolsConfigsManager,
        error: errorLaunchpoolsConfigsManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();
    const {
        data: launchpoolsConfigs,
        isLoading: isLaunchpoolsConfigs,
        error: errorLaunchpoolsConfigs
    } = launchpoolService.fetchLaunchpoolsConfigsAddresses();
    const [isUserAuthority, showUpdateHeadAuthorityButton] = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return [false, false];
        const user = userPublicKey.toBase58();
        const showUpdateHeadAuthorityButton = launchpoolsConfigsManager.headAuthority === user
        return [
            launchpoolsConfigsManager.authority === user || showUpdateHeadAuthorityButton,
            showUpdateHeadAuthorityButton
        ];
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isLaunchpoolsConfigsManager) {
            router.push("/");
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    if (errorLaunchpoolsConfigsManager) return <LoadingError error={errorLaunchpoolsConfigsManager}/>;
    if (errorLaunchpoolsConfigs) return <LoadingError error={errorLaunchpoolsConfigs}/>;
    if (isLaunchpoolsConfigsManager || isLaunchpoolsConfigs || !launchpoolsConfigsManager || !launchpoolsConfigs) return <Loader/>;

    return (
        <div className={styles.pageContainer}>
            <section className={styles.managerBlock}>
                <h2>Launchpools Configurations Manager</h2>
                <div className={styles.header}>
                    <p><strong>Head Authority:</strong> {launchpoolsConfigsManager.headAuthority}</p>
                    {showUpdateHeadAuthorityButton && (
                        <button className={styles.functionalButton}
                                onClick={() => router.push(`${links.launchpoolsConfigs.path}/update-head-authority`)}>Update</button>
                    )}
                </div>
                <div className={styles.header}>
                    <p><strong>Authority:</strong> {launchpoolsConfigsManager.authority}</p>
                    {isUserAuthority && (
                        <button className={styles.functionalButton}
                                onClick={() => router.push(`${links.launchpoolsConfigs.path}/update-authority`)}>Update</button>
                    )}
                </div>
            </section>

            <section className={styles.configsSection}>
                <div className={styles.header}>
                    <h2>Launchpools Configs</h2>
                    <button className={styles.functionalButton}
                            onClick={() => router.push(`${links.launchpoolsConfigs.path}/create`)}>Create
                    </button>
                </div>
                    {isUserAuthority && (
                        <div>
                            <LaunchpoolsConfigsList launchpoolsConfigs={launchpoolsConfigs}/>
                        </div>
                    )}
            </section>
        </div>
    );
}
export default Page;