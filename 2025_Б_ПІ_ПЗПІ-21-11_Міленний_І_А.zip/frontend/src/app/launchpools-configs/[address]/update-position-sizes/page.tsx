"use client"
import {usePublicKey, useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useEffect, useMemo, useState} from "react";
import formStyles from "../../../form-styles.module.css";
import {useParams, useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";
import BN from "bn.js";

const Page = () => {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();
    const {address} = useParams();
    const {notify} = useNotification();

    const [minStr, setMinStr] = useState("");
    const [maxStr, setMaxStr] = useState("");
    const [isUpdating, setIsUpdating] = useState(false);

    const configPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch {
            return null;
        }
    }, [address]);

    if (!configPubkey) {
        return <LoadingError error={new Error(`Invalid LaunchpoolsConfig address: ${address}`)}/>;
    }

    const {
        data: manager,
        isLoading,
        error
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !manager) return false;
        const user = userPublicKey.toBase58();
        return manager.authority === user || manager.headAuthority === user;
    }, [userPublicKey, manager]);

    useEffect(() => {
        if (!isUserAuthority && !isLoading) {
            router.push("/");
        }
    }, [isUserAuthority, isLoading]);

    if (error) return <LoadingError error={error}/>;
    if (isLoading || !manager) return <Loader/>;

    const handleUpdate = async () => {
        try {
            setIsUpdating(true);

            const min = new BN(minStr);
            const max = new BN(maxStr);

            if (min.isZero()) {
                throw new Error("Min position size cannot be 0");
            }
            if (min.gt(max)) {
                throw new Error("Min position size cannot be greater than max");
            }

            const base64Tx = await launchpoolService.updateLaunchpoolsConfigPositionSizes(
                configPubkey!,
                userPublicKey!,
                min,
                max
            );

            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.launchpoolsConfigs.path}/${configPubkey.toBase58()}`);
        } catch (e) {
            const message =
                e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsUpdating(false);
        }
    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Update Min Position Sizes</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        type="text"
                        value={minStr}
                        placeholder="Enter new min position size"
                        onChange={(e) => setMinStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.baseContainer}>
                    <label>Update Max Position Sizes</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        type="text"
                        value={maxStr}
                        placeholder="Enter new max position size"
                        onChange={(e) => setMaxStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                            onClick={handleUpdate}
                            disabled={!isUserAuthority || !minStr || !maxStr || isUpdating}
                        >
                            Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Page;
