"use client"
import {usePublicKey, useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useEffect, useMemo, useState} from "react";
import formStyles from "../../../form-styles.module.css";
import {useParams, useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";

const Page = () => {
    const userPublicKey = usePublicKey();
    const launchpoolService = useLaunchpoolService();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const router = useRouter();
    const {address} = useParams();
    const {notify} = useNotification();
    const [newRewardAuthorityStr, setNewRewardAuthorityStr] = useState("");
    const [isUpdating, setIsUpdating] = useState(false);

    const launchpoolsConfigPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch {
            return null;
        }
    }, [address]);

    if (!launchpoolsConfigPubkey) {
        return <LoadingError error={new Error(`Invalid LaunchpoolsConfig address: ${address}`)}/>;
    }

    const {
        data: launchpoolsConfigsManager,
        isLoading: isLaunchpoolsConfigsManager,
        error: errorLaunchpoolsConfigsManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return (
            launchpoolsConfigsManager.authority === user ||
            launchpoolsConfigsManager.headAuthority === user
        );
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isLaunchpoolsConfigsManager) {
            router.push("/");
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    if (errorLaunchpoolsConfigsManager) return <LoadingError error={errorLaunchpoolsConfigsManager}/>;
    if (isLaunchpoolsConfigsManager || !launchpoolsConfigsManager) return <Loader/>;

    const handleUpdateRewardAuthority = async () => {
        try {
            setIsUpdating(true);
            const newRewardAuthority = new PublicKey(newRewardAuthorityStr);

            const base64Tx = await launchpoolService.updateLaunchpoolsConfigRewardAuthority(
                launchpoolsConfigPubkey!,
                userPublicKey!,
                newRewardAuthority
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.launchpoolsConfigs.path}/${launchpoolsConfigPubkey.toBase58()}`);
        } catch (e) {
            const message =
                e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsUpdating(false);
        }
    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Update Reward Authority</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        type="text"
                        placeholder="Enter new reward authority pubkey"
                        value={newRewardAuthorityStr}
                        onChange={(e) => setNewRewardAuthorityStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                            onClick={handleUpdateRewardAuthority}
                            disabled={!isUserAuthority || !newRewardAuthorityStr || isUpdating}
                        >
                            Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Page;