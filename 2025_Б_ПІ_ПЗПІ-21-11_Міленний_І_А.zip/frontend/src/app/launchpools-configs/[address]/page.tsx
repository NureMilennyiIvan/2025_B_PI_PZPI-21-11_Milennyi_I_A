"use client"
import { usePublicKey } from "@/components/solana/solana-context-wrapper";
import { useLaunchpoolService } from "@/components/backend/launchpool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import { useEffect, useMemo } from "react";
import styles from "../../styles.module.css";
import { useParams, useRouter } from "next/navigation";
import { links } from "@/components/ui/general-page-layout";
import { PublicKey } from "@solana/web3.js";

const Page = () => {
    const userPublicKey = usePublicKey();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();
    const { address } = useParams();

    const launchpoolsConfigPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch (e) {
            return null;
        }
    }, [address]);

    if (!launchpoolsConfigPubkey) {
        return <LoadingError error={new Error(`Invalid LaunchpoolsConfig address: ${address}`)} />;
    }

    const {
        data: launchpoolsConfigsManager,
        isLoading: isManagerLoading,
        error: errorManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();

    const {
        data: launchpoolsConfig,
        isLoading: isConfigLoading,
        error: errorConfig
    } = launchpoolService.fetchLaunchpoolsConfigVM(launchpoolsConfigPubkey);

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return (
            launchpoolsConfigsManager.authority === user ||
            launchpoolsConfigsManager.headAuthority === user
        );
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isManagerLoading) {
            router.push("/");
        }
    }, [isUserAuthority, isManagerLoading]);

    if (errorManager) return <LoadingError error={errorManager} />;
    if (errorConfig) return <LoadingError error={errorConfig} />;
    if (isManagerLoading || isConfigLoading || !launchpoolsConfigsManager || !launchpoolsConfig) return <Loader />;

    const rewardSharePercent = (launchpoolsConfig.protocolRewardShareBasisPoints / 100).toFixed(2);

    return (
        <div className={styles.pageContainer}>
            <section className={styles.managerBlock}>
                <h2>Launchpools Config</h2>
                <div className={styles.header}>
                    <p><strong>Stakable Mint:</strong> {launchpoolsConfig.stakableMint}</p>
                </div>
                <div className={styles.header}>
                    <p><strong>Reward Authority:</strong> {launchpoolsConfig.rewardAuthority}</p>
                    <button
                        className={styles.functionalButton}
                        onClick={() => router.push(`${links.launchpoolsConfigs.path}/${address?.toString()}/update-reward-authority`)}
                    >
                        Update
                    </button>
                </div>
                <div className={styles.header}>
                    <div>
                        <p><strong>Min Position Size:</strong> {launchpoolsConfig.minPositionSize.toString()}</p>
                        <p><strong>Max Position Size:</strong> {launchpoolsConfig.maxPositionSize.toString()}</p>
                    </div>
                    <button
                        className={styles.functionalButton}
                        onClick={() =>
                            router.push(
                                `${links.launchpoolsConfigs.path}/${address?.toString()}/update-position-sizes`
                            )
                        }
                    >
                        Update
                    </button>
                </div>
                <div className={styles.header}>
                    <p><strong>Protocol Reward Share:</strong> {rewardSharePercent}%</p>
                    <button
                        className={styles.functionalButton}
                        onClick={() => router.push(`${links.launchpoolsConfigs.path}/${address?.toString()}/update-protocol-reward-share`)}
                    >
                        Update
                    </button>
                </div>
                <div className={styles.header}>
                    <p><strong>Duration:</strong> {launchpoolsConfig.duration.toString()} seconds</p>
                    <button
                        className={styles.functionalButton}
                        onClick={() => router.push(`${links.launchpoolsConfigs.path}/${address?.toString()}/update-duration`)}
                    >
                        Update
                    </button>
                </div>
            </section>
        </div>
    );
};

export default Page;
