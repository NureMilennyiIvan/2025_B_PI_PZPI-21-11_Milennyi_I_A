"use client"
import { usePublicKey, useSignAndSendBase64Transaction } from "@/components/solana/solana-context-wrapper";
import { useLaunchpoolService } from "@/components/backend/launchpool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import { useEffect, useMemo, useState } from "react";
import formStyles from "../../../form-styles.module.css";
import { useParams, useRouter } from "next/navigation";
import { links } from "@/components/ui/general-page-layout";
import { PublicKey } from "@solana/web3.js";
import { useNotification } from "@/components/ui/notification-context";

const Page = () => {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();
    const { address } = useParams();
    const { notify } = useNotification();
    const [rewardSharePercent, setRewardSharePercent] = useState("0.0");
    const [isUpdating, setIsUpdating] = useState(false);

    const configPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch {
            return null;
        }
    }, [address]);

    if (!configPubkey) {
        return <LoadingError error={new Error(`Invalid LaunchpoolsConfig address: ${address}`)} />;
    }

    const {
        data: launchpoolsConfigsManager,
        isLoading: isLaunchpoolsConfigsManager,
        error: errorLaunchpoolsConfigsManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return (
            launchpoolsConfigsManager.authority === user ||
            launchpoolsConfigsManager.headAuthority === user
        );
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isLaunchpoolsConfigsManager) {
            router.push("/");
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    if (errorLaunchpoolsConfigsManager) return <LoadingError error={errorLaunchpoolsConfigsManager} />;
    if (isLaunchpoolsConfigsManager || !launchpoolsConfigsManager) return <Loader />;

    const handleUpdateRewardShare = async () => {
        try {
            setIsUpdating(true);
            const newRewardShare = Math.round(Number(rewardSharePercent) * 100);

            const base64Tx = await launchpoolService.updateLaunchpoolsConfigProtocolRewardShare(
                configPubkey!,
                userPublicKey!,
                newRewardShare
            );

            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.launchpoolsConfigs.path}/${configPubkey.toBase58()}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsUpdating(false);
        }
    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Update Protocol Reward Share</label>
                </div>
                <div className={formStyles.sliderContainer}>
                    <input
                        type="range"
                        min="0"
                        max="100"
                        step="0.1"
                        value={rewardSharePercent}
                        onChange={(e) => setRewardSharePercent(Number(e.target.value).toFixed(1))}
                    />
                    <label>{rewardSharePercent}%</label>
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                    onClick={handleUpdateRewardShare}
                    disabled={!isUserAuthority || isUpdating}
                >
                    Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Page;
