"use client"

import {
    usePublicKey,
    useSignAndSendBase64Transaction
} from "@/components/solana/solana-context-wrapper";
import {useRouter} from "next/navigation";
import React, {useEffect, useMemo, useState} from "react";
import LoadingError from "@/components/ui/error";
import Loader from "@/components/ui/loader";
import styles from "../../styles.module.css";
import formStyles from "../../form-styles.module.css";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import BN from "bn.js";

const Page = () => {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();
    const {notify} = useNotification();

    const [rewardAuthorityStr, setRewardAuthorityStr] = useState("");
    const [stakableMintStr, setStakableMintStr] = useState("");
    const [minPositionSizeStr, setMinPositionSizeStr] = useState("");
    const [maxPositionSizeStr, setMaxPositionSizeStr] = useState("");
    const [protocolRewardShareBasisPoints, setProtocolRewardShareBasisPoints] = useState("0.0");
    const [durationStr, setDurationStr] = useState("");
    const [isCreating, setIsCreating] = useState(false);

    const {
        data: launchpoolsConfigsManager,
        isLoading: isLaunchpoolsConfigsManager,
        error: errorLaunchpoolsConfigsManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return launchpoolsConfigsManager.authority === user || launchpoolsConfigsManager.headAuthority === user;
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isLaunchpoolsConfigsManager) {
            router.push("/");
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    if (errorLaunchpoolsConfigsManager) return <LoadingError error={errorLaunchpoolsConfigsManager}/>;
    if (isLaunchpoolsConfigsManager || !launchpoolsConfigsManager) return <Loader/>;

    const handleCreateConfig = async () => {
        try {
            setIsCreating(true);
            const rewardAuthority = new PublicKey(rewardAuthorityStr);
            const stakableMint = new PublicKey(stakableMintStr);

            const minPositionSize = new BN(minPositionSizeStr);
            const maxPositionSize = new BN(maxPositionSizeStr);
            const protocolRewardShare = Math.round(Number(protocolRewardShareBasisPoints) * 100);
            const duration = new BN(durationStr);

            if (minPositionSize.eqn(0)) {
                throw new Error("Min position is 0")
            }
            if (minPositionSize.gt(maxPositionSize)) {
                throw new Error("Max position size is lesser then min position size")
            }
            if (duration.ltn(3600)) {
                throw new Error("Duration is less then one hour")
            }
            let [base64Tx, launchpoolsConfig] = await launchpoolService.initializeLaunchpoolsConfig(
                userPublicKey!,
                launchpoolsConfigsManager.key,
                rewardAuthority,
                stakableMint,
                minPositionSize,
                maxPositionSize,
                protocolRewardShare,
                duration
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.launchpoolsConfigs.path}/${launchpoolsConfig}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsCreating(false)
        }
    };
    return (
        <div className={formStyles.formPageContainer}>
            <div className={styles.header}>
                <h2>Create Launchpools Config</h2>
            </div>
            <div className={formStyles.generalForm}>
                <div className={formStyles.baseContainer}>
                    <label>Reward Authority</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter reward authority pubkey"
                        value={rewardAuthorityStr}
                        onChange={(e) => setRewardAuthorityStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.baseContainer}>
                    <label>Stakable Token</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter stakable token pubkey"
                        value={stakableMintStr}
                        onChange={(e) => setStakableMintStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.baseContainer}>
                    <label>Min Position Size</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter min position size"
                        value={minPositionSizeStr}
                        onChange={(e) => setMinPositionSizeStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.baseContainer}>
                    <label>Max Position Size</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter max position size"
                        value={maxPositionSizeStr}
                        onChange={(e) => setMaxPositionSizeStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.baseContainer}>
                    <label>Duration (in seconds):</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter duration"
                        value={durationStr}
                        onChange={(e) => setDurationStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.sliderContainer}>
                    <label>Protocol Reward Share</label>
                    <input
                        type="range"
                        min="0"
                        max="100"
                        step="0.1"
                        value={protocolRewardShareBasisPoints}
                        onChange={(e) => setProtocolRewardShareBasisPoints(Number(e.target.value).toFixed(1))}
                    />
                    <label>{protocolRewardShareBasisPoints}%</label>
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                            onClick={handleCreateConfig}
                            disabled={!isUserAuthority || isCreating}
                        >Create
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;