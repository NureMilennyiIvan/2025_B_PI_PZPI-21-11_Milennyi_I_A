"use client"

import React, {useEffect, useMemo, useState} from "react";
import {PublicKey} from "@solana/web3.js";
import formStyles from "../../form-styles.module.css";
import styles from "../../styles.module.css";
import {usePublicKey, useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import {
    bnToString,
    handlePubkeyChange,
    handleTokenInputChange,
    parseStringToBN,
} from "@/utils";
import {AmmsConfigVM} from "@/models/amms-config-vm";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useNotification} from "@/components/ui/notification-context";
import {useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import BN from "bn.js";

const Page = () => {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const liquidityPoolService = useLiquidityPoolService();
    const router = useRouter();
    const {notify} = useNotification();

    const [baseMint, setBaseMint] = useState<PublicKey | undefined>(undefined);
    const [quoteMint, setQuoteMint] = useState<PublicKey | undefined>(undefined);
    const [baseMintStr, setBaseMintStr] = useState("");
    const [quoteMintStr, setQuoteMintStr] = useState("");
    const [baseTokenInput, setBaseTokenInput] = useState<string>("");
    const [quoteTokenInput, setQuoteTokenInput] = useState<string>("");

    const [selectedAmmsConfigKey, setSelectedAmmsConfigKey] = useState<string | undefined>(undefined);
    const [isCreating, setIsCreating] = useState(false);

    const {
        data: baseToken,
        isLoading: isBaseToken,
        error: errorBaseToken
    } = liquidityPoolService.fetchTokenMintWithAtaBalance(baseMint, userPublicKey);
    const {
        data: quoteToken,
        isLoading: isQuoteToken,
        error: errorQuoteToken
    } = liquidityPoolService.fetchTokenMintWithAtaBalance(quoteMint, userPublicKey);
    const baseBalance = useMemo(() => {
        if (!baseToken || !baseToken.balance) {
            return "0";
        }
        return bnToString(baseToken.balance, baseToken.decimals)
    }, [baseToken]);
    const quoteBalance = useMemo(() => {
        if (!quoteToken || !quoteToken.balance) {
            return "0";
        }
        return bnToString(quoteToken.balance, quoteToken.decimals)
    }, [quoteToken]);
    const {
        data: ammsConfigVMs,
        isLoading: isAmmsConfigVMs,
        error: errorAmmsConfigVMs
    } = liquidityPoolService.fetchAmmsConfigVMs();
    const [ammsConfigVMsRenderer, setAmmsConfigVMsRenderer] = useState<AmmsConfigVM[]>([]);


    const selectedAmmsConfig = ammsConfigVMsRenderer.find(
        (config) => config.key.toBase58() === selectedAmmsConfigKey
    );

    useEffect(() => {
        if (ammsConfigVMs) {
            setAmmsConfigVMsRenderer(ammsConfigVMs);
        }
    }, [ammsConfigVMs]);
    useEffect(() => {
        if (!selectedAmmsConfigKey && ammsConfigVMsRenderer.length > 0) {
            setSelectedAmmsConfigKey(ammsConfigVMsRenderer[0].key.toBase58());
        }
    }, [ammsConfigVMsRenderer, selectedAmmsConfigKey]);


    if (ammsConfigVMsRenderer.length == 0 || isAmmsConfigVMs) {
        return <Loader/>;
    }
    if (!!errorAmmsConfigVMs) {
        return <LoadingError error={errorAmmsConfigVMs}/>;
    }

    const createLiquidityPool = async () => {
        try {
            setIsCreating(true);
            if (quoteMint == baseMint) {
                throw new Error("Base and Quote cannot be equal")
            }
            const baseMintKey = baseMint!;
            const quoteMintKey = quoteMint!;
            const base = parseStringToBN(baseTokenInput, baseToken!.decimals);
            const quote = parseStringToBN(quoteTokenInput, quoteToken!.decimals);
            if (base.mul(quote).lt(new BN("160000000000"))) {
                throw new Error("Insufficient liquidity for launch")
            }
            const ammsConfig = selectedAmmsConfig!;
            let [base64Tx, cpAmm] = await liquidityPoolService.createCpAmm(
                userPublicKey!,
                ammsConfig.key,
                baseMintKey,
                quoteMintKey,
                base,
                quote
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.liquidityPools.path}/${cpAmm}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsCreating(false)
        }

    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <div className={formStyles.inputContainer}>
                        <input
                            type="text"
                            placeholder="Base Mint"
                            className={styles.searchInput}
                            value={baseMintStr}
                            onChange={(e) => handlePubkeyChange(e.target.value, setBaseMintStr, setBaseMint)}
                        />
                    </div>
                    <div className={formStyles.inputContainer}>
                        <input
                            type="text"
                            value={baseTokenInput}
                            className={styles.inputNumber}
                            onChange={(e) => handleTokenInputChange(e, setBaseTokenInput)}
                            placeholder="Base amount"
                        />
                    </div>
                    <div className={formStyles.balance}>
                        <span>Your balance: {baseBalance}</span>
                    </div>
                </div>
                <hr className={formStyles.divider}/>
                <div className={formStyles.baseContainer}>
                    <div className={formStyles.inputContainer}>
                        <input
                            type="text"
                            placeholder="Quote Mint"
                            className={styles.searchInput}
                            value={quoteMintStr}
                            onChange={(e) => handlePubkeyChange(e.target.value, setQuoteMintStr, setQuoteMint)}
                        />
                    </div>
                    <div className={formStyles.inputContainer}>
                        <input
                            type="text"
                            value={quoteTokenInput}
                            className={styles.inputNumber}
                            onChange={(e) => handleTokenInputChange(e, setQuoteTokenInput)}
                            placeholder="Quote amount"
                        />
                    </div>
                    <div className={formStyles.balance}>
                        <span>Your balance: {quoteBalance}</span>
                    </div>

                </div>
                <hr className={formStyles.divider}/>
                <div className={styles.header}>
                    <div className={formStyles.baseContainer}>
                        <label htmlFor="ammsConfigSelect">Select AMMs Config:</label></div>

                    <select
                        id="ammsConfigSelect"
                        className={formStyles.select}
                        value={selectedAmmsConfigKey ?? ""}
                        onChange={(e) => setSelectedAmmsConfigKey(e.target.value)}
                    >
                        <option value="" disabled>Select configuration</option>
                        {ammsConfigVMsRenderer.map((config) => (
                            <option key={config.key.toBase58()} value={config.key.toBase58()}>
                                {config.key.toBase58()}
                            </option>
                        ))}
                    </select>
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.utils}>
                        {selectedAmmsConfig && (
                            <div className={formStyles.utilsText}>
                                <strong>Provider Fee: {selectedAmmsConfig.getProvidersFeeRatesAsPercent()}%</strong>
                                <strong>Protocol Fee: {selectedAmmsConfig.getProtocolFeeRatesAsPercent()}%</strong>
                                <strong>Price: 0.1 SOL</strong>
                            </div>
                        )}
                    </div>
                    <div className={formStyles.buttonContainer}>
                        <button className={formStyles.actionButton}
                                disabled={isCreating || !userPublicKey || !baseToken || !quoteToken || !selectedAmmsConfigKey}
                                onClick={() => createLiquidityPool()}
                        >
                            Create Pool
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;