"use client"
import { useLiquidityPoolService } from "@/components/backend/liquidity-pool-context-wrapper";
import { usePublicKey } from "@/components/solana/solana-context-wrapper";
import Loader from "@/components/ui/loader";
import {useEffect, useMemo, useState} from "react";
import {CpAmmsList} from "@/app/liquidity-pools/cp-amms-list";
import {CpAmmRow} from "@/models/cp-amm-row";
import {PublicKey} from "@solana/web3.js";
import styles from "../styles.module.css";
import Link from "next/link";
import {links} from "@/components/ui/general-page-layout";
import LoadingError from "@/components/ui/error";

const Page = ()=> {
    const userPublicKey = usePublicKey();
    const liquidityPoolService = useLiquidityPoolService();

    const {data: ammsConfigsManager, isLoading: isAmmsConfigsManager, error: errorAmmsConfigsManager} = liquidityPoolService.fetchAmmsConfigsManagerVM();
    const [baseMintToSearch, setBaseMintToSearch] = useState<PublicKey | undefined>(undefined);
    const [quoteMintToSearch, setQuoteMintToSearch] = useState<PublicKey | undefined>(undefined);
    const [baseMintToSearchStr, setBaseMintToSearchStr] = useState("");
    const [quoteMintToSearchStr, setQuoteMintToSearchStr] = useState("");
    const {data: cpAmmRows, isLoading: isCpAmmRows, error: errorCpAmmRows} = liquidityPoolService.fetchCpAmmRows(20, baseMintToSearch, quoteMintToSearch);
    const [cpAmmRowsRender, setCpAmmRowsRender] = useState<CpAmmRow[]>([]);
    const showAmmsConfigButton = useMemo(() => {
        if (!userPublicKey || !ammsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return ammsConfigsManager.authority === user || user === ammsConfigsManager.headAuthority;
    }, [userPublicKey, ammsConfigsManager]);

    useEffect(() => {
        if (cpAmmRows && !isCpAmmRows) {
            setCpAmmRowsRender(cpAmmRows);
        }
    }, [cpAmmRows, isCpAmmRows]);

    if (!!errorAmmsConfigsManager) {
        return <LoadingError error={errorAmmsConfigsManager} />;
    }
    if (isAmmsConfigsManager || (cpAmmRowsRender.length == 0 && isCpAmmRows)) {
        return <Loader />;
    }


    if (!!errorCpAmmRows) {
        return <LoadingError error={errorCpAmmRows} />;
    }

    return (
        <div className={styles.pageContainer}>
            <div className={styles.header}>
                <h1>Liquidity Pools</h1>
                <div className={styles.functionalButtonContainer}>
                    {showAmmsConfigButton && (
                        <Link href={links.ammsConfigs.path}>
                            <button className={styles.functionalButton}>Configuration</button>
                        </Link>
                    )}
                    <Link href={`${links.liquidityPools.path}/create`}>
                        <button className={styles.functionalButton}>{links.createLiquidityPool.label}</button>
                    </Link>
                </div>
            </div>
            <div className={styles.searchContainer}>
                <div className={styles.searchInputContainer}>
                    <input
                        type="text"
                        placeholder="Base Token"
                        value={baseMintToSearchStr}
                        onChange={(e) => setBaseMintToSearchStr(e.target.value)}
                    />
                </div>
                <div className={styles.searchInputContainer}>
                    <input
                        type="text"
                        placeholder="Quote Token"
                        value={quoteMintToSearchStr}
                        onChange={(e) => setQuoteMintToSearchStr(e.target.value)}
                    />
                </div>
                <button
                    className={styles.searchButton}
                    onClick={() => {
                        try {
                            setBaseMintToSearch(baseMintToSearchStr ? new PublicKey(baseMintToSearchStr) : undefined);
                        } catch (e) {
                            setBaseMintToSearch(undefined);
                        }
                        try {
                            setQuoteMintToSearch(quoteMintToSearchStr ? new PublicKey(quoteMintToSearchStr) : undefined);
                        } catch (e) {
                            setQuoteMintToSearch(undefined);
                        }
                    }}
                >
                    Search
                </button>
            </div>
            <CpAmmsList cpAmmRows={cpAmmRowsRender}></CpAmmsList>
        </div>
    );
};
export default Page;