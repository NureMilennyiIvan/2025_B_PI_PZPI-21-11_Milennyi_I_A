"use client";

import { CpAmmRow } from "@/models/cp-amm-row";
import styles from "../styles.module.css";
import { useRouter } from "next/navigation";
import { links } from "@/components/ui/general-page-layout";
import {shortenAddress} from "@/utils";

interface CpAmmsListProps {
    cpAmmRows: CpAmmRow[];
}

export const CpAmmsList: React.FC<CpAmmsListProps> = ({ cpAmmRows }) => {
    const router = useRouter();

    const copyToClipboard = async (address: string) => {
        await navigator.clipboard.writeText(address);
    };

    return (
        <div className={styles.tableContainer}>
            {cpAmmRows.length === 0 ? (
                <div className={styles.message}>No liquidity pools available.</div>
            ) : (

                    <table className={styles.table}>
                        <thead>
                        <tr>
                            <th>Pool</th>
                            <th>Base Token</th>
                            <th>Quote Token</th>
                            <th>LP Token</th>
                        </tr>
                        </thead>
                        <tbody>
                        {cpAmmRows.map((pool) => {
                            const poolKey = pool.cpAmm.toBase58();
                            const baseMint = pool.baseMint;
                            const quoteMint = pool.quoteMint;
                            const lpMint = pool.lpMint;
                            return (
                                <tr
                                    key={poolKey}
                                    className={styles.tableRow}
                                    onClick={() =>
                                        router.push(`${links.liquidityPools.path}/${poolKey}`)
                                    }
                                >
                                    <td>{shortenAddress(poolKey)}</td>
                                    <td
                                        title={baseMint}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            copyToClipboard(baseMint);
                                        }}
                                        className={styles.clickable}
                                    >
                                        {shortenAddress(baseMint)}
                                    </td>
                                    <td
                                        title={quoteMint}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            copyToClipboard(quoteMint);
                                        }}
                                        className={styles.clickable}
                                    >
                                        {shortenAddress(quoteMint)}
                                    </td>
                                    <td
                                        title={lpMint}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            copyToClipboard(lpMint);
                                        }}
                                        className={styles.clickable}
                                    >
                                        {shortenAddress(lpMint)}
                                    </td>
                                </tr>
                            );
                        })}
                        </tbody>
                    </table>
            )}
        </div>
    );
};