"use client"
import React, {useEffect, useMemo, useState} from "react";
import formStyles from "../../form-styles.module.css";
import styles from "../../styles.module.css";
import {usePublicKey, useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import {useParams} from "next/navigation";
import {PublicKey} from "@solana/web3.js";
import LoadingError from "@/components/ui/error";
import {bnToString, shortenAddress} from "@/utils";
import {useNotification} from "@/components/ui/notification-context";
import {SwapForm} from "@/app/liquidity-pools/[address]/swap-form";
import {ProvideForm} from "@/app/liquidity-pools/[address]/provide-form";
import {WithdrawForm} from "@/app/liquidity-pools/[address]/withdraw-form";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faHandHoldingDollar} from "@fortawesome/free-solid-svg-icons";
import {Trade} from "@/models/trade";
import Loader from "@/components/ui/loader";

const Page = () => {
    const userPublicKey = usePublicKey();
    const liquidityPoolService = useLiquidityPoolService();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const {address} = useParams();
    const {notify} = useNotification();
    const [trades, setTrades] = useState<Trade[]>([]);
    const [selectedMode, setSelectedMode] = useState<'swap' | 'provide' | 'withdraw'>('swap');
    const [isCollecting, setIsCollecting] = useState(false);
    const [socket, setSocket] = useState<WebSocket | null>(null);

    const cpAmmPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch (e) {
            return null;
        }
    }, [address]);

    if (!cpAmmPubkey) {
        return <LoadingError error={new Error(`Invalid CpAmm address: ${address}`)}/>;
    }

    const {
        data: cpAmm,
        isLoading: isCpAmm,
        error: errorCpAmm
    } = liquidityPoolService.fetchCpAmmVM(cpAmmPubkey, userPublicKey);

    if (!!errorCpAmm) {
        return <LoadingError error={errorCpAmm}/>;
    }


    useEffect(() => {
        if (!cpAmmPubkey || !!socket) {
            return;
        }
        const websocket = liquidityPoolService.getCpAmmTradesWS(cpAmmPubkey);
        setSocket(websocket);
        websocket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (Array.isArray(data)) {
                    const parsedTrades = data.map(Trade.fromJSON);
                    setTrades((prev) => [...parsedTrades, ...prev]);
                }
            } catch (err) {
                console.error("Trade parsing error:", err);
            }
        };

        websocket.onopen = () => {
            console.log("WebSocket opened");
        };

        websocket.onclose = () => {
            console.log("WebSocket closed");
            setSocket(null)
        };

        return () => {
            websocket.close();
            setSocket(null)
        };
    }, [cpAmmPubkey]);
    if (isCpAmm) {
        return <Loader/>;
    }
    const handleModeChange = (mode: 'swap' | 'provide' | 'withdraw') => {
        setSelectedMode(mode);
    };
    const collectFeesFromLiquidityPool = async () => {
        try {
            setIsCollecting(true);
            let base64Tx = await liquidityPoolService.collectFeesFromCpAmm(
                userPublicKey!,
                cpAmmPubkey
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully collected");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsCollecting(false)
    };
    return (
        <div className={styles.pageContainer}>
            <div className={formStyles.tradingCard}>
                <div className={formStyles.liquidityPoolCard}>
                    {!!cpAmm && (
                        <div>
                            <div className={formStyles.baseContainer}>
                                <label>Base Token</label>
                                <div>{cpAmm.baseMint.toString()}</div>
                                <div>Amount: {bnToString(cpAmm.baseLiquidity, cpAmm.baseTokenData.decimals)}</div>
                                {cpAmm.baseTokenData.transferFeeBasisPoints > 0 && (
                                    <div>
                                        <div>Token Transfer Fee: {cpAmm.getBaseMintFeeAsPercent()}%</div>
                                        <div>Max Transfer
                                            Fee: {bnToString(cpAmm.baseTokenData.maximumFee, cpAmm.baseTokenData.decimals)} tokens
                                        </div>
                                    </div>
                                )}
                            </div>
                            <hr className={formStyles.divider}/>
                            <div className={formStyles.baseContainer}>
                                <label>Quote Token</label>
                                <div>{cpAmm.quoteMint.toString()}</div>
                                <div>Amount: {bnToString(cpAmm.quoteLiquidity, cpAmm.quoteTokenData.decimals)}</div>
                                {cpAmm.quoteTokenData.transferFeeBasisPoints > 0 && (
                                    <div>
                                        <div>Token Transfer Fee: {cpAmm.getQuoteMintFeeAsPercent()}%</div>
                                        <div>Max Transfer
                                            Fee: {bnToString(cpAmm.quoteTokenData.maximumFee, cpAmm.quoteTokenData.decimals)} tokens
                                        </div>
                                    </div>
                                )}
                            </div>
                            <hr className={formStyles.divider}/>
                            <div className={formStyles.baseContainer}>
                                <label>LP Token</label>
                                <div>{cpAmm.lpMint.toString()}</div>
                                <div>Supply: {bnToString(cpAmm.lpTokensSupply, cpAmm.lpTokenData.decimals)}</div>
                                {cpAmm.lpTokenData.transferFeeBasisPoints > 0 && (
                                    <div>
                                        <div>Token Transfer Fee: {cpAmm.getLpMintFeeAsPercent()}%</div>
                                        <div>Max Transfer
                                            Fee: {bnToString(cpAmm.lpTokenData.maximumFee, cpAmm.lpTokenData.decimals)} tokens
                                        </div>
                                    </div>
                                )}
                            </div>
                            <hr className={formStyles.divider}/>
                            <div className={styles.header}>
                                <div className={formStyles.baseContainer}>
                                    <label>Protocol Fees Collected</label>
                                    <div>Base: {bnToString(cpAmm.protocolBaseFeesToRedeem, cpAmm.baseTokenData.decimals)}</div>
                                    <div>Quote: {bnToString(cpAmm.protocolQuoteFeesToRedeem, cpAmm.quoteTokenData.decimals)}</div>

                                </div>
                                <div className={formStyles.buttonContainer}>
                                    <button className={formStyles.harvestButton} onClick={collectFeesFromLiquidityPool}
                                            disabled={isCollecting || !userPublicKey || (cpAmm.protocolQuoteFeesToRedeem.eqn(0) && cpAmm.protocolBaseFeesToRedeem.eqn(0))}
                                            title="Collect Fees for platform">
                                        <FontAwesomeIcon icon={faHandHoldingDollar} className={formStyles.icon}/>
                                    </button>
                                </div>
                            </div>
                            <hr className={formStyles.divider}/>
                            <div className={formStyles.baseContainer}>
                                <label>Approximate rate</label>
                                <div>1 BASE ≈ {cpAmm.getBasePrice()} QUOTE</div>
                                <div>1 QUOTE ≈ {cpAmm.getQuotePrice()} BASE</div>
                            </div>
                            <hr className={formStyles.divider}/>
                            <div className={formStyles.baseContainer}>
                                <label>Swap Fee</label>
                                <div>
                                    {cpAmm.getTotalFeeRatesAsPercent()}%
                                    ({cpAmm.getProvidersFeeRatesAsPercent()}% to providers,
                                    {cpAmm.getProtocolFeeRatesAsPercent()}% to protocol)
                                </div>
                            </div>
                        </div>
                    )}
                </div>
                <div className={formStyles.liquidityPoolCard}>
                    <div className={`${formStyles.header}`}>
                        <div className={`${formStyles.modeSelector}`}>
                            <button
                                onClick={() => handleModeChange("swap")}
                                className={selectedMode === "swap" ? formStyles.active : ""}
                            >
                                Swap
                            </button>
                            <button
                                onClick={() => handleModeChange("provide")}
                                className={selectedMode === "provide" ? formStyles.active : ""}
                            >
                                Provide
                            </button>
                            <button
                                onClick={() => handleModeChange("withdraw")}
                                className={selectedMode === "withdraw" ? formStyles.active : ""}
                            >
                                Withdraw
                            </button>
                        </div>
                    </div>
                    <div className={formStyles.generalForm}>
                        {!!cpAmm && (
                            <div>
                                {selectedMode === 'swap' && (
                                    <SwapForm
                                        cpAmmKey={cpAmmPubkey!}
                                        cpAmmVM={cpAmm}
                                        user={userPublicKey}
                                        liquidityPoolService={liquidityPoolService}
                                    />
                                )}

                                {selectedMode === 'provide' && (
                                    <ProvideForm
                                        cpAmmKey={cpAmmPubkey!}
                                        cpAmmVM={cpAmm}
                                        user={userPublicKey}
                                        liquidityPoolService={liquidityPoolService}
                                    />
                                )}
                                {selectedMode === 'withdraw' && (
                                    <WithdrawForm
                                        cpAmmKey={cpAmmPubkey!}
                                        cpAmmVM={cpAmm}
                                        user={userPublicKey}
                                        liquidityPoolService={liquidityPoolService}
                                    />
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
            {!!cpAmm && (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th>Signature</th>
                        <th>Time</th>
                        <th>Action</th>
                        <th>Swapper</th>
                        <th>Swapped amount</th>
                        <th>Received amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    {trades.map((trade, idx) => (
                        <tr key={idx}>
                            <td>{shortenAddress(trade.signature, 4)}</td>
                            <td>{new Date(trade.timestamp).toLocaleTimeString()}</td>
                            <td>{shortenAddress(trade.swapper, 4)}</td>
                            {trade.isInOut ? (
                                <>
                                    <td style={{color: "#ff4d4d"}}>Sell</td>
                                    <td>{bnToString(trade.swappedAmount, cpAmm.baseTokenData.decimals)}</td>
                                    <td>{bnToString(trade.receivedAmount, cpAmm.quoteTokenData.decimals)}</td>
                                </>
                            ) : (
                                <>
                                    <td style={{color: "#4dff4d"}}>Buy</td>
                                    <td>{bnToString(trade.swappedAmount, cpAmm.quoteTokenData.decimals)}</td>
                                    <td>{bnToString(trade.receivedAmount, cpAmm.baseTokenData.decimals)}</td>
                                </>
                            )}
                        </tr>
                    ))}

                    </tbody>
                </table>
            )}
        </div>
    );
}
export default Page;