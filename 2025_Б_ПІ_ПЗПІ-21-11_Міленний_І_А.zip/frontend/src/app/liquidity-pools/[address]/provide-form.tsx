"use client"

import {BN} from "@coral-xyz/anchor";
import React, {useEffect, useMemo, useState} from "react";
import {
    bnToString,
    handlePercentageAmountClick,
    handleTokenInputChange,
    parseStringToBN, shortenAddress
} from "@/utils";
import styles from "../../form-styles.module.css";
import {CpAmmVM} from "@/models/cp-amm-vm";
import {PublicKey} from "@solana/web3.js";
import {LiquidityPoolService} from "@/services/liquidity-pool-service";
import {useNotification} from "@/components/ui/notification-context";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import {useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";


export const ProvideForm = ({cpAmmKey, cpAmmVM, user, liquidityPoolService}:
                            {cpAmmKey: PublicKey, cpAmmVM: CpAmmVM, user: PublicKey | undefined, liquidityPoolService: LiquidityPoolService}) => {
    const {notify} = useNotification();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const [baseToken, quoteToken]: [[string, TokenWithAtaBalance, BN], [string, TokenWithAtaBalance, BN]] = useMemo(() => {
        return [
            [shortenAddress(cpAmmVM.baseMint, 3), cpAmmVM.baseTokenData, cpAmmVM.baseLiquidity],
            [shortenAddress(cpAmmVM.quoteMint, 3), cpAmmVM.quoteTokenData, cpAmmVM.quoteLiquidity]
        ];
    }, [cpAmmVM]);
    const [addLiquidityString, setAddLiquidityString] = useState<string>("");
    const [addLiquidityBN, setAddLiquidityBN] = useState<BN>(new BN(0))

    const [requiredLiquidityString, setRequiredLiquidityString] = useState<string>("0");
    const [requiredLiquidityBN, setRequiredLiquidityBN] = useState<BN>(new BN(0));

    const [share, setShare] = useState<number>(0);
    const [lpTokensToMint, setLpTokensToMint] = useState<BN>(new BN(0));
    const [isProviding, setIsProviding] = useState(false);

    useEffect(() => {
        if (addLiquidityString.length > 0){
            const baseAmount = parseStringToBN(addLiquidityString, baseToken[1].decimals);
            setAddLiquidityBN(baseAmount)
            const {providedQuote, share, provideLp} = cpAmmVM.calculateProvide(baseAmount)
            setRequiredLiquidityBN(providedQuote)
            setRequiredLiquidityString(bnToString(providedQuote, quoteToken[1].decimals))
            setShare(share)
            setLpTokensToMint(provideLp)
        }
        else{
            setAddLiquidityBN(new BN(0))
            setRequiredLiquidityBN(new BN(0))
            setRequiredLiquidityString("0")
            setShare(0)
            setLpTokensToMint(new BN(0))
        }
    }, [addLiquidityString, cpAmmVM]);
    const provideToLiquidityPool = async () => {
        try {
            setIsProviding(true);
            if (addLiquidityBN.gt(baseToken[1].balance)){
                throw new Error("Insufficient base balance")
            }
            if (requiredLiquidityBN.gt(quoteToken[1].balance)){
                throw new Error("Insufficient quote balance")
            }
            let base64Tx = await liquidityPoolService.provideToCpAmm(
                user!,
                cpAmmKey,
                addLiquidityBN,
                requiredLiquidityBN
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully provided");
            setAddLiquidityString("");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsProviding(false)
    };
    return (
        <div>
           <div className={styles.field}>
                <div className={styles.baseContainer}>
                    <label>Base</label>
                    <div className={styles.percentageButtons}>
                        {[25, 50, 75, 100].map((percentage) => (
                            <button key={percentage} onClick={() => handlePercentageAmountClick(
                                baseToken[1],
                                percentage,
                                setAddLiquidityString
                            )}>
                                {percentage}%
                            </button>
                        ))}
                    </div>
                </div>
                <div className={styles.inputContainer}>
                    <div className={styles.tokenSymbol}>
                        {baseToken[0]}
                    </div>
                    <input
                        type="text"
                        value={addLiquidityString}
                        onChange={(e) => handleTokenInputChange(e, setAddLiquidityString)}
                        placeholder={"Enter providing amount"}
                    />
                </div>

               <div className={styles.balance}>
                   <span>Your balance: {bnToString(baseToken[1].balance, baseToken[1].decimals)}</span>
                   <span>Pool balance: {bnToString(baseToken[2], baseToken[1].decimals)}</span>
               </div>
            </div>
            <hr className={styles.divider}/>
            <div className={styles.field}>
                <label>Quote</label>
                <div className={styles.inputContainer}>
                    <span className={styles.tokenSymbol}>{quoteToken[0]}</span>
                    <input type="text" value={requiredLiquidityString} readOnly/>
                </div>
                <div className={styles.balance}>
                    <span>Your balance: {bnToString(quoteToken[1].balance, quoteToken[1].decimals)}</span>
                    <span>Pool balance: {bnToString(quoteToken[2], quoteToken[1].decimals)}</span>
                </div>
            </div>
            <div className={styles.bottomContainer}>
                <div className={styles.utils}>
                    <div className={styles.utilsText}>
                        <strong>LP tokens to receive: {lpTokensToMint.toString()}</strong>
                        <strong>Share increase by {share.toString()}%</strong>
                    </div>
                </div>
                <div className={styles.buttonContainer}>
                    <button className={styles.actionButton} onClick={provideToLiquidityPool} disabled={!user || isProviding || addLiquidityBN.eqn(0) || requiredLiquidityBN.eqn(0)} title={"Click to Provide"}>
                        Provide
                    </button>
                </div>
                </div>
            </div>
            );
}