"use client"

import React, {useEffect, useMemo, useState} from "react";
import {
    bnToString,
    handlePercentageAmountClick,
    handleTokenInputChange,
    parseStringToBN, shortenAddress
} from "@/utils";

import styles from "../../form-styles.module.css";
import {CpAmmVM} from "@/models/cp-amm-vm";
import {PublicKey} from "@solana/web3.js";
import {LiquidityPoolService} from "@/services/liquidity-pool-service";
import {useNotification} from "@/components/ui/notification-context";
import {useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import {BN} from "@coral-xyz/anchor";

export const WithdrawForm = ({cpAmmKey, cpAmmVM, user, liquidityPoolService}:
                             {cpAmmKey: PublicKey, cpAmmVM: CpAmmVM, user: PublicKey | undefined, liquidityPoolService: LiquidityPoolService}) => {
    const {notify} = useNotification();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const [lpToken, baseToken, quoteToken]: [[string, TokenWithAtaBalance, BN], [string, TokenWithAtaBalance, BN], [string, TokenWithAtaBalance, BN]] = useMemo(() => {
        return [
            [shortenAddress(cpAmmVM.lpMint, 3), cpAmmVM.lpTokenData, cpAmmVM.lpTokensSupply],
            [shortenAddress(cpAmmVM.baseMint, 3), cpAmmVM.baseTokenData, cpAmmVM.baseLiquidity],
            [shortenAddress(cpAmmVM.quoteMint, 3), cpAmmVM.quoteTokenData, cpAmmVM.quoteLiquidity]
        ];
    }, [cpAmmVM]);

    const [burnLpString, setBurnLpString] = useState<string>("");
    const [burnLpBN, setBurnLpBN] = useState<BN>(new BN(0));
    const [baseReturnString, setBaseReturnString] = useState<string>("0");
    const [quoteReturnString, setQuoteReturnString] = useState<string>("0");

    const share = useMemo(() => cpAmmVM.calculateShare(lpToken[1].balance).toNumber() / 10_000_000, [cpAmmVM]);
    const [isWithdrawing, setIsWithdrawing] = useState(false);

    useEffect(() => {
        if (burnLpString.length > 0){
            const lpAmount = parseStringToBN(burnLpString, lpToken[1].decimals);
            setBurnLpBN(lpAmount)
            const {withdrawBase, withdrawQuote} = cpAmmVM.calculateWithdraw(lpAmount);
            setBaseReturnString(bnToString(withdrawBase, baseToken[1].decimals));
            setQuoteReturnString(bnToString(withdrawQuote, quoteToken[1].decimals));
        }
        else{
            setBurnLpBN(new BN(0))
            setBaseReturnString("0");
            setQuoteReturnString("0");
        }
    }, [burnLpString, cpAmmVM]);
    const withdrawFromLiquidityPool = async () => {
        try {
            setIsWithdrawing(true);
            if (burnLpBN.gt(lpToken[1].balance)){
                throw new Error("Insufficient lp balance")
            }
            let base64Tx = await liquidityPoolService.withdrawFromCpAmm(
                user!,
                cpAmmKey,
                burnLpBN
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully withdrawn");
            setBurnLpString("");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsWithdrawing(false)
    };
    return (
        <div style={{display: "flex", flexDirection: "column", height: "500px"}}>
            <div className={styles.field}>
                <div className={styles.baseContainer}>
                    <label>Base</label>
                    <div className={styles.percentageButtons}>
                        {[25, 50, 75, 100].map((percentage) => (
                            <button key={percentage} onClick={() => handlePercentageAmountClick(
                                lpToken[1],
                                percentage,
                                setBurnLpString
                            )}>
                                {percentage}%
                            </button>
                        ))}
                    </div>
                </div>
                <div className={styles.inputContainer}>
                    <div className={styles.tokenSymbol}>
                        {`${lpToken[0]} LP`}
                    </div>
                    <input
                        type="text"
                        value={burnLpString}
                        onChange={(e) => handleTokenInputChange(e, setBurnLpString)}
                        placeholder={"Enter burning amount"}
                    />
                </div>

                <div className={styles.balance}>
                    <span>Your balance: {bnToString(lpToken[1].balance, lpToken[1].decimals)}</span>
                    <span>Total supply: {bnToString(cpAmmVM.lpTokensSupply, lpToken[1].decimals)}</span>
                </div>
                <hr className={styles.divider}/>
                <div className={styles.detailsContainer}>
                    <div className={styles.detail}>
                        <span>Your share</span>
                        <span>{share}%</span>
                    </div>
                </div>
            </div>
            <div className={styles.bottomContainer}>
                <div className={styles.utils}>
                    <div className={styles.utilsText}>
                        <strong>{baseToken[0]} to receive: {baseReturnString}</strong>
                        <strong>{quoteToken[0]} to receive: {quoteReturnString}</strong>
                    </div>
                </div>
                <div className={styles.buttonContainer}>
                    <button className={styles.actionButton} onClick={withdrawFromLiquidityPool} disabled={!user || isWithdrawing || burnLpBN.eqn(0)} title={"Click to Withdraw"}>
                        Withdraw
                    </button>
                </div>
            </div>
        </div>
    );
}