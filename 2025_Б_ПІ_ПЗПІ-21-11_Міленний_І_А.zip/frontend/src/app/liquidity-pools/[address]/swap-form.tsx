"use client"

import {BN} from "@coral-xyz/anchor";
import React, {useEffect, useState} from "react";
import {
    handleTokenInputChange,
    handlePercentageAmountClick,
    bnToString,
    parseStringToBN, shortenAddress
} from "@/utils";
import stylesSwap from "../../../components/liquidity-pool/swap/swap-form.module.css";
import styles from "../../form-styles.module.css";
import {ReverseButton} from "@/components/liquidity-pool/form-parts";
import {CpAmmVM} from "@/models/cp-amm-vm";
import {PublicKey} from "@solana/web3.js";
import {LiquidityPoolService} from "@/services/liquidity-pool-service";
import {useNotification} from "@/components/ui/notification-context";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import {useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";

export const SwapForm = ({cpAmmKey, cpAmmVM, user, liquidityPoolService}:
                         {
                             cpAmmKey: PublicKey,
                             cpAmmVM: CpAmmVM,
                             user: PublicKey | undefined,
                             liquidityPoolService: LiquidityPoolService
                         }) => {
    const {notify} = useNotification();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const [fromToken, setFromToken] = useState<[string, TokenWithAtaBalance, BN]>([shortenAddress(cpAmmVM.quoteMint, 3), cpAmmVM.quoteTokenData, cpAmmVM.quoteLiquidity]);
    const [toToken, setToToken] = useState<[string, TokenWithAtaBalance, BN]>([shortenAddress(cpAmmVM.baseMint, 3), cpAmmVM.baseTokenData, cpAmmVM.baseLiquidity]);
    const [fromString, setFromString] = useState<string>("");
    const [fromBN, setFromBN] = useState<BN>(new BN(0))
    const [toString, setToString] = useState<string>("0");
    const [toBN, setToBN] = useState<BN>(new BN(0));
    const [toFeeBN, setToFeeBN] = useState<BN>(new BN(0));
    const [fromFeeBN, setFromFeeBN] = useState<BN>(new BN(0));

    const [allowedSlippage, setAllowedSlippage] = useState<BN>(new BN(0));
    const [isInOut, setIsInOut] = useState(false);

    const [slippage, setSlippage] = useState<number>(0.5);
    const [isSwapping, setIsSwapping] = useState(false);
    useEffect(() => {
        if (fromString.length > 0) {
            const fromAmount = parseStringToBN(fromString, fromToken[1].decimals);
            setFromBN(fromAmount)
            const {
                estimatedFee: toFee,
                estimatedAmountAfterFee: toAfterFee,
                allowedSlippage: allowedSlippage,
                swapAmountTransferFee: fromTransferFee,
                swapAmountPoolFee: fromPoolFee
            } = cpAmmVM.calculateSwapAndFeeAmount(fromAmount, slippage * 100, isInOut)
            const fromFee = fromTransferFee.add(fromPoolFee);
            setToBN(toAfterFee)
            setFromBN(fromAmount)
            setFromFeeBN(fromFee)
            setToFeeBN(toFee)
            setAllowedSlippage(allowedSlippage)
            setToString(bnToString(toAfterFee, toToken[1].decimals))
        } else {
            setFromBN(new BN(0))
            setToBN(new BN(0))
            setToFeeBN(new BN(0))
            setFromBN(new BN(0))
            setToString("0")
            setAllowedSlippage(new BN(0))
        }
    }, [fromString, cpAmmVM]);
    useEffect(() => {
        if (!isInOut) {
            setFromToken([shortenAddress(cpAmmVM.quoteMint, 3), cpAmmVM.quoteTokenData, cpAmmVM.quoteLiquidity])
            setToToken([shortenAddress(cpAmmVM.baseMint, 3), cpAmmVM.baseTokenData, cpAmmVM.baseLiquidity])
        } else {
            setToToken([shortenAddress(cpAmmVM.quoteMint, 3), cpAmmVM.quoteTokenData, cpAmmVM.quoteLiquidity])
            setFromToken([shortenAddress(cpAmmVM.baseMint, 3), cpAmmVM.baseTokenData, cpAmmVM.baseLiquidity])
        }
    }, [cpAmmVM]);
    useEffect(() => {
        setAllowedSlippage(toBN.mul(new BN(slippage)).div(new BN(100)))
    }, [slippage]);
    const handleReverseClick = () => {
        setIsInOut(!isInOut);
        setFromToken(toToken);
        setToToken(fromToken)
        setFromString(toString);
    };
    const swapInLiquidityPool = async () => {
        try {
            setIsSwapping(true);
            if (fromBN.gt(fromToken[1].balance)) {
                throw new Error("Insufficient balance for swap")
            }
            let base64Tx = await liquidityPoolService.swapInCpAmm(
                user!,
                cpAmmKey,
                fromBN,
                toBN.add(toFeeBN),
                allowedSlippage,
                isInOut
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully swapped");
            setFromString("");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsSwapping(false)
    };

    return (
        <div>
            <div className={styles.field}>
                <div className={styles.baseContainer}>
                    <label>Sell</label>
                    <div className={styles.percentageButtons}>
                        {[25, 50, 75, 100].map((percentage) => (
                            <button
                                key={percentage}
                                onClick={() =>
                                    handlePercentageAmountClick(
                                        fromToken[1],
                                        percentage,
                                        setFromString
                                    )
                                }
                            >
                                {percentage}%
                            </button>
                        ))}
                    </div>
                </div>
                <div className={styles.inputContainer}>
                    <div className={styles.tokenSymbol}>
                        {fromToken[0]}
                    </div>
                    <input
                        type="text"
                        value={fromString}
                        onChange={(e) => handleTokenInputChange(e, setFromString)}
                        placeholder="Enter swap amount"
                    />
                </div>
                <div className={styles.balance}>
                    <span>Your balance: {bnToString(fromToken[1].balance, fromToken[1].decimals)}</span>
                    <span>Pool balance: {bnToString(fromToken[2], fromToken[1].decimals)}</span>
                </div>
            </div>
            <div className={styles.reverseButtonContainer}>
                <ReverseButton handleReverseClick={handleReverseClick}/>
            </div>
            <div className={styles.field}>
                <label>Buy</label>
                <div className={styles.inputContainer}>
                    <span className={styles.tokenSymbol}>{toToken[0]}</span>
                    <input type="text" value={toString} readOnly/>
                </div>
                <div className={styles.balance}>
                    <span>Your balance: {bnToString(toToken[1].balance, toToken[1].decimals)}</span>
                    <span>Pool balance: {bnToString(toToken[2], toToken[1].decimals)}</span>
                </div>
                <hr className={styles.divider}/>
                <div className={styles.detailsContainer}>
                    <div className={styles.balance}>
                        <strong>Fee</strong>
                    </div>
                    <div className={styles.balance}>
                        <span>{bnToString(fromFeeBN, fromToken[1].decimals)} {fromToken[0]}</span>
                        <span>{bnToString(toFeeBN, toToken[1].decimals)} {toToken[0]}</span>
                    </div>
                </div>
            </div>
            <div className={stylesSwap.slippageContainer}>
                <label>Slippage</label>
                <input
                    type="range"
                    min="0.0"
                    max="100.0"
                    step="0.1"
                    value={slippage}
                    onChange={(e) => setSlippage(parseFloat(e.target.value))}
                />
                <input
                    type="number"
                    min="0.0"
                    max="100.0"
                    step="0.1"
                    value={slippage}
                    onChange={(e) => setSlippage(parseFloat(e.target.value))}
                />
            </div>
            <div className={styles.bottomContainer}>
                <div className={styles.buttonContainer}>
                    <button className={styles.actionButton} onClick={swapInLiquidityPool}
                            disabled={!user || isSwapping || fromBN.eqn(0)} title={"Click to Swap"}>
                        Swap
                    </button>
                </div>
            </div>
        </div>
    );
}