"use client"
import React, {useMemo} from "react";
import formStyles from "../../form-styles.module.css";
import styles from "../../styles.module.css";
import {usePublicKey} from "@/components/solana/solana-context-wrapper";
import {useParams} from "next/navigation";
import {PublicKey} from "@solana/web3.js";
import LoadingError from "@/components/ui/error";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import Loader from "@/components/ui/loader";
import {LaunchForm} from "@/app/launchpools/[address]/launch-form";
import {bnToString} from "@/utils";
import {WaitingForm} from "@/app/launchpools/[address]/waiting-form";
import {StakeForm} from "@/app/launchpools/[address]/stake-form";
import {CloseForm} from "@/app/launchpools/[address]/close-form";

const Page = () => {
    const userPublicKey = usePublicKey();
    const launchpoolService = useLaunchpoolService();

    const timestampMs = Date.now();

    const {address} = useParams();
    const launchpoolPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch (e) {
            return null;
        }
    }, [address]);
    if (!launchpoolPubkey) {
        return <LoadingError error={new Error(`Invalid Launchpool address: ${address}`)}/>;
    }

    const {
        data: launchpool,
        isLoading: isLaunchpool,
        error: errorLaunchpool
    } = launchpoolService.fetchLaunchpoolVM(launchpoolPubkey, userPublicKey);

    if (!!errorLaunchpool) {
        return <LoadingError error={errorLaunchpool}/>;
    }

    if (isLaunchpool) {
        return <Loader></Loader>;
    }
    if (!launchpool) {
        return <LoadingError error={new Error("This launchpool doesn't exist")}></LoadingError>;
    }
    if (launchpool.status == "Uninitialized") {
        return <LoadingError error={new Error("Launchpool is uninitialized")}></LoadingError>
    }
    let layout = <div></div>
    if (launchpool.status == "Initialized") {
        layout = <LaunchForm launchpoolKey={launchpoolPubkey} launchpoolVM={launchpool} user={userPublicKey}
                             launchpoolService={launchpoolService}></LaunchForm>
    } else {
        if (launchpool.status == "Launched" && timestampMs < launchpool.endTimestamp) {
            if (timestampMs >= launchpool.startTimestamp) {
                layout = <StakeForm launchpoolKey={launchpoolPubkey} launchpoolVM={launchpool} user={userPublicKey}
                                    launchpoolService={launchpoolService}></StakeForm>
            } else {
                layout = <WaitingForm></WaitingForm>
            }
        } else if (launchpool.status == "ClaimedProtocolReward" || launchpool.status == "Finished" || (launchpool.status == "Launched" && timestampMs >= launchpool.endTimestamp)) {
            layout = <CloseForm launchpoolKey={launchpoolPubkey} launchpoolVM={launchpool} user={userPublicKey}
                                launchpoolService={launchpoolService}></CloseForm>
        } else {
            return <LoadingError error={new Error("Launchpool is unavailable")}></LoadingError>
        }
    }
    return (
        <div className={styles.pageContainer}>
            <div className={formStyles.stakingCard}>
                <div className={formStyles.launchpoolCard}>
                    <div className={formStyles.baseContainer}>
                        <label>Status</label>
                        <div>{launchpool.status}</div>
                    </div>
                    <hr className={formStyles.divider}/>
                    <div className={formStyles.baseContainer}>
                        <label>Reward Token</label>
                        <div>{launchpool.rewardMint.toString()}</div>
                        <hr className={formStyles.divider}/>
                        <label>Reward Vault</label>
                        <div>{launchpool.rewardVault.toString()}</div>
                        <hr className={formStyles.divider}/>
                        <div className={formStyles.baseContainer}>
                            <label>Participant Rewards</label>
                            <div>
                                <strong>Total</strong>
                                <div>{bnToString(launchpool.participantsRewardAmount, launchpool.rewardTokenData.decimals)}</div>
                                <strong>Left to obtain</strong>
                                <div>{bnToString(launchpool.participantsRewardLeftToObtain, launchpool.rewardTokenData.decimals)}</div>
                                <strong>Left to distribute</strong>
                                <div>{bnToString(launchpool.participantsRewardLeftToDistribute, launchpool.rewardTokenData.decimals)}</div>
                            </div>
                            <hr className={formStyles.divider}/>
                            <label>Protocol Rewards</label>
                            <div>
                                <strong>Total</strong>
                                <div>{bnToString(launchpool.protocolRewardAmount, launchpool.rewardTokenData.decimals)}</div>
                                <strong>Left to obtain</strong>
                                <div>{bnToString(launchpool.protocolRewardLeftToObtain, launchpool.rewardTokenData.decimals)}</div>
                            </div>
                        </div>
                    </div>
                    <hr className={formStyles.divider}/>
                    <div className={formStyles.baseContainer}>
                        <label>Stakable Token</label>
                        <div>{launchpool.stakableMint.toString()}</div>
                        <hr className={formStyles.divider}/>
                        <div className={formStyles.baseContainer}>
                            <label>Staked Total</label>
                            <div>{bnToString(launchpool.stakedAmount, launchpool.stakableTokenData.decimals)}</div>
                            <hr className={formStyles.divider}/>
                            <label>Minimal position size</label>
                            <div>{bnToString(launchpool.minPositionSize, launchpool.stakableTokenData.decimals)}</div>
                            <label>Maximum position size</label>
                            <div>{bnToString(launchpool.maxPositionSize, launchpool.stakableTokenData.decimals)}</div>
                        </div>
                    </div>
                    <hr className={formStyles.divider}/>
                    <div className={formStyles.baseContainer}>
                        <label>Start</label>
                        <div>
                            {launchpool.startTimestamp > 0
                                ? new Date(launchpool.startTimestamp).toLocaleString()
                                : "Not set"}
                        </div>
                    </div>
                    <hr className={formStyles.divider}/>
                    <div className={formStyles.baseContainer}>
                        <label>End</label>
                        <div>
                            {launchpool.startTimestamp > 0
                                ? new Date(launchpool.endTimestamp).toLocaleString()
                                : "Not set"}
                        </div>
                    </div>
                    <hr className={formStyles.divider}/>
                    <div className={formStyles.baseContainer}>
                        <label>Last Updated</label>
                        <div>
                            {launchpool.startTimestamp > 0
                                ? new Date(launchpool.lastUpdateTimestamp).toLocaleString()
                                : "Not set"}
                        </div>
                    </div>
                </div>
                <div style={{display: "flex", alignItems: "center"}}>
                    <div className={formStyles.launchpoolCard}>
                        {layout}
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;