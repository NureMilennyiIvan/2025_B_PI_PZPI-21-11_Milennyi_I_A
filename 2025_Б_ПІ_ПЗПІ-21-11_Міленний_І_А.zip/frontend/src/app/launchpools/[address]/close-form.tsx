"use client"
import React, {useState} from "react";
import {useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {PublicKey} from "@solana/web3.js";
import {LaunchpoolService} from "@/services/launchpool-service";
import {
    bnToString,
} from "@/utils";
import {LaunchpoolVM} from "@/models/launchpool-vm";
import formStyles from "../../form-styles.module.css";
import styles from "../../styles.module.css";
import {useNotification} from "@/components/ui/notification-context";
import {BN} from "@coral-xyz/anchor";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faHandHoldingDollar} from "@fortawesome/free-solid-svg-icons";

export const CloseForm = ({launchpoolKey, launchpoolVM, user, launchpoolService}:
                          {
                              launchpoolKey: PublicKey,
                              launchpoolVM: LaunchpoolVM,
                              user: PublicKey | undefined,
                              launchpoolService: LaunchpoolService
                          }) => {
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const [isClosing, setIsClosing] = useState(false);
    const {notify} = useNotification();

    const closeInLaunchpool = async () => {
        try {
            setIsClosing(true);
            let base64Tx = await launchpoolService.closeStakePosition(
                user!,
                null,
                launchpoolVM.stakePositionVM!.key
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully closed");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsClosing(false)
    }
    const collectProtocolReward = async () => {
        try {
            setIsClosing(true);
            let base64Tx = await launchpoolService.collectProtocolReward(
                user!,
                launchpoolKey
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully collected");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsClosing(false)
    }
    return (
        <div className={formStyles.liquidityPoolPageForm}>
            <div className={formStyles.field}>
                <div className={formStyles.detailsContainer}>
                    <div className={formStyles.detail}>
                        <span>Staked Amount</span>
                        <span>{bnToString(launchpoolVM.stakePositionVM?.amount ?? new BN(0), launchpoolVM.stakableTokenData.decimals)}</span>
                    </div>
                    <hr className={formStyles.divider}/>
                    <div className={formStyles.detail}>
                        <span>Accumulated Reward</span>
                        <span>{bnToString(launchpoolVM.stakePositionVM?.rewardEarned ?? new BN(0), launchpoolVM.rewardTokenData.decimals)}</span>
                    </div>
                </div>

            </div>
            <div className={styles.header}>
                <button className={formStyles.harvestButton} onClick={collectProtocolReward}
                        disabled={isClosing || !user || launchpoolVM.protocolRewardLeftToObtain.eqn(0)}
                        title="Collect Protocol Reward">
                    <FontAwesomeIcon icon={faHandHoldingDollar} className={styles.icon}/>
                </button>
            </div>
            <div className={formStyles.buttonContainer}>
                <button className={formStyles.actionButton} onClick={closeInLaunchpool}
                        disabled={!user || !launchpoolVM.stakePositionVM || isClosing} title={"Click to Close"}>
                    Close Position
                </button>
            </div>
        </div>
    );
}