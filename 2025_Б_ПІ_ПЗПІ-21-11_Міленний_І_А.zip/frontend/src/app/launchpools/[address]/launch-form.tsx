"use client"
import React, {useEffect, useMemo, useState} from "react";
import {links} from "@/components/ui/general-page-layout";
import {useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {PublicKey} from "@solana/web3.js";
import {LaunchpoolService} from "@/services/launchpool-service";
import {useRouter} from "next/navigation";
import {bnToString} from "@/utils";
import {LaunchpoolVM} from "@/models/launchpool-vm";
import formStyles from "../../form-styles.module.css";
import {useNotification} from "@/components/ui/notification-context";
import styles from "@/app/form-styles.module.css";

export const LaunchForm = ({launchpoolKey, launchpoolVM, user, launchpoolService}:
                           {
                               launchpoolKey: PublicKey,
                               launchpoolVM: LaunchpoolVM,
                               user: PublicKey | undefined,
                               launchpoolService: LaunchpoolService
                           }) => {
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const router = useRouter();
    const [isLaunching, setIsLaunching] = useState(false);
    const {notify} = useNotification();
    const [startTime, setStartTime] = useState<string>(() => {
        const now = new Date();
        now.setHours(now.getHours() + 1);
        now.setMinutes(0, 0, 0);

        const pad = (n: number) => n.toString().padStart(2, '0');
        const yyyy = now.getFullYear();
        const mm = pad(now.getMonth() + 1);
        const dd = pad(now.getDate());
        const hh = pad(now.getHours());
        const min = pad(now.getMinutes());

        return `${yyyy}-${mm}-${dd}T${hh}:${min}`;
    });
    const [endTime, setEndTime] = useState<string>("");

    const {
        data: launchpoolsConfigsManager,
        isLoading: isLaunchpoolsConfigsManager,
        error: errorLaunchpoolsConfigsManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();
    const isUserAuthority = useMemo(() => {
        if (!user || !launchpoolsConfigsManager) return false;
        const userKey = user.toBase58();
        return launchpoolsConfigsManager.authority === userKey || launchpoolsConfigsManager.headAuthority === userKey;
    }, [user, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);
    useEffect(() => {
        let start = new Date(startTime).getTime() / 1000;
        let end = new Date((start + launchpoolVM.duration) * 1000)

        const pad = (n: number) => n.toString().padStart(2, '0');
        const yyyy = end.getFullYear();
        const mm = pad(end.getMonth() + 1);
        const dd = pad(end.getDate());
        const hh = pad(end.getHours());
        const min = pad(end.getMinutes());

        const formattedEnd = `${yyyy}-${mm}-${dd}T${hh}:${min}`;
        setEndTime(formattedEnd);
    }, [startTime]);
    const handleTimeChange = (value: string) => {
        setStartTime(value)
        let start = new Date(value).getTime() / 1000;
        let end = new Date((start + launchpoolVM.duration) * 1000)

        const pad = (n: number) => n.toString().padStart(2, '0');
        const yyyy = end.getFullYear();
        const mm = pad(end.getMonth() + 1);
        const dd = pad(end.getDate());
        const hh = pad(end.getHours());
        const min = pad(end.getMinutes());

        const formattedEnd = `${yyyy}-${mm}-${dd}T${hh}:${min}`;
        setEndTime(formattedEnd);
    }
    const launchLaunchpool = async () => {
        try {
            setIsLaunching(true);
            const startTimestampSec = Math.floor(new Date(startTime).getTime() / 1000);

            if (startTimestampSec < new Date().getTime() / 1000 + 60) {
                throw new Error("Start of the launchpool must be at least a minute after now");
            }
            let base64Tx = await launchpoolService.launchLaunchpool(
                user!,
                launchpoolKey,
                startTimestampSec
            );
            await signAndSendBase64Tx!(base64Tx);
            notify("success", "Successfully initialized");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsLaunching(false)
    };
    return (
        <div className={formStyles.liquidityPoolPageForm}>

            <div className={formStyles.inputContainer}>
                <span className={formStyles.tokenSymbol}>Start</span>
                <input
                    type="datetime-local"
                    value={startTime}
                    onChange={(e) => handleTimeChange(e.target.value)}
                    className="border p-2 rounded"
                />
            </div>
            <div className={formStyles.inputContainer}>
                <span className={formStyles.tokenSymbol}>End</span>
                <input
                    type="datetime-local"
                    value={endTime}
                    readOnly
                    className="border p-2 rounded bg-gray-100"
                />
            </div>
            <div className={formStyles.balance}>
                <span>Required reward amount: {bnToString(launchpoolVM.initialRewardAmount, launchpoolVM.rewardTokenData.decimals)}</span>
                <span>Provided reward amount: {bnToString(launchpoolVM.rewardTokenData.balance, launchpoolVM.rewardTokenData.decimals)}</span>
            </div>
            <div className={styles.buttonContainer}>
                <button className={formStyles.actionButton} onClick={launchLaunchpool} disabled={!user || isLaunching}
                        title={"Click to Launch"}>
                    Launch
                </button>
            </div>
        </div>
    );
}