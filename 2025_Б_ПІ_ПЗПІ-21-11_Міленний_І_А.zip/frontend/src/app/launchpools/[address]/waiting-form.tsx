"use client"
import React from "react";
import styles from "../../styles.module.css";

export const WaitingForm = () => {
    return (
        <div style={{display: "flex", justifyContent: "center"}}>
            <label className={styles.message}>Launchpool not started yet</label>
        </div>
    );
}