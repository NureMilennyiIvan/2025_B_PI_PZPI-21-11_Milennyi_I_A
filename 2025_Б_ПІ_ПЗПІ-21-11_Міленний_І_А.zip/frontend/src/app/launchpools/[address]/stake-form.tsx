"use client"
import React, {useEffect, useMemo, useState} from "react";
import {useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {PublicKey} from "@solana/web3.js";
import {LaunchpoolService} from "@/services/launchpool-service";
import {
    bnToString,
    handlePercentageAmountClick,
    handleTokenInputChange,
    parseStringToBN,
    shortenAddress
} from "@/utils";
import {LaunchpoolVM} from "@/models/launchpool-vm";
import styles from "../style.module.css";
import {useNotification} from "@/components/ui/notification-context";
import {TokenWithAtaBalance} from "@/models/token-with-ata-balance";
import {BN} from "@coral-xyz/anchor";

export const StakeForm = ({launchpoolKey, launchpoolVM, user, launchpoolService}:
                          {
                              launchpoolKey: PublicKey,
                              launchpoolVM: LaunchpoolVM,
                              user: PublicKey | undefined,
                              launchpoolService: LaunchpoolService
                          }) => {
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const [isStaking, setIsStaking] = useState(false);
    const {notify} = useNotification();
    const [stakeString, setStakeString] = useState("");
    const [stakeBN, setStakeBN] = useState(new BN(0));
    const stakeToken: [string, TokenWithAtaBalance] = useMemo(() => {
        return [shortenAddress(launchpoolVM.stakableMint, 3), launchpoolVM.stakableTokenData];
    }, [launchpoolVM]);
    useEffect(() => {
        if (stakeString.length > 0) {
            const stakeAmount = parseStringToBN(stakeString, stakeToken[1].decimals);
            setStakeBN(stakeAmount)
        } else {
            setStakeBN(new BN(0))
        }
    }, [stakeString, launchpoolVM]);
    const stakeInLaunchpool = async () => {
        try {
            setIsStaking(true);
            if (!launchpoolVM.stakePositionVM) {
                if (stakeBN.gt(launchpoolVM.maxPositionSize)) {
                    throw new Error("Stake position exceeds max position size")
                }
                if (stakeBN.lt(launchpoolVM.minPositionSize)) {
                    throw new Error("Stake position is less than min position size")
                }
                let [base64Tx, _] = await launchpoolService.openStakePosition(
                    user!,
                    null,
                    launchpoolKey,
                    stakeBN
                );
                await signAndSendBase64Tx!(base64Tx);
            } else {
                let stake = stakeBN.add(launchpoolVM.stakePositionVM.amount)
                if (stake.gt(launchpoolVM.maxPositionSize)) {
                    throw new Error("Stake position exceeds max position size")
                }
                if (stake.lt(launchpoolVM.minPositionSize)) {
                    throw new Error("Stake position is less than min position size")
                }
                let base64Tx = await launchpoolService.increaseStakePosition(
                    user!,
                    null,
                    launchpoolVM.stakePositionVM.key,
                    stakeBN
                );
                await signAndSendBase64Tx!(base64Tx);
            }
            notify("success", "Successfully staked");
            setStakeString("");
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
        }
        setIsStaking(false)
    }
    return (
        <div className={styles.liquidityPoolPageForm}>
            <div className={styles.field}>
                <div className={styles.baseContainer}>
                    <label>Stake</label>
                    <div className={styles.percentageButtons}>
                        {[25, 50, 75, 100].map((percentage) => (
                            <button
                                key={percentage}
                                onClick={() =>
                                    handlePercentageAmountClick(
                                        stakeToken[1],
                                        percentage,
                                        setStakeString
                                    )
                                }
                            >
                                {percentage}%
                            </button>
                        ))}
                    </div>
                </div>
                <div className={styles.inputContainer}>
                    <div className={styles.tokenSymbol}>
                        {stakeToken[0]}
                    </div>
                    <input
                        type="text"
                        value={stakeString}
                        onChange={(e) => handleTokenInputChange(e, setStakeString)}
                        placeholder="Enter stake amount"
                    />
                </div>
                <div className={styles.balance}>
                    <span>Your balance: {bnToString(stakeToken[1].balance, stakeToken[1].decimals)}</span>
                    <span>Your position size: {bnToString(launchpoolVM.stakePositionVM?.amount ?? new BN(0), stakeToken[1].decimals)}</span>
                </div>
                <hr className={styles.divider}/>
                <div className={styles.detailsContainer}>
                    <div className={styles.detail}>
                        <span>Accumulated Reward: {bnToString(launchpoolVM.stakePositionVM?.rewardEarned ?? new BN(0), launchpoolVM.rewardTokenData.decimals)}</span>
                    </div>
                </div>
            </div>
            <button className={styles.actionButton} onClick={stakeInLaunchpool}
                    disabled={!user || isStaking || stakeBN.eqn(0)} title={"Click to Stake"}>
                Stake
            </button>
        </div>
    );
}