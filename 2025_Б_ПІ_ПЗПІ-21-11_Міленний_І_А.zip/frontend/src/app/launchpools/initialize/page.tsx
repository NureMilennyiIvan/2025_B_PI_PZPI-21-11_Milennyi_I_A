"use client"

import React, {useEffect, useMemo, useState} from "react";
import {PublicKey} from "@solana/web3.js";
import formStyles from "../../form-styles.module.css";
import styles from "../../styles.module.css";
import {usePublicKey, useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {
    bnToString,
    handlePubkeyChange,
    handleTokenInputChange,
    parseStringToBN
} from "@/utils";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useNotification} from "@/components/ui/notification-context";
import {useRouter} from "next/navigation";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import {LaunchpoolsConfigVM} from "@/models/launchpools-config-vm";
import {links} from "@/components/ui/general-page-layout";


const Page = () => {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();
    const {notify} = useNotification();
    const [rewardMint, setRewardMint] = useState<PublicKey | undefined>(undefined);
    const {
        data: launchpoolsConfigsManager,
        isLoading: isLaunchpoolsConfigsManager,
        error: errorLaunchpoolsConfigsManager
    } = launchpoolService.fetchLaunchpoolsConfigsManagerVM();
    const {
        data: rewardToken,
        isLoading: isRewardToken,
        error: errorRewardToken
    } = launchpoolService.fetchTokenMintWithAtaBalance(rewardMint, userPublicKey);

    const {
        data: launchpoolsConfigVMs,
        isLoading: isLaunchpoolsConfigVMs,
        error: errorLaunchpoolsConfigVMs
    } = launchpoolService.fetchLaunchpoolsConfigVMs();
    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return launchpoolsConfigsManager.authority === user || launchpoolsConfigsManager.headAuthority === user;
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    const [launchpoolsConfigVMsRenderer, setLaunchpoolsConfigVMsRenderer] = useState<LaunchpoolsConfigVM[]>([]);
    const [selectedLaunchpoolsConfigKey, setSelectedLaunchpoolsConfigKey] = useState<string | undefined>(undefined);


    useEffect(() => {
        if (launchpoolsConfigVMs) {
            setLaunchpoolsConfigVMsRenderer(launchpoolsConfigVMs);
        }
    }, [launchpoolsConfigVMs]);

    useEffect(() => {
        if (!selectedLaunchpoolsConfigKey && launchpoolsConfigVMsRenderer.length > 0) {
            setSelectedLaunchpoolsConfigKey(launchpoolsConfigVMsRenderer[0].key.toBase58());
        }
    }, [launchpoolsConfigVMsRenderer, selectedLaunchpoolsConfigKey]);

    const [rewardMintStr, setRewardMintStr] = useState("");
    const [initialRewardInput, setInitialRewardInput] = useState<string>("");
    const [isInitializing, setIsInitializing] = useState(false);
    const rewardSupply = useMemo(() => {
        if (!rewardToken) {
            return "0";
        }
        return bnToString(rewardToken.supply, rewardToken.decimals)
    }, [rewardToken]);

    if (!!errorLaunchpoolsConfigVMs) {
        return <LoadingError error={errorLaunchpoolsConfigVMs}/>;
    }
    if (launchpoolsConfigVMsRenderer.length == 0 || isLaunchpoolsConfigVMs) {
        return <Loader/>;
    }

    const selectedLaunchpoolsConfig = launchpoolsConfigVMsRenderer.find(
        (config) => config.key.toBase58() === selectedLaunchpoolsConfigKey
    );

    const initializeLiquidityPool = async () => {
        try {
            setIsInitializing(true);
            const rewardMintKey = rewardMint!;
            const initial = parseStringToBN(initialRewardInput, rewardToken!.decimals);
            if (initial.ltn(0)) {
                throw new Error("Initial amount must be greater than 0")
            }
            if (initial.gt(rewardToken!.supply)) {
                throw new Error("Initial amount must be less than token supply")
            }
            const launchpoolsConfig = selectedLaunchpoolsConfig!;
            let [base64Tx, launchpool] = await launchpoolService.initializeLaunchpool(
                userPublicKey!,
                launchpoolsConfig.key,
                rewardMintKey,
                initial
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.launchpools.path}/${launchpool}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsInitializing(false)
        }

    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label htmlFor="launchpoolsConfigSelect">Reward Token</label>

                    <div className={formStyles.inputContainer}>
                        <input
                            type="text"
                            placeholder="Reward Mint"
                            value={rewardMintStr}
                            onChange={(e) => handlePubkeyChange(e.target.value, setRewardMintStr, setRewardMint)}
                        />
                    </div>
                    <div className={formStyles.balance}>
                        <span>Total supply: {rewardSupply}</span>
                    </div>
                </div>
                <hr className={formStyles.divider}/>
                <div className={formStyles.baseContainer}>
                    <label htmlFor="launchpoolsConfigSelect">Initial reward amount</label>

                    <div className={formStyles.inputContainer}>
                        <input
                            type="text"
                            value={initialRewardInput}
                            className={formStyles.inputNumber}
                            onChange={(e) => handleTokenInputChange(e, setInitialRewardInput)}
                            placeholder="Initial amount"
                        />
                    </div>
                </div>
                <hr className={formStyles.divider}/>
                <div className={styles.header}>
                    <div className={formStyles.baseContainer}>
                        <label htmlFor="launchpoolsConfigSelect">Select Launchpools Config</label>
                    </div>
                    <select
                        id="launchpoolsConfigSelect"
                        className={formStyles.select}
                        value={selectedLaunchpoolsConfigKey ?? ""}
                        onChange={(e) => setSelectedLaunchpoolsConfigKey(e.target.value)}
                    >
                        <option value="" disabled>Select configuration</option>
                        {launchpoolsConfigVMsRenderer.map((config) => (
                            <option key={config.key.toBase58()} value={config.key.toBase58()}>
                                {config.key.toBase58()}
                            </option>
                        ))}
                    </select>
                </div>

                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.utils}>
                        {selectedLaunchpoolsConfig && (
                            <div className={formStyles.utilsText}>
                                <strong>Protocol Share: {selectedLaunchpoolsConfig.getProtocolRewardSharePercent()}%</strong>
                                <strong>Stakable Mint: {selectedLaunchpoolsConfig.stakableMint.toString()}</strong>
                            </div>
                        )}
                    </div>
                    <div className={formStyles.buttonContainer}>
                        <button className={formStyles.actionButton}
                                disabled={isInitializing || !userPublicKey || !rewardToken || !selectedLaunchpoolsConfigKey}
                                onClick={() => initializeLiquidityPool()}
                        >
                            Initialize Pool
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;