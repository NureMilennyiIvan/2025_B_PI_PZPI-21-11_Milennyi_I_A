import {LaunchpoolRow} from "@/models/launchpool-row";
import styles from "../styles.module.css";
import {useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import {shortenAddress} from "@/utils";

interface ActiveLaunchpoolsListProps {
    launchpoolRows: LaunchpoolRow[];
}

export const ActiveLaunchpoolList: React.FC<ActiveLaunchpoolsListProps> = ({launchpoolRows}) => {
    const router = useRouter();
    const copyToClipboard = async (address: string) => {
        await navigator.clipboard.writeText(address);
    };

    return (
        <div className={styles.tableContainer}>
            {launchpoolRows.length === 0 ? (
                <div className={styles.message}>No launchpools available.</div>
            ) : (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th>Launchpool</th>
                        <th>Reward Token</th>
                        <th>Stakable Token</th>
                    </tr>
                    </thead>
                    <tbody>
                    {launchpoolRows.map((pool) => {
                        const key = pool.launchpool;
                        const rewardMint = pool.rewardMint;
                        const stakableMint = pool.stakableMint;

                        return (
                            <tr
                                key={key}
                                className={styles.tableRow}
                                onClick={() => router.push(`${links.launchpools.path}/${key}`)}
                            >
                                <td>{shortenAddress(key)}</td>
                                <td
                                    title={rewardMint}
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        copyToClipboard(rewardMint);
                                    }}
                                    className={styles.clickable}
                                >
                                    {shortenAddress(rewardMint)}
                                </td>
                                <td
                                    title={stakableMint}
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        copyToClipboard(stakableMint);
                                    }}
                                    className={styles.clickable}
                                >
                                    {shortenAddress(stakableMint)}
                                </td>
                            </tr>
                        );
                    })}
                    </tbody>
                </table>
            )}
        </div>
    );
};