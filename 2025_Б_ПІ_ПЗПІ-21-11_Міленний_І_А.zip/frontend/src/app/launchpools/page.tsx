"use client"
import { usePublicKey } from "@/components/solana/solana-context-wrapper";
import Loader from "@/components/ui/loader";
import {useEffect, useMemo, useState} from "react";
import {PublicKey} from "@solana/web3.js";
import styles from "../styles.module.css";
import Link from "next/link";
import {links} from "@/components/ui/general-page-layout";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import {LaunchpoolRow} from "@/models/launchpool-row";
import {ActiveLaunchpoolList} from "@/app/launchpools/active-launchpools-list";
import LoadingError from "@/components/ui/error";

const Page = ()=> {
    const userPublicKey = usePublicKey();
    const launchpoolService = useLaunchpoolService();

    const {data: launchpoolsConfigsManager, isLoading: isLaunchpoolsConfigsManager, error: errorLaunchpoolsConfigsManager} = launchpoolService.fetchLaunchpoolsConfigsManagerVM();
    const [stakableMintToSearch, setStakableMintToSearch] = useState<PublicKey | undefined>(undefined);
    const [stakableMintToSearchStr, setStakableMintToSearchStr] = useState("");
    const {data: launchpoolRows, isLoading: isLaunchpoolRows, error: errorsLaunchpoolRows} = launchpoolService.fetchActiveLaunchpoolRows(20, stakableMintToSearch);
    const [launchpoolRowsRender, setLaunchpoolRowsRender] = useState<LaunchpoolRow[]>([]);

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return launchpoolsConfigsManager.authority === user || user === launchpoolsConfigsManager.headAuthority;
    }, [userPublicKey, launchpoolsConfigsManager]);
    useEffect(() => {
        if (launchpoolRows && !isLaunchpoolRows) {
            setLaunchpoolRowsRender(launchpoolRows);
        }
    }, [launchpoolRows, isLaunchpoolRows]);

    if (!!errorLaunchpoolsConfigsManager) {
        return <LoadingError error={errorLaunchpoolsConfigsManager} />;
    }

    if (isLaunchpoolsConfigsManager || (launchpoolRowsRender.length == 0 && isLaunchpoolRows)) {
        return <Loader />;
    }

    if (!!errorsLaunchpoolRows) {
        return <LoadingError error={errorsLaunchpoolRows} />;
    }
    return (
        <div className={styles.pageContainer}>
            <div className={styles.header}>
                <h1>Launchpools</h1>
                {isUserAuthority && (
                    <div className={styles.functionalButtonContainer}>
                        <Link href={links.launchpoolsConfigs.path}>
                            <button className={styles.functionalButton}>Configuration</button>
                        </Link>
                        <Link href={`${links.launchpools.path}${links.initializeLaunchpool.path}`}>
                            <button className={styles.functionalButton}>{links.initializeLaunchpool.label}</button>
                        </Link>
                        <Link href={`${links.launchpools.path}/initialized`}>
                            <button className={styles.functionalButton}>Initialized Launchpools</button>
                        </Link>
                    </div>
                )}
            </div>
            <div className={styles.searchContainer}>
                <div className={styles.searchInputContainer}>
                <input
                    type="text"
                    placeholder="Stakable Token"
                    value={stakableMintToSearchStr}
                    onChange={(e) => setStakableMintToSearchStr(e.target.value)}
                />
                </div>
                <button
                    className={styles.searchButton}
                    onClick={() => {
                        try {
                            setStakableMintToSearch(stakableMintToSearchStr ? new PublicKey(stakableMintToSearchStr) : undefined);
                        } catch (e) {
                            setStakableMintToSearch(undefined);
                        }
                    }}
                >
                    Search
                </button>
            </div>
            <ActiveLaunchpoolList launchpoolRows={launchpoolRowsRender}></ActiveLaunchpoolList>
        </div>
    );
};
export default Page;