"use client"

import {usePublicKey} from "@/components/solana/solana-context-wrapper";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import {useEffect, useMemo, useState} from "react";
import {LaunchpoolRow} from "@/models/launchpool-row";
import LoadingError from "@/components/ui/error";
import Loader from "@/components/ui/loader";
import styles from "../../styles.module.css";
import Link from "next/link";
import {links} from "@/components/ui/general-page-layout";
import {ActiveLaunchpoolList} from "@/app/launchpools/active-launchpools-list";
import {useRouter} from "next/navigation";

const Page = ()=> {
    const userPublicKey = usePublicKey();
    const launchpoolService = useLaunchpoolService();
    const router = useRouter();

    const {data: launchpoolsConfigsManager, isLoading: isLaunchpoolsConfigsManager, error: errorLaunchpoolsConfigsManager} = launchpoolService.fetchLaunchpoolsConfigsManagerVM();
    const {data: launchpoolRows, isLoading: isLaunchpoolRows, error: errorsLaunchpoolRows} = launchpoolService.fetchInitializedLaunchpoolRows();
    const [launchpoolRowsRender, setLaunchpoolRowsRender] = useState<LaunchpoolRow[]>([]);

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !launchpoolsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return launchpoolsConfigsManager.authority === user || launchpoolsConfigsManager.headAuthority === user;
    }, [userPublicKey, launchpoolsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isLaunchpoolsConfigsManager]);

    useEffect(() => {
        if (launchpoolRows && !isLaunchpoolRows) {
            setLaunchpoolRowsRender(launchpoolRows);
        }
    }, [launchpoolRows, isLaunchpoolRows]);

    if (!!errorLaunchpoolsConfigsManager) {
        return <LoadingError error={errorLaunchpoolsConfigsManager} />;
    }

    if (isLaunchpoolsConfigsManager || (launchpoolRowsRender.length == 0 && isLaunchpoolRows)) {
        return <Loader />;
    }

    if (!!errorsLaunchpoolRows) {
        return <LoadingError error={errorsLaunchpoolRows} />;
    }
    return (
        <div className={styles.pageContainer}>
            <div className={styles.header}>
                <h1>Launchpools</h1>
                {isUserAuthority && (
                    <div className={styles.functionalButtonContainer}>
                        <Link href={links.launchpoolsConfigs.path}>
                            <button className={styles.functionalButton}>Configuration</button>
                        </Link>
                        <Link href={`${links.launchpools.path}${links.initializeLaunchpool.path}`}>
                            <button className={styles.functionalButton}>{links.initializeLaunchpool.label}</button>
                        </Link>
                        <Link href={links.launchpools.path}>
                            <button className={styles.functionalButton}>Active Launchpools</button>
                        </Link>
                    </div>
                )}
            </div>
            <ActiveLaunchpoolList launchpoolRows={launchpoolRowsRender}></ActiveLaunchpoolList>
        </div>
    );
};
export default Page;