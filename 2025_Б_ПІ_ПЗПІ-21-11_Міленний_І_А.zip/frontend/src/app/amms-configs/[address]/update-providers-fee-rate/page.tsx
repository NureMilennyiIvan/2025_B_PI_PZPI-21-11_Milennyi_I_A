"use client"
import {usePublicKey, useSignAndSendBase64Transaction} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useEffect, useMemo, useState} from "react";
import formStyles from "../../../form-styles.module.css";
import {useParams, useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";

const Page = () => {
    const userPublicKey = usePublicKey();
    const liquidityPoolService = useLiquidityPoolService();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const router = useRouter();
    const {address} = useParams();
    const {notify} = useNotification();
    const [providersFeeRateBasisPoints, setProvidersFeeRateBasisPoints] = useState("0.0");
    const [isUpdating, setIsUpdating] = useState(false);

    const ammsConfigPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch (e) {
            return null;
        }
    }, [address]);
    if (!ammsConfigPubkey) {
        return <LoadingError error={new Error(`Invalid Amms Config address: ${address}`)}/>;
    }

    const {
        data: ammsConfigsManager,
        isLoading: isAmmsConfigsManager,
        error: errorAmmsConfigsManager
    } = liquidityPoolService.fetchAmmsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !ammsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return ammsConfigsManager.authority === user || ammsConfigsManager.headAuthority === user;
    }, [userPublicKey, ammsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isAmmsConfigsManager) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isAmmsConfigsManager]);

    if (errorAmmsConfigsManager) return <LoadingError error={errorAmmsConfigsManager}/>;
    if (isAmmsConfigsManager || !ammsConfigsManager) return <Loader/>;
    const handleUpdateFeeAuthority = async () => {
        try {
            setIsUpdating(true);
            const newProvidersFee = Math.round(Number(providersFeeRateBasisPoints) * 100);

            let base64Tx = await liquidityPoolService.updateAmmsConfigProvidersFeeRate(
                userPublicKey!,
                ammsConfigPubkey!,
                newProvidersFee
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.ammsConfigs.path}/${ammsConfigPubkey.toBase58()}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsUpdating(false)
        }
    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Update Providers Fee Rate</label>
                </div>
                <div className={formStyles.sliderContainer}>
                    <input
                        type="range"
                        min="0"
                        max="100"
                        step="0.1"
                        value={providersFeeRateBasisPoints}
                        onChange={(e) => setProvidersFeeRateBasisPoints(Number(e.target.value).toFixed(1))}
                    />
                    <label>{providersFeeRateBasisPoints}%</label>
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                            onClick={handleUpdateFeeAuthority}
                            disabled={!isUserAuthority || isUpdating}
                        >Update
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;