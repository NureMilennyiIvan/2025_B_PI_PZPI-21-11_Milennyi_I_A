"use client"
import {usePublicKey} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useEffect, useMemo} from "react";
import styles from "../../styles.module.css";
import {useParams, useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";

const Page = () => {
    const userPublicKey = usePublicKey();
    const liquidityPoolService = useLiquidityPoolService();
    const router = useRouter();
    const {address} = useParams();

    const ammsConfigPubkey = useMemo(() => {
        if (typeof address !== "string") return null;
        try {
            return new PublicKey(address);
        } catch (e) {
            return null;
        }
    }, [address]);

    if (!ammsConfigPubkey) {
        return <LoadingError error={new Error(`Invalid Amms Config address: ${address}`)}/>;
    }

    const {
        data: ammsConfigsManager,
        isLoading: isAmmsConfigsManager,
        error: errorAmmsConfigsManager
    } = liquidityPoolService.fetchAmmsConfigsManagerVM();
    const {
        data: ammsConfig,
        isLoading: isAmmsConfigs,
        error: errorAmmsConfigs
    } = liquidityPoolService.fetchAmmsConfigVM(ammsConfigPubkey);

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !ammsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return ammsConfigsManager.authority === user || ammsConfigsManager.headAuthority === user;
    }, [userPublicKey, ammsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isAmmsConfigsManager) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isAmmsConfigsManager]);

    if (errorAmmsConfigsManager) return <LoadingError error={errorAmmsConfigsManager}/>;
    if (errorAmmsConfigs) return <LoadingError error={errorAmmsConfigs}/>;
    if (isAmmsConfigsManager || isAmmsConfigs || !ammsConfigsManager || !ammsConfig) return <Loader/>;

    return (
        <div className={styles.pageContainer}>
            <section className={styles.managerBlock}>
                <h2>AMMs Config</h2>
                <div className={styles.header}>
                    <p><strong>Fee Authority:</strong> {ammsConfig.feeAuthority}</p>
                    <button className={styles.functionalButton}
                            onClick={() => router.push(`${links.ammsConfigs.path}/${address?.toString()}/update-fee-authority`)}>Update
                    </button>
                </div>


                <div className={styles.header}>
                    <p><strong>Protocol Fee Rate:</strong> {ammsConfig.getProtocolFeeRatesAsPercent()}%</p>
                    <button
                        className={styles.functionalButton}
                        onClick={() => router.push(`${links.ammsConfigs.path}/${address?.toString()}/update-protocol-fee-rate`)}
                    >
                        Update
                    </button>
                </div>

                <div className={styles.header}>
                    <p><strong>Providers Fee Rate:</strong> {ammsConfig.getProvidersFeeRatesAsPercent()}%</p>

                    <button
                        className={styles.functionalButton}
                        onClick={() => router.push(`${links.ammsConfigs.path}/${address?.toString()}/update-providers-fee-rate`)}
                    >
                        Update
                    </button>

                </div>
            </section>
        </div>
    );
}
export default Page;