"use client"

import {
    usePublicKey,
    useSignAndSendBase64Transaction
} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import {useRouter} from "next/navigation";
import React, {useEffect, useMemo, useState} from "react";
import LoadingError from "@/components/ui/error";
import Loader from "@/components/ui/loader";
import styles from "../../styles.module.css";
import formStyles from "../../form-styles.module.css";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";

const Page = () => {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const liquidityPoolService = useLiquidityPoolService();
    const router = useRouter();
    const {notify} = useNotification();

    const [feeAuthorityStr, setFeeAuthorityStr] = useState("");
    const [protocolFeeRateBasisPoints, setProtocolFeeRateBasisPoints] = useState("0.0");
    const [providersFeeRateBasisPoints, setProvidersFeeRateBasisPoints] = useState("0.0");
    const [isCreating, setIsCreating] = useState(false);

    const {
        data: ammsConfigsManager,
        isLoading: isAmmsConfigsManager,
        error: errorAmmsConfigsManager
    } = liquidityPoolService.fetchAmmsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !ammsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return ammsConfigsManager.authority === user || ammsConfigsManager.headAuthority === user;
    }, [userPublicKey, ammsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isAmmsConfigsManager) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isAmmsConfigsManager]);

    if (errorAmmsConfigsManager) return <LoadingError error={errorAmmsConfigsManager}/>;
    if (isAmmsConfigsManager || !ammsConfigsManager) return <Loader/>;

    const handleCreateConfig = async () => {
        try {
            setIsCreating(true);
            const feeAuthority = new PublicKey(feeAuthorityStr);
            const protocolFee = Math.round(Number(protocolFeeRateBasisPoints) * 100);
            const providersFee = Math.round(Number(providersFeeRateBasisPoints) * 100);

            let [base64Tx, ammsConfig] = await liquidityPoolService.initializeAmmsConfig(
                userPublicKey!,
                ammsConfigsManager!.key,
                feeAuthority,
                protocolFee,
                providersFee
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.ammsConfigs.path}/${ammsConfig}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsCreating(false)
        }
    };
    const handleProtocolFeeChange = (value: number) => {
        const total = value + Number(providersFeeRateBasisPoints);
        if (total <= 100) setProtocolFeeRateBasisPoints(value.toFixed(1));
    };

    const handleProvidersFeeChange = (value: number) => {
        const total = value + Number(protocolFeeRateBasisPoints);
        if (total <= 100) setProvidersFeeRateBasisPoints(value.toFixed(1));
    };
    return (
        <div className={formStyles.formPageContainer}>
            <div className={styles.header}>
                <h2>Create AMMs Config</h2>
            </div>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Fee Authority</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter fee authority pubkey"
                        value={feeAuthorityStr}
                        onChange={(e) => setFeeAuthorityStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.sliderContainer}>
                    <label>Protocol Fee Rate</label>
                    <input
                        type="range"
                        min="0"
                        max="100"
                        step="0.1"
                        value={protocolFeeRateBasisPoints}
                        onChange={(e) => handleProtocolFeeChange(Number(e.target.value))}
                    />
                    <label>{protocolFeeRateBasisPoints}%</label>
                </div>
                <div className={formStyles.sliderContainer}>
                    <label>Providers Fee Rate</label>
                    <input
                        type="range"
                        min="0"
                        max="100"
                        step="0.1"
                        value={providersFeeRateBasisPoints}
                        onChange={(e) => handleProvidersFeeChange(Number(e.target.value))}
                    />
                    <label>{providersFeeRateBasisPoints}%</label>
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                            onClick={handleCreateConfig}
                            disabled={!isUserAuthority || !feeAuthorityStr || isCreating}
                        >Create
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;