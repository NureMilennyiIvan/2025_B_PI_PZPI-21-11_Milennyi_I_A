"use client"
import {usePublicKey} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import Loader from "@/components/ui/loader";
import LoadingError from "@/components/ui/error";
import {useEffect, useMemo} from "react";
import styles from "../styles.module.css";
import {useRouter} from "next/navigation";
import {AmmsConfigsList} from "@/app/amms-configs/amms-configs-list";
import {links} from "@/components/ui/general-page-layout";

const Page = ()=> {
    const userPublicKey = usePublicKey();
    const liquidityPoolService = useLiquidityPoolService();
    const router = useRouter();

    const {data: ammsConfigsManager, isLoading: isAmmsConfigsManager, error: errorAmmsConfigsManager} = liquidityPoolService.fetchAmmsConfigsManagerVM();
    const {data: ammsConfigs, isLoading: isAmmsConfigs, error: errorAmmsConfigs} = liquidityPoolService.fetchAmmsConfigsAddresses();
    const [isUserAuthority, showUpdateHeadAuthorityButton] = useMemo(() => {
        if (!userPublicKey || !ammsConfigsManager) return [false, false];
        const user = userPublicKey.toBase58();
        const showUpdateHeadAuthorityButton = ammsConfigsManager.headAuthority === user
        return [
            ammsConfigsManager.authority === user || showUpdateHeadAuthorityButton,
            showUpdateHeadAuthorityButton
        ];
    }, [userPublicKey, ammsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isAmmsConfigsManager) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isAmmsConfigsManager]);

    if (errorAmmsConfigsManager) return <LoadingError error={errorAmmsConfigsManager} />;
    if (errorAmmsConfigs) return <LoadingError error={errorAmmsConfigs} />;
    if (isAmmsConfigsManager || isAmmsConfigs || !ammsConfigsManager || !ammsConfigs) return <Loader />;

    return (
        <div className={styles.pageContainer}>
            <section className={styles.managerBlock}>
                <h2>AMMs Configurations Manager</h2>
                <div className={styles.header}>
                    <p><strong>Head Authority:</strong> {ammsConfigsManager.headAuthority}</p>
                    {showUpdateHeadAuthorityButton && (
                        <button className={styles.functionalButton} onClick={() => router.push(`${links.ammsConfigs.path}/update-head-authority`)}>Update</button>
                    )}
                </div>
                <div className={styles.header}>
                    <p><strong>Authority:</strong> {ammsConfigsManager.authority}</p>
                    {isUserAuthority && (
                        <button className={styles.functionalButton} onClick={() => router.push(`${links.ammsConfigs.path}/update-authority`)}>Update</button>
                    )}
                </div>
            </section>

            <section className={styles.configsSection}>
                <div className={styles.header}>
                <h2>AMMs Configs</h2>
                <button className={styles.functionalButton} onClick={() => router.push(`${links.ammsConfigs.path}/create`)}>Create</button>
                </div>
                {isUserAuthority && (
                    <div>
                        <AmmsConfigsList ammsConfigsAddresses={ammsConfigs} />
                    </div>
                )}
            </section>
        </div>
    );
}
export default Page;