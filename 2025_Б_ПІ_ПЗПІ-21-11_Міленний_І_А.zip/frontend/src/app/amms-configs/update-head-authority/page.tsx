"use client"

import {
    usePublicKey,
    useSignAndSendBase64Transaction
} from "@/components/solana/solana-context-wrapper";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";
import {useRouter} from "next/navigation";
import React, {useEffect, useMemo, useState} from "react";
import LoadingError from "@/components/ui/error";
import Loader from "@/components/ui/loader";
import styles from "../../styles.module.css";
import formStyles from "../../form-styles.module.css";
import {links} from "@/components/ui/general-page-layout";
import {PublicKey} from "@solana/web3.js";
import {useNotification} from "@/components/ui/notification-context";

const Page = ()=> {
    const userPublicKey = usePublicKey();
    const signAndSendBase64Tx = useSignAndSendBase64Transaction();
    const liquidityPoolService = useLiquidityPoolService();
    const router = useRouter();
    const { notify } = useNotification();

    const [newHeadAuthorityStr, setNewHeadAuthorityStr] = useState("");
    const [isUpdating, setIsUpdating] = useState(false);

    const {data: ammsConfigsManager, isLoading: isAmmsConfigsManager, error: errorAmmsConfigsManager} = liquidityPoolService.fetchAmmsConfigsManagerVM();

    const isUserAuthority = useMemo(() => {
        if (!userPublicKey || !ammsConfigsManager) return false;
        const user = userPublicKey.toBase58();
        return ammsConfigsManager.headAuthority === user;
    }, [userPublicKey, ammsConfigsManager]);

    useEffect(() => {
        if (!isUserAuthority && !isAmmsConfigsManager ) {
            router.push(links.launchpools.path);
        }
    }, [isUserAuthority, isAmmsConfigsManager]);

    if (errorAmmsConfigsManager) return <LoadingError error={errorAmmsConfigsManager} />;
    if (isAmmsConfigsManager || !ammsConfigsManager) return <Loader />;

    const handleUpdateHeadAuthority = async () => {
        try {
            setIsUpdating(true);
            const newHeadAuthority = new PublicKey(newHeadAuthorityStr);

            let base64Tx = await liquidityPoolService.updateAmmsConfigsManagerHeadAuthority(
                userPublicKey!,
                newHeadAuthority
            );
            await signAndSendBase64Tx!(base64Tx);
            router.push(`${links.ammsConfigs.path}`);
        } catch (e) {
            const message = e instanceof Error ? e.message : typeof e === "string" ? e : JSON.stringify(e);
            notify("error", message);
            setIsUpdating(false)
        }
    };

    return (
        <div className={formStyles.formPageContainer}>
            <div className={formStyles.smallGeneralForm}>
                <div className={formStyles.baseContainer}>
                    <label>Update Head Authority</label>
                </div>
                <div className={formStyles.inputContainer}>
                    <input
                        className={styles.input}
                        type="text"
                        placeholder="Enter new head authority pubkey"
                        value={newHeadAuthorityStr}
                        onChange={(e) => setNewHeadAuthorityStr(e.target.value.trim())}
                    />
                </div>
                <div className={formStyles.bottomContainer}>
                    <div className={formStyles.buttonContainer}>
                        <button
                            className={formStyles.actionButton}
                        onClick={handleUpdateHeadAuthority}
                        disabled={!isUserAuthority || !newHeadAuthorityStr || isUpdating}
                    >Update
                    </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Page;