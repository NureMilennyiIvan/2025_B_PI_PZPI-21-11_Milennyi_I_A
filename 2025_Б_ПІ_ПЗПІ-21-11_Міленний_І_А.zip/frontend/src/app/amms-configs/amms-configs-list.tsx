"use client"
import styles from "../styles.module.css";
import {links} from "@/components/ui/general-page-layout";
import {useRouter} from "next/navigation";
import {AmmsConfigAddress} from "@/models/amms-config-address";
import {shortenAddress} from "@/utils";

interface AmmsConfigsListProps {
    ammsConfigsAddresses: AmmsConfigAddress[];
}

export const AmmsConfigsList: React.FC<AmmsConfigsListProps> = ({ammsConfigsAddresses}) => {
    const router = useRouter();


    return (
        <div className={styles.tableContainer}>
            {ammsConfigsAddresses.length === 0 ? (
                <div className={styles.message}>No amms configs available.</div>
            ) : (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    {ammsConfigsAddresses.map((config) => {
                        const key = config.ammsConfig;
                        return (
                            <tr
                                key={config.ammsConfig}
                                className={styles.tableRow}
                                onClick={() =>
                                    router.push(`${links.ammsConfigs.path}/${key}`)
                                }
                            >
                                <td className={styles.clickable}>{shortenAddress(config.ammsConfig)}</td>
                            </tr>
                        );
                    })}
                    </tbody>
                </table>
)}
        </div>
    );
};
