"use client"
import React from "react";
import {PublicKey} from "@solana/web3.js";
import {Trade} from "@/models/trade";
import { shortenAddress} from "@/utils";
import styles from "../styles.module.css";
import {links} from "@/components/ui/general-page-layout";
import {useRouter} from "next/navigation";

export const UserTradesList = ({user, trades}: { user: PublicKey, trades: Trade[] }) => {
    const router = useRouter();
    return (
        <div className={styles.tableContainer}>
            {trades.length === 0 ? (
                <div className={styles.message}>No trades available.</div>
            ) : (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th>Signature</th>
                        <th>Time</th>
                        <th>Pool</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    {trades.map((trade, idx) => (
                        <tr className={styles.tableRow} key={idx}>
                            <td>{shortenAddress(trade.signature, 4)}</td>
                            <td>{new Date(trade.timestamp).toLocaleTimeString()}</td>
                            <td onClick={() =>
                                router.push(`${links.liquidityPools.path}/${trade.cpAmm.toBase58()}`)
                            }>{shortenAddress(trade.cpAmm, 4)}</td>
                            {trade.isInOut ? (
                                <>
                                    <td style={{color: "#ff4d4d"}}>Sell</td>
                                </>
                            ) : (
                                <>
                                    <td style={{color: "#4dff4d"}}>Buy</td>
                                </>
                            )}
                        </tr>
                    ))}

                    </tbody>
                </table>
            )}
        </div>
    )
}