"use client"
import React from "react";
import {PublicKey} from "@solana/web3.js";
import {shortenAddress} from "@/utils";
import {StakePositionVM} from "@/models/stake-position-vm";
import styles from "../styles.module.css";
import {useRouter} from "next/navigation";
import {links} from "@/components/ui/general-page-layout";

export const UserStakePositions = ({user, positionsRender}: {
    user: PublicKey,
    positionsRender: StakePositionVM[]
}) => {
    const router = useRouter();
    return (
        <div className={styles.tableContainer}>
            {positionsRender.length === 0 ? (
                <div className={styles.message}>No active stake positions available.</div>
            ) : (
                <table className={styles.table}>
                    <thead>
                    <tr>
                        <th>Position</th>
                        <th>Launchpool</th>
                    </tr>
                    </thead>
                    <tbody>
                    {positionsRender.map((position, idx) => (
                        <tr className={styles.tableRow} onClick={() =>
                            router.push(`${links.launchpools.path}/${position.launchpool.toBase58()}`)
                        } key={idx}>
                            <td>{shortenAddress(position.key, 4)}</td>
                            <td>{shortenAddress(position.launchpool, 4)}</td>
                        </tr>
                    ))}

                    </tbody>
                </table>
            )}
        </div>
    )
}