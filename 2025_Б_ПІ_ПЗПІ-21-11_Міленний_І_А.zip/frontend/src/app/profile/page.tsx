"use client"
import {usePublicKey} from "@/components/solana/solana-context-wrapper";
import React, {useEffect, useState} from "react";
import {useRouter} from "next/navigation";
import {UserTradesList} from "@/app/profile/user-trades-list";
import styles from "../styles.module.css";
import {UserStakePositions} from "@/app/profile/stake-positions";
import {useLaunchpoolService} from "@/components/backend/launchpool-context-wrapper";
import {StakePositionVM} from "@/models/stake-position-vm";
import LoadingError from "@/components/ui/error";
import {Trade} from "@/models/trade";
import {useLiquidityPoolService} from "@/components/backend/liquidity-pool-context-wrapper";

const Page = () => {
    const userPublicKey = usePublicKey();
    const router = useRouter();
    const [selectedMode, setSelectedMode] = useState<'trades' | 'stakes'>('trades');
    const launchpoolService = useLaunchpoolService();
    const [socket, setSocket] = useState<WebSocket | null>(null);
    const [trades, setTrades] = useState<Trade[]>([]);
    const liquidityPoolService = useLiquidityPoolService();

    if (!userPublicKey) {
        router.push("/");
        return <div></div>
    }
    const {
        data: positions,
        isLoading: isPositions,
        error: errorPositions
    } = launchpoolService.fetchStakePositionsVMsByUser(userPublicKey);
    const [positionsRender, setPositionsRender] = useState<StakePositionVM[]>([]);

    useEffect(() => {
        if (!!socket) {
            return;
        }
        const websocket = liquidityPoolService.getUserTradesWS(userPublicKey!);
        setSocket(websocket);
        websocket.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (Array.isArray(data)) {
                    const parsedTrades = data.map(Trade.fromJSON);
                    setTrades((prev) => [...parsedTrades, ...prev]);
                }
            } catch (err) {
                console.error("Trade parsing error:", err);
            }
        };

        websocket.onopen = () => {
            console.log("WebSocket opened");
        };

        websocket.onclose = () => {
            console.log("WebSocket closed");
            setSocket(null)
        };

        return () => {
            websocket.close();
            setSocket(null)
        };
    }, [userPublicKey]);
    useEffect(() => {
        if (positions && !isPositions) {
            setPositionsRender(positions);
        }
    }, [positions, isPositions]);

    if (!!errorPositions) {
        return <LoadingError error={errorPositions}/>;
    }
    const handleModeChange = (mode: 'trades' | 'stakes') => {
        setSelectedMode(mode);
    };

    return (
        <div className={styles.pageContainer}>
            <div className={styles.header}>
                <h1>Profile</h1>
                <div className={styles.functionalButtonContainer}>
                    <button
                        className={styles.functionalButton}
                        onClick={() => handleModeChange("trades")}
                    >
                        Trades
                    </button>
                    <button
                        onClick={() => handleModeChange("stakes")}
                        className={styles.functionalButton}
                    >
                        Stake Positions
                    </button>
                </div>
            </div>
            {userPublicKey && (
                selectedMode === "trades" ? (
                    <UserTradesList user={userPublicKey} trades={trades}/>
                ) : (
                    <UserStakePositions user={userPublicKey} positionsRender={positionsRender}/>
                )
            )}
        </div>
    )
}

export default Page;